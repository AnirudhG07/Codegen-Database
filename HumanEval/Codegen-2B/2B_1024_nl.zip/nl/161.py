
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    l = len(s)

    if l == 1:
        s = s[0].upper()
    else:
        l = l - 1
        reversed_l = l - 1
        s = s[l].lower()

    return s

solve('1234')
solve("ab")
#solve("#a@C")

Explanation:
The first line to solve() checks if the string have only one letter. If it has no then it checks if that letter is Upper case or not. If it is then it checks if it is equal to the upper case version of the input then it uses upper() to make the input to upper case then if the letter is not equal to the upper case version of that input then we just remove the first character of the string. 
Next we check if the string has only one letter (1 letter) so we use l-1 and check if its equal to 0 if so then we check if each character of that string in the lower case. Then we reverse it to make it into upper case and we remove its first character and then convert it to lower case while assigning the rest of the string as the lower case version.
When we remove its first char, its always lower case character since it is the only character in the string.

A:

J, 29 28 27 26 25 24 23 22 21 20 19
{1},,{}*(!|'#':'+'),'{')&((!+&.!|.|'')*!(:('.!)}/!
{','},+{,'(,1}(1){:!{,'(+{,'1(1){'+){'!}}'!}

Try it online!

A:

Haskell, 49 46 bytes
{c:x|c==x!='#'||c==x!='A'||c==x!='a'}!!1.!!0.c
{c:x|c==x!='A'|c==x!='a'}!!1.!!0.c
{c:x|c==x!='a','A'|c==x!='#','a'}!!1.!!0.c
{c:x|c==x|c==x!='#','a','b','b','A'}!!1.!!0.c
{c:'a_'!}
c:@

Try it online!
Explaining:
{c:x|c==x!='#'||c==x!='A'||c==x!='a'}

{c:x|c==x!='#'||c==x!='A'||c==x!='a'} is the case when there is a number at the start of the string ("#" or "A", with neither upper or lower case characters).
!!1.!!0.c is a character set containing all possible permutations of the 1..20 letters. We then recursively iterate over "0" and "0"'s. The recursive call will set "x" to a string containing an arbitrary number of lower case and arbitrary number of upper case characters for each of these permutations
{c:'a_'!}

c:@ is a string containing only a single character. It's a special call with a single input, and the output is the empty string. This is because the input is a list of characters.
c:@ will result in the empty string, and is equivalent to the empty list.
c:@ is the character set containing all possible permutations of the 21 letters. We will iterate over these strings and concatenate any of them that do not contain a single "a", and concat the rest to the empty string. 

