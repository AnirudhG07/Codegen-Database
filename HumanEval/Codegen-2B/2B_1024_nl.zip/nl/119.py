
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    if not lst or len(lst)<2:
        return 'No'
    lst1 = lst[0]
    lst2 = lst[1]
    c = []
    c.extend(lst1)
    c.extend(lst2)
    c.append((None, None))
    c.append(None)
    c.append((None, None))
    result = []
    for i in range(len(c)):
        if c[i][0] == '(':
            result.append(c[i][1])
        elif c[i][0] == ')':
            result.append(c[i][1])
            break
        matchlen = 0
        if len(c[i])>1:
            for j in range(len(c[i])):
                if c[i][j] == c[i][len(c[i])-1]:
                    matchlen += 2
        else:
            matchlen = 1
        matchlen += 1
        if matchlen!= len(c[i]:
            return 'No'
        matchlen = 1
        if c[i][1] == c[i][0]:
            matchlen += 1
            if len(c[i])>matchlen:
                return 'No'
        elif c[i][1] == c[0][0]:
            matchlen += 1
            if len(c[i])>matchlen:
                return 'No'
    return 'Yes'

