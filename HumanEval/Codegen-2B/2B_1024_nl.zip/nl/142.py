


def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """
    n = 0 #The input of the function
    result = 0  #The output of the function
    for i in lst:
        if i%3 == 0 or i%4 == 0:
            result += ((i * i)**2))
        else:
            result += (i**3)
    return result

lst = [1,2,3]

print(sum_squares(lst))

A:

As this question is tagged both python and mathematics, I'll give an answer in both languages. The sum_squares() function in python code below. I'd recommend using lambda to avoid global scope.
