
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    #       n,m,s,d = len(nums),len(nums[0:n-1]),nums[0:n-1]
    # return -n+1
    nums = list(map(int, nums))
    sum_of_digits = 0
    nums.sort()
    for i in range(len(nums)):
        s = 0
        while True:
            c = (s + (nums[i] % 10) // 10) % 10;
            if (c == 0):
                if s == 0:
                    break
            s += 1
        sum_of_digits += c
    return sum_of_digits

