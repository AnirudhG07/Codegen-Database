
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    alphabet = set(string.ascii_lowercase)
    new_alphabet = set(string.ascii_uppercase)

    def alphabet_rotation(alphabet, shift):
        for letter in alphabet:
            alphabet = new_alphabet - letter
        return alphabet 

    s_rotated = []
    length = len(s)
    cnt = 0
    while cnt < length:
        if s[cnt] == 'i':
            s_rotated.append(str(s[cnt - 1]) + str(s[cnt + 1]))
        elif s[cnt] == 'j':
            s_rotated.append(str(s[cnt - 1]))
        elif s[cnt] == 'k':
            s_rotated.append(str(s[cnt - 1]) + str(s[cnt + 2]))
        elif s[cnt] == 'l':
            s_rotated.append(str(s[cnt - 1]) + str(s[cnt - 2]))
        elif s[cnt] =='m':
            s_rotated.append(str(s[cnt - 1] + s[cnt - 2]))
        else:
            s_rotated.append(str(s[cnt - 1]))
        cnt += 1
    return s_rotated
