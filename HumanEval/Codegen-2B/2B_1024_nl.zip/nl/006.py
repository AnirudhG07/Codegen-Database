from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    list_of_int = []
    stack: List[int] = []  # (a,b) => list_of_int[b]
    last_paren = None
    for paren in paren_string:
        if paren in ('(', ')', '()'):
            if stack:
                last_paren = last_paren or stack[stack[-1]]

            stack.append(last_paren.ord())
        elif paren == '(':
            list_of_int.append(0)
        elif paren == ')':
            if len(stack) == 0:
                list_of_int = [last_paren.ord(), ]
                break
            else:
                list_of_int.append(1)  # depth of deepest nesting
                stack.pop()
        elif paren == '()':
            list_of_int.append(last_paren.ord())
        else:
            list_of_int.append(stack.pop())  # depth of deepest nesting
    return list_of_int


