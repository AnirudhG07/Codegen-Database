
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    return ((2*n%2)**(n//2))%3

for n in range(len(tests)/2):
    if digits(n)%10!= digits(n+1)%10:
        print(n, digits(n)%10)
"""

I'm trying to make it accept all integers in the list. I'm unsure what to do with the n-1 at the end of the loop though?

A:

You need to loop while n is a valid number, not just the first half of the list of test numbers. You can do this by checking that n is not part of the first half of the list before you do the last test:
sum = 0    # current sum (included)
d = max(len(iterable) for _ in iterable)    # max input length
for n in xrange(len(tests)):
    if n in tests[0:d] and tests[d-1] == tests[0]:
        print(n/10, '%d is a factor of' % (n, 10), tests[0])
        sum += len(tests)
        break    # quit at the current sum (if it has been reached)
else:
    sum += len(tests)

Note that I have swapped the outer loop's sum-comparing step (checking if n in tests[0:d]) with the inner loop, with the test (n in tests[0:d], tests[d-1] == tests[0]) and the rest.  If you had the tests not be the same length, you would have to swap the two.
I'm using %d for printing the output, which doesn't print trailing newlines if the length of the iterable is divisible by any long number. %10 just makes things a bit uglier. Here's the result of your tests on my system, using Python 2.7.10:
1   0
3   0
4   0
22  7
23  9
24  0
26  5
27  10
29  5
2   2
3   2
3   4
5   4
10  3
10  6
11  9
12  9
13  0
13  10
15  10
14  19
15  0
16  1
17  3
18  1
19  6
20  0
24  2
25  12
26  10
27  6
27  9
28  3
29  15

