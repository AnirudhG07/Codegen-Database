
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    start_ones_count = 1
    ones_count_sum = 0
    for i in range(n):
        if (i % 10) == 1:
            starts_ones_count += 1
        else:
            ones_count_sum += -1

    one_ends_count = starts_ones_count - starts_ones_count + 1
    return OneEndsCount(n, one_ends_count)


Theorem: starts_one_ends_count == (n-1)!/(2 * n)
Proof:
    cncl
    unfold starts_one_ends_count
    auto
    congruence
        assume c: IH starts_one_ends n
        factor n-2 // one_ends_count -- IH n
      end
    apply divides_fact2 -- n
    apply divides_fact -- (2 * n)
    auto
    apply IH starts_one_ends, n
  qed
Qed

Theorem: finishes_one_ends_count == (n-1)!/(2 * n-1)
Proof:
    cncl
    unfold finishes_one_ends_count
    auto
    congruence
        assume finishes_one_ends n
        factor n-1 // (2 * n) -- (2 * n-1)
      end
    apply divides_fact2 -- (2 * n-1)
    auto
    apply IH finishes_one_ends, n
  qed

Theorem: counts_one_ends(n) == (n-1)!/(2 * n)
Proof:
    cncl
    unfold counts_one_ends
    auto
    apply IH counts_one_ends, n
  qed

Theorem: counts_one_ends(1) == 1
Proof:
    case 1
    auto
    exists
    unfold counts_one_ends
    case (1 < *n*)
    by contradiction // from formulas
    clear
    unfold counts_one_ends_count /| 2
    case (n = 1)
        assume 1: 1: IH n: - |- [ |- (2 > 1)]-- contradict 1
        auto
        unfold counts_one_ends_count, starts_one_ends_count
        case (IH 1) // count |- IH 1.from n
        by contradiction // from formulas
    clear
    exists
    auto
    case IH (1 < *n*)
    by contradiction
    auto
    clear
QED

Theorem: starts_one_ends_count_equals_finishes_one_ends_count(n) == 1
Proof:
    case n, (1 < n)
    auto
    auto
    apply starts_one_ends_count == finishes_one_ends_count
        by apply counts_one_ends_count == (n-1)!/(2 * n)
    auto
    apply OneEndsCount(n, (n![n] - 1)/(2 * n)) == counts_one_ends(n)
        by case 1 // clear
    auto
    apply IH one_ends_count_equals_finishes_one_ends_count
        by apply OneEndsCount(n, (n! [1] - 1)/(2 * n))
QED
