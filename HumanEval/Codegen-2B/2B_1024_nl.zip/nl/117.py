
def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """
    if s:
        all_words = set(s)  # All words
        for x in range(1, n + 1):
            # Remove all consonants in this word
            all_words -= set(t[0] for t in all_words if t[0] in 'bcdfghjklmnpstv')
            if s.index(all_words +'') > -1:
                # We've reached the nth word so return it
                return [s[i:s.index(all_words +'')]]
    print("Error: Unable to find n words in input string")
    return []

# Testing
# ------------------------------------------------
# >>> select_words("Mary had a little lamb", 3)
# True
# >>> select_words("This letter is very long.", 1)
# ['e'], ['l', 't','s']
# >>> select_words("", 0)
# ['', '', '', '', '']
# >>> select_words("", 1)
# []

# Testing for case #1
# ------------------------------------------------

# >>> select_words("Mary had a little lamb", 1)
# ['Mary', 'had', 'a', 'little', 'Lamb']
# >>> select_words("mahi thar lambu", 2)
# ['mahi', 'thar', 'lampu', 'Mahi', 'thar']

# Testing for case #2
# ------------------------------------------------

# >>> select_words("", 1)
# ['', '', '', '', '']
# >>> select_words("", 0)
# ['', '', '', '', '']   

A:

The problem is that all_words is a set, so it's not iterable, and because of that:
if s.index(all_words +'') > -1

s.index(...) returns the index of "all_words +''".
The index is used to determine the last word in all_words, but it is not used to determine whether or not "all_words +''" is present in s.

