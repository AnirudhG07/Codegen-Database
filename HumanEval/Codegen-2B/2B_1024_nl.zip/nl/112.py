
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    if s == '':
        #s = 'a', c = 'a', this is the case we want to return if the result is palindrome
        return s, False

    for i in s:
        if c in (s[-i],s[-i-1]):
            #i can be max value in string, -1
            i = -1

        #this is the case when s == c, return the result string and False to the checking value
        if i == 0:
            s = s[1:]
            for i,j in reversed(range(i+1, len(s))):
                if s[i] == s[j]:
                    s = s[:i]

        #if i > 0:
        #   s = 'a' + 'b' + s[i:i+1]
        #else:
        s = (s[-i]) + 'b' + s[i:]

    return s, True

if __name__ == '__main__':

    #read input string
    read_input_str = "abcdef"
    #read input char
    read_c = input("Enter character = ")

    #write input string to stack
    stack = []
    while len(stack)!= 0: #stop condition if stack is empty
        stack.append(read_input_str)
    print("\nInput is \n")
    for s in stack: #process input string
        print str(s)
    #print()
    #print("Output is \n")
    s = ''.join(s)

    #if the input string is palindrome, return ''.join(s).
    #else returns output.
    palindrome = reverse_delete(s,read_c)
    print(palindrome)