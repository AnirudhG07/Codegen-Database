
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    ret = 0
    # Handle special case of sum 0
    if len(nums) == 0:
        return 0

    # Check each sub-array...
    for s in range(len(nums)):
        if s > 0:
            # If sum of previous sub-arrays is less than this sub-array...
            if sum(nums[:s - 1] + nums[s + 1:]) < ret:
                ret = sum(nums[:s - 1] + nums[s + 1:])
        else:
            #... then the sub-array is an empty set so return the sum of this subarray.
            ret = sum(nums[:s - 1] + nums[s + 1:])
    return ret

And here is the timings it gives me for comparison. (Notice that the timing for the solution I came up with is actually faster than both the Python Solution and the Solution in C++) (the C++ one is slower I think on purpose). Note that for the C++ solution the loop is already over the sub-arrays so there is no need to check whether it is empty.
For reference I'm running on Visual Studios 2010 if it helps.
Timings for Python Solution using the built-in sum function:
Time: 0.039 ms

Timings for Joda Time Solution using Arrays.stream():
Time: 2.918 ms

Timings for Joda Time Solution using Arrays: sum() without an array filter (same approach as Arrays.stream() but using the API:
Time: 1.899 ms

Timings for my own Solution (the solution using subarrays and array filters I came up with while debugging):
Time: 3.000 ms

A:

Java, 738 µs
I'm posting this answer so that others have the opportunity to see how small of a problem it is to do this calculation in Java on a regular desktop computer. 
package test;

public class Test {
    public static void main(String[] args) {

        int nums[] = new int[] { 2, 3, 4, 1, 2, 4 }; // initial array
        int s = 0;

        s = findEmptySubArrays(new int[] {});

        System.out.println(isEmpty(s));
    }
}

private static boolean isEmpty(int[] nums) {
    int sum = 0, max = nums.length - 1;
    for (int i = 0; i <= max; i++) {
        for (int j = i + 1; j <= max; j++) {
            if (nums[i] == nums[j]) continue;
            sum = max - i;
        }
    }
    return sum == max / 2;
}

private static int findEmptySubArrays(int[] nums) {
    int ret = 0;
    for (int i = 0; i < nums.length; i++) {
        if (isEmpty(nums))
            ret = ret + nums[i];
    }
    return ret;
}

A:

There are only a few possible solutions and there is no one-size-fits-all solution. I'll try to address your questions in that order:

How to do you