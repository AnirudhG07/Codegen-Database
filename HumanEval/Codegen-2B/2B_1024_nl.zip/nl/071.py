
def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''
        a = float(a)
        b = float(b)
        c = float(c)
        return ((a + b + c) * 0.5) / 4

>>> triangle_area(1, 2, 10) == 1
True
>>> triangle_area(1, 2, 16) == -1
False
>>> triangle_area(1, 2, 100000) == 6
True
>>> triangle_area(1, 2, 100) == -1
False
>>> triangle_area(3,4,5) == 6
True
>>> triangle_area(-1, -1, -1) == -1
True
>>> triangle_area(float("-1.1428"), float("-1.1428"), 1) == -2.2857
True

>>> triangle_area("5", "6", "7") == 3
True

A:

You can't have a triangle in python. Here are some things you can do: 
1) use a library for geometry calculations instead (tricon, matplotlib.tri)
2) use the triangle inequalities:
the_triangle_inequality(a, b, c) = (b*b + c*c) - (a*a + b*b + c*c) < 0
3) you can just make it up :)

