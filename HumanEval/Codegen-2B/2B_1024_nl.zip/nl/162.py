
def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    if text:
        return ':'.join([random.SystemRandom().md5(text).hex()[:16]
                         for _ in range(16, 36)])
    return None


class CachedResponse(object):
    """A custom response that we can keep around to prevent multiple requests with
    the same connection to reuse connection objects and thus to not incur
    unnecessary connection timeouts.
    """

    def __init__(self, client, connection_id):
        self.connection_id = connection_id
        self.client = client

        self.original_scheme, self.original_url = connection_id, None
        self.original_response = None

    def __getstate__(self):
        return None

    def __setstate__(self, state):
        """Make sure the connection_id is not clobbered on state
        reload(CachedResponse)
        """
        del self.connection_id

    @property
    def _connection(self):
        if self.original_response:
            return self.original_response.connection
        else:
            return get_unused_connection(request=self.client.request,
                                         redirect_location=self.original_url)

    @_connection.setter
    def _connection(self, connection):
        """Set the original connection object."""
        self.original_response = connection

        self.connection_id = self._connection.connection_id
        self.original_scheme, self.original_url = self._connection.original_scheme, self._connection.original_url

    @property
    def state(self):
        if self.original_response:
            return self.original_response.state
        else:
            return HttpResponseNotModified

    @state.setter
    def state(self, value):
        """Set the response body or set the response headers if body is set
        """
        if value is not None:
            if value is HTTP_OK and self.original_response:
                self.original_response.body = value
            elif self.original_response is None:
                self.original_response = HttpResponse.__new__(HttpResponse, value)

        self.state = value


class Cookie(object):
    """
    A helper decorator which allows access to cookie data in an easy fashion.
    """

    def __init__(self, name, value, path_info, domain, secure, httponly):
        self.name = name
        # Default to "secure" in the absence of any of other parameters
 