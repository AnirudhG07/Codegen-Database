

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    x = 0
    y = 1

    while x < n:
        x, y = y+x, y+x-1

    return y


class Solution:
    def fib(n: int) -> int:
        """
        :type n: int
        :rtype: int
        :return: fib number
        """
        if n > 0:
            return fib(n-1) + fib(n-2)
        return 1
