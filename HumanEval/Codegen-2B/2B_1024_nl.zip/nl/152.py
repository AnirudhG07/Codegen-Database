
def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    
    
    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    if game[0]-game[1]!= guess[0]:
        return game[0]-game[1], guess[0]
    elif game[1]-game[0]!= guess[1]:
        return guess[1], game[0]-game[1]
    elif game[2]-game[0]!= guess[2]:
        return game[2]-game[0], guess[2]
    elif game[3]-game[0]!= guess[3]:
        return game[3]-game[0], guess[3]
    elif game[4]-game[0]!= guess[4]:
        return game[4]-game[0], guess[4]
    elif game[0]-game[1]!= guess[5]:
        return game[0]-game[1], guess[5]
    elif game[2]-game[0]!= guess[6]:
        return game[2]-game[0], guess[6]
    elif game[3]-game[0]!= guess[7]:
        return game[3]-game[0], guess[7]
    elif game[4]-game[0]!= guess[8]:
        return game[4]-game[0], guess[8]
    return 0, 0

A:

The factorial algorithm is the most simple recursive algorithm  (and the most simple algorithm in the list). It works by counting how many times the base case (the number 1) is called, and multiply the number of times by the recursive call. For example, the algorithm for factorial(5) would be 5, 0, 0, 0, 0. (It's called 5 times, the base case is called once, and 0 times). It's not recursive, but it's a recursive algorithm.

