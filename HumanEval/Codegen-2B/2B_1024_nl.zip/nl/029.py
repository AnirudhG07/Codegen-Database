from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    new_list = []
    for item in strings:
        m = prefix.match(item)
        if m:
            item = item[len(prefix):]
            new_list.append(item)
    return new_list


