
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    primes_to_check = [2, 3, 5, 7, 11]
    while not len(string) in primes_to_check:
        primes_to_check = [2, 3, 5, 7]

    return len(string) % len(primes_to_check)!= 0

I was recently testing out some problems with python on Codecademy, and encountered an error that I have been unable to resolve for the past couple of days.
I am wondering if anyone has encountered this error and if so how did they resolve it.

A:

I think the best solution you can use is to take a string parameter for calculating prime number length and it will return that prime number length as a function as well.
from math import *
