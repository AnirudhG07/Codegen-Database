
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    def count(arr, num):
        if num == 0:
            return True
        elif not (num // 4) < -1:
            return False
        elif num == -1:
            return False
        else:
            for d in [sum(int(int(x)) - 1 for x in a) for a in arr if x % 4!= 0]:
                if d < -1:
                    d = -1
                count(arr, d)
                if d < 0:
                    d = 0
            return True
    return count(arr, num)

print(count_nums([]) == 0)
print(count_nums([]) == 0)
print(count_nums([]))
print(count_nums([7], 9))
print(count_nums([1, 7, 4, -8, 0, 4], 12))
print(count_nums([1, 3, 6], 10))
print(count_nums([0, 34, 0, 1, 4, 3]), len(array_size(len(arr), 4)))
print(count_nums([-12, 0, -11, 4, 2, 0, 1, -2, -18, -2, -2, -7, 0, -8], 15))

count_nums([], -1) == 1
count_nums([0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0], 24) == 4

I'm also trying to understand why the last three lines are returning False. I understand the first two because of the return True for d == -1, but for the last two return false for the first return True for d!= -1, but the condition checks are evaluated in sequence? Therefore, this should be True for the last two return statements, but only True for the last statement.
Is this the output expected? I feel like this is still too simplistic an example to expect a correct answer.

A:

count_nums([],[]) == 0 is going to be False because [] == 0; that is, 0 == 0 and False is never assigned to True.  That being said, -1 == -1 is False.  You may want to clarify your question to make sure you understand what you're doing.
count_nums([], -1) == 1

is False because count_nums is just checking the condition; if the first number is not -1, then the result is True; if the first number is -1, then the result is False (indicating that the array passed to count_nums contains an element equal to -1).  Note that this still produces a value of True for the first number to be equal to -1, and False for any other number to equal -1.
count_nums([7], 9) == 3

is True, because both conditions, d!= -1 and d < 0, are True.  Note that your code never checks d < 0, as in the second line of code, which is why the second line outputs False under the first condition