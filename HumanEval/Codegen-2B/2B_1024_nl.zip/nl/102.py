
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    x = abs(x)
    y = abs(y)
    largest = -1
    for n in range(-1, x, 2):
        if n >= y:
            largest = n
    for n in range(x, y-1, -2):
        if n >= x:
            largest = n
    return largest

A:

Try to see if you understand this: 

Your goal is to find the "number"

If so then (n+1)2 < ((n+1)2 + (n-1)2) Then use (n+1)2.

Try to do this:

If m is the biggest one, then (m+1)4 should be bigger than m *
  (m+2). By the way you can think that  (max * m) * m ~= m * max
  ~= max. To find the max you can think like (max - n) = m. (and the
  answer of the max will be (m + 1)

If you don't understand the last step try to write  (max - n) = max + n
Try to understand first the part of your question which is trying to find the highest integer in the range defined by the 2 parameters.
You have to understand this process by writing it, then try to understand your code. So let's come back to what we are trying to do.
Let's see how the algorithm can be extended to higher numbers.
max = -1
    for xn in range(2, n):
        for xm in range(2, m):

            largest_difference = (xn-xm) * (xn+xm)

            if (largest_difference) < max_difference:
                max_difference = (xn-xm) * (xn+xm)
                max = xn

