
def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''
    if not isinstance(lst, list):
        raise "Input value is not a list."

    # If list has an equal number of duplicates of each number,
    # return True
    if len(set(lst)) == len(lst):
        return True

    # If list has less than 1 distinct number, return False
    if not n:
        return False

    # Iterate through the list from the smallest number to largest
    num_sorted = 1
    for num in lst:
        if num_sorted < len(lst) or num in lst:
            continue
        d = sorted(lst)
        for num_i in d:
            if num_i == len(lst):
                return True
            if not n == num_i:
                return False
            else:
                num_sorted += 1
    return False

This is a good point to note too, that in the end, that for an in-place version, the for loop can still be faster in certain cases. I'd only bother considering an indexing by hand if the algorithm is so much slower that you couldn't otherwise do anything else, eg: if you had 1000000 elements and the comparison took longer than the loop itself.

A:

Some general considerations about lists.

list is a type. No more, no less. If you are passing in a list to a built-in function that takes byreference, then by convention (since Python2.1) the caller should also use byreference, so they should be the same list. However, passing lists by value often results in unexpected behavior. For example, it is quite common to pass strings to functions which expect lists of characters, where it is the string that is copied, not the list. (The exception here is that strings are immutable; there is no chance that they'll be modified and changed unintentionally when they're passed by values.)
n < len(ls) will be True if the given list contains the number or more than the length of ls.
for a in b: will be faster if iterable b really is iterable and iter is a reasonable speed-critical function. Since this is not guaranteed to always be the case, it is generally not faster unless you really have a large list of numbers: a list of 10^4 elements really takes longer.

In your exact example, we could write:
import itertools
