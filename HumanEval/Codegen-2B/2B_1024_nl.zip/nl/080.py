
def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """
    if len(s) == 1:
        return s in ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3"]
    else:
        return [s[j]+[s[j+1]]+[s[j+2]]+[s[j+3]] for j in xrange(len(s))] == [3,3,3,3]

print(is_happy("abc"))
print(is_happy("ghi"))
print(is_happy("xyz"))

Output
False
False
True

Python 3.6.4

A:

Here is a complete recursive implementation, which returns True if the input string is happy:
