

def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    if not isinstance(l, basestring):
        raise TypeError('{} value is not a string'
                        .format(type(l).__name__))

    def f(i):
        return max(i - l[i - 1], l[i]) if i >= 1 else l[0]

    return max(v, f, lambda x, y: None if x <= y else 1)
