
def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    if x < 0:
        throw "Error..."
    if n < 0:
        raise "Error..."

    result = x%n!= 0
    while x!= 1:
        result = result and n%i!= 0 for i in range(1, n)
    return result

A:

Pythonic style
I just wanted to point out that the first few lines of your code appear to be pretty readable without having to look at the comments, I might not be the target audience for your library.

There are a lot of comments:

This function is called is_simple_power() and has the docstring is_simple_power()
You've imported the math library, you haven't done it with your class.

Your class implementation isn't much:

There is no need for class.
You're not using the docstring to provide a proper docstring.
For a class with just two methods, there is no need for a docstring.

You've implemented a function whose class doesn't instantiate a cls argument, nor any other arguments to it by default.
Instead you're using some instance variables whose names hint at their possible purpose, but never get fully used.
Is that intentional? To make the intention of your function more obvious? It would have been better not to use any names.
You could have used these variables instead:
self._n
self._x

Is this a proper function? I haven't found out your true intent. For example, do you really want to return None?
Your implementation doesn't reflect much of the actual problem, but more on the algorithm you've chosen to use, which isn't obvious:

You've implemented this function using a loop that checks the power of
its parameters step by step. There is no need for a loop here. With that
solution, you'll see that the function is slower than a simple
comparison, but it's just a simple comparison. Can you be sure that the
slowness of the second implementation is not due to the fact you've used
a lot of comparisons in it?
You've implemented the algorithm twice, once to find an index of the
number (which is the power of the number), the second to find out if the
number is prime. Can you be sure this is the best solution?
Can you be sure to use the exact same type argument n? Maybe there is
a possible edge case where n is larger than n**... and can be mistaken
for an integer.

