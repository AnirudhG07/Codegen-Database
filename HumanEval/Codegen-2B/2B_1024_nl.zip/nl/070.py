
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    sorted_ints = []
    for i in lst:
        max = int(i) if i > lst[-1] else lst[-1]
        sorted_ints.append(min(max, lst))
    return sorted_ints

class my_class(object):
    def __init__(self):
        self.max = 0
        self.init_max = max(self)

    def add(self, n):
        self.max += n
        self.init_max = max(self)

if __name__ == "__main__":
    num_list = [1, 3, 4, 6]
    my_obj_obj = my_class()
    my_obj_obj.add(9)
    my_obj_obj.add(6)
    strange_sort_list(num_list)
    print(my_obj_obj)

Output:
[1, 6, 3, 4].
my_obj_.max = 1
my_obj_.init_max = 2

[my_obj_obj.__dict__ = <attribute 'init_max' of'strange_sort_list' object at 0x7fe0555dd3d0>, 1, 5, 0, 4, 6, 0]

