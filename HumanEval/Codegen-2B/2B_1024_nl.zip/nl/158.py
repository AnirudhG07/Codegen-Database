
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    if len(words) == 1:
        return words[0]
    if len(words) < 2:
        return words[0]
            # print "len(words) %d" % len(words)
    for i in range(1, len(words)+1):
            c = len(set(words[i]) - set(words[i-1]))
            if c == 0:
                break
            elif c == 1:
                words[i] = words[i-1]
                break
            else:
                words[i+1] = words[i]
    max_len = len(words[len(words)-1])
    return words[len(words)-1] if max_len == len(words[len(words)-1]) else None


if __name__=='__main__':
    from timeit import default_timer as timer
    max_size = 32
    max_dict = max(map(len, open(max_size, 'rb').read().strip().split('\n')))
    sizeList = []
    for i in range(1, max_size + 1):
        sizeList.append(len(open(i, 'rb').read().strip().split('\n')))

    sizeList = sorted(sizeList)

    print '%s' % max_dict, '< %d' % (max_size, max(" ".join(sizeList))))
    d = {}
    sizeStr = dict((k, v) for k, v in sizeList)
    for word in "hello":
        d[word] = 1
    for n in range(50):
        n, n2, n3 = n * 2, n * 3, n * 4
        d[str(n)] = 0
        d[str(n2)] = 0
        d[str(n3)] = 0
    if __name__=='__main__':
        for key in sorted(d, key=lambda x:x):
            print key, sorted(d[key])

    find_max([])
    print '%d' % find_max('zzzccccc')