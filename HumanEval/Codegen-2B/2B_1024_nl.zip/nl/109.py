
def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2],..., arr[N].The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing 
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.
    
    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index. 

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.

    For Example:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: By performin 2 right shift operations, non-decreasing order can
                 be achieved for the given array.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation:It is not possible to get non-decreasing order for the given
                array by performing any number of right shift operations.
                
    """
    # The algorithm which is not working
    def sort(arr, shift):
        temp = {}
        # print(arr)
        # print(shift)
        sorted_arr = len(temp)
        for i in arr:
            if (i in temp):
                # print(sorted_arr)
                # print(i)
                shift(i, s)
                # shift(i+1, s)
                # shift(i-1, s)
            else:
                # if i is not in the temp, add it to it
                temp[i] = True
        # print(temp)
        sorted_arr = len(temp)
        # print(shift(sorted_arr-1, (1, 0, 0)))
        return sorted_arr - shift(arr.pop(0), (1, 0, 0))

    return not sort(arr, 0)

if __name__ == '__main__':
    print(__name__)
    print(__file__)
    print("---------------------")
    print("Main Entry")
    print("---------------------")
    print(__class__)

    arr = [1, 2, 3, 4, 5, 6]
    print("The array is:", arr, "with indices", len(arr), "and values", arr[len(arr)-1])

    if move_one_ball(arr) == True:
        print("Function Success")
        print(arr)
    else:
        print("Function Failure")

    else:
        print("Function Success")

    print(__name__)

    print(__file__)
    print("---------------------")
