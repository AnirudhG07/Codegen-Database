

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if base > 10:
        raise ValueError('base must be < 10')
    if 10 <= base and int.digits:
        raise ValueError('base must not be 10')
    if base > 0:
        x *= 10
        while x % base!= 0:
            x /= base
    else:
        x *= base
    return str(x)

print(change_base(3, 3))
print(change_base(8, 3))
print(change_base(3, 2))
print(change_base(8, 2))        

# output
# 3'3
# 8'3
# 11'3
# 222'3

