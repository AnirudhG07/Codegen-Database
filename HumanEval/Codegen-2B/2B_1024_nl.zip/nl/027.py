

def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """
    return string.upper().lower() if string.index(string[::-1])!= len(string) else string.lower()

@precedence(operator.is, operator.eq)
