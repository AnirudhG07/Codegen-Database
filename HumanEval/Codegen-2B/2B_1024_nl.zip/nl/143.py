
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    input_s, output_s = _parse_str(sentence), "", word_comp = [], []
    _count_words_in_sentence(input_s, output_s)
    _sort_words_in_sentence(input_s, output_s)
    words_in_sentence = []
    while True:
        _check_prime(input_s)
        words_in_sentence.extend(output_s)
        input_s = word_comp.pop(0)
        word_comp = input_s
        output_s_new = _process_word_in_sentence(input_s, output_s)
        words_in_sentence.extend(output_s_new)
        print("W: {}  o: {}".format(words_in_sentence, output_s_new))
        output_s = output_s_new
        input_s = word_comp.pop(0)
        word_comp = input_s
        if len(words_in_sentence) >= word_count:
            break

