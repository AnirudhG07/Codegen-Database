from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    # TODO: use binary search for most efficent time complexity?
    def iterate(value):
        if value in numbers:
            yield value
        elif number not in numbers:
            for x in numbers:
                if value < x:
                    yield value
                    break
            if value == greatest(numbers):
                yield value
        else:
            x = number
            while numbers:
                if x in numbers:
                    yield value
                    x = number
                    break
                x = highest(numbers)

    yield next(iterate(x))

    return remove_duplicates(numbers=list(map(next, iterate(x))))


