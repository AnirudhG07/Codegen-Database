
def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.

    Example:

        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """
    return sum(i for i in arr[:k] if len(i) <= 2)

for n,k in enumerate(itertools.combinations(range(101,100),4)):
    print(add_elements(map(int,input().split( " ")),k),end=" ")

The program displays the following output (assume the order doesn't really matter!) :

20
27
21
24
22
24
23
26
25
26
27
28
2
3
4
5
6
7
8
9

Now, as stated in the problem, we will be using the itertools module. There's actually another issue which we have on which we will do that next problem : why does input().split(" ") work even when we don't give any argument? I'll talk about that later.
As I said, I would like you to focus mostly on the python coding and the itertools module. And you can use the Python 3 itertools import. 

