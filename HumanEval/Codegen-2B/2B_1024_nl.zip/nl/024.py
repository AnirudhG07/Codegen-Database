

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    n /= 1000000007
    # n /= 10000
    n /= 50
    n /= 10
    n /= 5
    n /= 2
    n = n % 1
    for divisor in [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2000, 2048, 1024, 32, 32]:
        if divisor * n >= n:
            break
    return divisor

# Initialized at the start of the function (if not at first call)
n = 1000000007
c = len(str(n))
print(largest_divisor(n))

And here is my output:
2
3
50
5
8
4
16
7
64
15
4095

As you can see it will not terminate for an input n > 128. When the input would already be exactly 128, it wouldn't enter the loop even at all. I don't know what's wrong. Anyone can help please?

A:

Because the input to the largest_divisor function is 1000000007 there's no remainder from the modulo operation, which is why it will never enter the loop.
If you can get the exact result of that division you then just use the largest, which is n / n / n / n.

