
def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """
    assert 1 <= n <= m, 'The range you want to calculate the average in'\
        'is 0 <= n <= m'
    binString = ""

    sumUpTo = (n + m - 1) * (n + m - 1)
    currentSum = 0
    lastNumber = -1
    while currentSum <= sumUpTo:
        nextX = currentSum / 2
        nextY = currentSum % 2
        x = int(nb((nextX + n) % m))
        y = int(nb((nextY + m) % n))
        if x == -1:
            nextX += 1
            lastX = x
            continue
        if y == -1:
            nextY += 1
            lastY = y
            continue
        currentSum += int(x) + int(y)
        binString += nb(int(x)) * nb(int(y))

    return binString

