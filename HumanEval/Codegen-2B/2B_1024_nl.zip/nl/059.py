

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    result = 2
    while n:
        m = ceil(math.sqrt(n))
        q = n % m
        if m == 1:
            result = n
            n -= 1
        else:
            if m % 2 == 0 and n % m!= 1:
                result = m * result
                n -= m * result
            elif m % 2 == 1 and n % m!= 1:
                result = 2 * result
                n -= 2 * result
            else:
                result = m * result
                n -= m * result
    return result


# From http://www2.maths.hants.ac.uk/~nj/njhtml/misc/fun/prime/prime.html

