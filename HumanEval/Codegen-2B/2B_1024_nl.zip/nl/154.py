
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    A,B = a.split(b)
    for i in range(len(A)):
        if b.index(A[i]):return True
    return False
'''

class Solution:
    def checkIfSubStr(self, a, d):
        if d not in b:
            return False
        ans = []
        for i in range(len(a)):
            if (d in a[i:]) or ((a[i:] in d) and (i == 0)):
                ans.append(True)
        return bool(p.join(sorted(ans))==a)

A:

This is a nice puzzle, and my Python is rusty but this seems like a solution for a brute force approach:
