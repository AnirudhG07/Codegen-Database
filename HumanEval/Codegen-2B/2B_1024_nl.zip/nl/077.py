
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    # Test validating the arguments...
    if len(a) not in range(1, len(a)+1):
        return False
    #...and generating a cube representation to pass to the 
    # comparison function.
    x = [0 for i in range(len(a))][:]
    for i in range(len(a)):
        x[i] *= x[i-1]
    return x == a


