
def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """
    n = int(n)
    if n in (0, 1):
        if n < 2: return []
        else: return [n]
    elif n in (2, 4, 6, 8):
        return [list(a) + [n * 2 - 1] + list(a) for a in zip(map(int, str.ascii_uppercase[i:i + 2]), a) for i in range(len(a) - 1)]
    elif n == 0: return []
    else: return [[i] + [i*2] for i in range(len(a) - 1)]

A:

You have a stack, the first level of which is empty and the second level is a single stone.

For each number in the array, you add the number to the stack of all stones in the pile:
    stack = [...]
    for j in range(n): # add n on the stack
        stack = [x + j for x in stack] # remove the top number from the top of the stack and stack it at the bottom

Here's a complete run of that algorithm, using your example array:
n = 1
[n] + 1
[1] + [2]
[1] + [3]
[1] + [4]
[1] + [5]
[1] + [6]
[1] + [7]
[1] + [8]
[1] + [9]
[1] + [10]
[1] + [11]
[1] + [12]
[1] + [13]
[1] + [14]
[1] + [15]
[1] + [16]
[1] + [17]
[1] + [18]
[1] + [19]
[1] + [20]
[1] + [21]
[1] + [22]
[1] + [23]
[1] + [24]
[1] + [25]
[1] + [26]
[1] + [27]
[1] + [28]
[1] + [29]
[1] + [30]
[1] + [31]
[1] + [32]
[1] + [33]
[1] + [34]
[1] + [35]
[1] + [36]
[1] + [37]
[1] + [38]
[1] + [39]
[1] + [40]
[1] + [41]
[1] + [42]
[1] + [43]
[1] + [44]
[1] + [45]
[1] + [46]
[1] + [47]
[1] + [48]
[1] + [49]
[1] + [50]
[1] + [51]
[1] + [52]
[1] + [53]
[1] + [54]
[1] + [55]
[1] + [56]
[1] + [57]
[1] + [58]
[1] + [59]
[1] + [60]
[1] + [61]
[1] + [62]
[1] + [63]
[1] + [64]
[1] + [65]
[1] + [66]
[1] + [67]
[1] + [68]
[1] +