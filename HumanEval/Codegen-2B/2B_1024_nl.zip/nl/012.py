from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    longest = None  # type: Optional[str]

    if not strings:
        return None  # type: ignore[arguments]
    if not isinstance(strings, List):
        strings = [str(x) for x in strings]

    for i in range(len(strings)):
        if len(max(strings[0:i + 1])) < len(strings[i + 1]:
            longest = strings[i + 1]

    return longest


