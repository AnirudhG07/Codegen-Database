

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    pairs = ""
    for i in range(1, len(brackets)):
        pairs += brackets[:i] + "( " + brackets[i:] + ")"
    if not pairs.endswith(")("):
        return False
    return pairs == brackets[len(brackets)-1] + " (" + brackets[-1:] + ")"


