
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    return nums[len(nums)-1] in [-10, 10]


###############################################################################
# Solve the above problem for the case where the list can contain duplicates.
# Also, handle the case where number can be repeated, like: 
#   -2, -1, -10100, 10100
# Input:
#   nums, k – The array of numbers to check for duplicates.
#   nums, k – Integer, number of duplicates to find. Default is 1.
#   Output:
#   nums – The original array.
