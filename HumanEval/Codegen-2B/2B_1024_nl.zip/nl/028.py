from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return ''.join(strings)


class DictTest(object):
    @staticmethod
    def test_values_in_order():
        """
        Check if keys are in order in a dictionnary given by the function
        :param dictionary:
            ``sorted({'a': 'b', 'c': 'd'})`` -> ``{'a': 'b', 'c': 'd'}``
        """
        d = sorted({'a': 'b', 'c': 'd'})
        d = list(d)
        result = dict(d)
        assert {'a': 'b', 'c': 'd'} == result

    @staticmethod
    def test_keys_order():
        p,q,x = [1, 2, 3], [4, 5, 6], [7, 8, 9]
        dict(zip(p, q, x))
        p,q,x = [4, 1, 5], [5, 2, 8], [9, 3, 7]
        dict(zip(p, q, x))
        assert {1: [2, 3], 2: [3, 4], 3: [4, 5], 4: [5, 6], 5: [6, 7], 6: [7, 8], 7: [8, 9], 8: [9, 9], 9: [9, 9]} == dict(zip(p, q, x))

    @staticmethod
    def test_concatenate_items_order(a):
        a = ['x', 'y', 'z']
        s = a + a
        sb = s.split()
        assert {1: 2, 2: 3, 3: 4} == sorted(a) == sorted(sb)

    @staticmethod
    def test_append(a, b):
        """Check the order of appending multiple values
        >>> {'key': ['value',]}.append('key')
        >>> {'key': ['value']}.append(['key'])
        >>> {'key': ['value']}.append(['value'])
        """
        s = a.__str__() + list(b)
        assert {'key': ['value']} == a
        assert {'value': [None, '']} == b

        from rpython.rlib.runeval import ui_to_bytes
        s = s.encode('utf-8')
        assert {'key': ['value']} == a
        assert {'value': [None, '']} == b

        assert {'key': ['value']} == a

        assert {'value': [None, '']}.append(['value']).append(['key'])

    @staticmethod
    def test_append2(a, b):
        """Check the order of appending multiple values to a container
        >>> {'key': ['value']}.append(['key1',] + ['key2'] + ['key3'])
        >>> {'key': ['value']}.append([['key1'], 'key2', '