

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    if not (all((i < 0 or i > end_): (elem in l for elem in l))):
        raise ValueError("expecting list with finite size")
    if len(l) <= 1:
        raise ValueError("list must be non-empty")
    if len(l) == 2 and l[1] > l[0]:
        return l[1]
    # Otherwise, return the average of the two middle elements.
    mid = (end_ * 0.5) + (len(l) // 2)
    n = max(1, len(l) - 1) - mid
    if n == 0:
        raise ValueError("list must be positive and larger than 1")
    return (l[mid] + l[len(l) - 1]) // 2
