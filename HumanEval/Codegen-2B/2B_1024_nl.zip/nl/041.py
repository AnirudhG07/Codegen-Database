

def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """
    count = 0

    for _ in range(n):
        car_left = car_right = 0

        for idx in range(4) - n:
            if idx < n and _ == 0:
                car_left += 1
            elif idx > n:
                car_right += 1

            if car_left == car_right:
                print("collide")
                count += 1

    return count

A:

if you want to do this in a compact form, I'd do something like bellow. For example, imagine two cars are A_car and B_car. The program will output the number of times they will collide.
    import sys
    n = len(sys.argv) - 1
    for i in range(n):
        sys.stdout.write(str(collidation_function()))
    sys.stdout.write("\nyes\n")

# This function checks the collisions of two cars

collision_function()

Hope this helps.

