

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    h = np.sqrt(h**2)
    q = a * h / 2
    return q * (a - sqrt(h**2 - q**2)) / 2.0


if __name__ == "__main__":
    import doctest

    doctest.testmod()
