
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello!!!Wdlor'
    """
    def anti_shuffle(s):
        return re.sub(" ", "A", s, flags=re.ASCII)
    return anti_shuffle

My code doesn't work at all, and I don't understand why.
Also, if someone could help me understand, why does it work if I have the function as a standalone?

A:

Your code is correct, and the following program should work the way you intended:
>>> import re
>>> def anti_shuffle(s):
        return re.sub(" ", "A", s, flags=re.ASCII)

>>> re.sub(" ", "A", "Hello World!!!")
'AHello!!!Wdlor'

Notice the change of "Hello World!!!" to "Hello World!!!".

