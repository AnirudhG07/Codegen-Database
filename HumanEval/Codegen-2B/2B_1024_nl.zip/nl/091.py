
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    boredoms = []
    found = False
    while not found:
        try:
            boredom = S.split('.')[0],
            # try:
            #     boredom = S.split('?')[0],
            # except IndexError:
            #     boredom = 'I'
            found = len([
                a for (i, (a, b)) in enumerate(zip(s, S.split('!')[:boredom]) if b == int(boredom),)]
        except IndexError:
            # found = len(S.split('.')) - len(S.split()[:boredom + 1])
            # found += len(S.split()[boredom + 1].replace('I', 0))
            found = len(S.split()[:boredom + 1])
        boredoms.append(int(boredom))
        S = S[1:] if S!= [''] else ''
    print('There are {} boredom sentences.'.format(sum(boredoms)))
    return sum(boredoms)


if __name__ == "__main__":
    from textblob import TextBlob
    T = TextBlob(["My name is _________, and I'm proud to be so. I'm pretty",
                  "sure I sound silly."])
    print(is_bored(T))
    print(is_bored("I am bored. And you should be too!"))
