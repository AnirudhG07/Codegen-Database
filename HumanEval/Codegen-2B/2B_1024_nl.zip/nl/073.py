
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    arr_size = len(arr)

    def smallest_change_count(arr_size):

        if arr_size == 1:
            return 0

        if arr_size == 2:

            result = 0

            while arr[0]!= arr[1]:
                smallest_change_count(arr_size - 1)

                result += min(smallest_change_count(arr_size - 1), smallest_change_count(arr_size - 2))

            return result

        print(Smallest_Change_count())

        result = 0

        while len(arr) > 0:
            if arr[0] == arr[len(arr)-1]:
                print(len(arr))
                break

            result += smallest_change_count(len(arr) - 1) + smallest_change_count(len(arr) - 2)

        return result

    return smallest_change_count(arr_size)

array = [1,2,3,5,4,7,9,6]

print(smallest_change(array))

A:

You could first sort elements (in-place):
smallest_change(array):
    def smallest_change(arr):

        arr_count  = len(arr)
        arr_sorted = sorted(arr)

        return (max(arr_count, (min(arr_count, len(arr_sorted)) - arr_count))/2)

