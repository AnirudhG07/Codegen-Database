

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    while not B_LT_0(a, b):
        if a < b and a % B_LEAST_COMMON_DIVISOR(a, b) == 0:
            return B_LEAST_COMMON_DIVISOR(a, b)
        if b < a and a % B_LEAST_COMMON_DIVISOR(a, b) == 0:
            return B_LEAST_COMMON_DIVISOR(a, b)

    if a == b:
        return B_LEAST_COMMON_DIVISOR(a, b)
    return B_GT_0(a, b)
