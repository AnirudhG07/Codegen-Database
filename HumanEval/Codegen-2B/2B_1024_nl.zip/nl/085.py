
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    i = 0
    while lst[i] < 0:
        i += 2 # change this if you want to add both first and last elements to 0 instead of last one
    return i + 0  # add all even index elements to the value at index 0.

