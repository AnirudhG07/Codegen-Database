
def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''
    if len(lst) == 0:
        return (None, None)
    low = min(lst)
    high = max(lst)
    # we have two lists: a and b
    if low <= 0:
        return (None, low)

    if high > 0:
        return (high, None)
    else:
        return (None, None)

# Make two lists
lst =  ["2", "1", "4", "3", "5", "7", "10", "-1", "-7"]
lst2 = lst[:]

try:
    largest_smallest_integers(lst)
except ValueError:
    print (largest_smallest_integers(lst2),largest_smallest_integers(lst))

The output of this is:
(None, 1) (None, None)

A:

The following code should work. It creates a second list by starting at the highest number, and then removing every number after the high point:
