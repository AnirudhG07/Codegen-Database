
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    # is it prime?
    if a == 2 or a == 3:
        return False
    # 3 prime factors, only 3
    for prime_factor in prime_factors(a):
        a = a / prime_factor
        if 6 * prime_factor == a:
            return True
    # too many prime factors
    else:
        return False


