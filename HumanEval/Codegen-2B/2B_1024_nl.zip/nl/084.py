
def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """
    if N < 10:
        return N
    ansi = [bin(x)[2:] for x in str(N)]
    return list(map(sum, ansi))

if __name__=="__main__":
    print(solve(100))

My input is:
N=100
answer = ["1"]
the output is [10111000010100]

How can I get it correctly to output:
answer = ["1000"]

Thanks for the help!

A:

This was actually really simple and embarrassingly bad written code. However I will explain my thought process on how to write it.
The output of the program should be a binary string. Therefore I used the bin method of string to convert the value. Thus I use the method in str to generate each binary digit in the string. This generated a list of the string. I then use another method in list to sum each bin of the list of str. This provides me the desired output.
N = 100
answer = [str(x)[2:] for x in str(N)]

The issue now is that this produces an output that contains some negative values that are not in the right range. I had to cast those values to a long after getting each bin in order to fix this and get the desired answer.
N = 100
answer = [list(map(int,x)) for x in str(N)]

I then converted the bin strings to long after getting each bin in order to cast the negative values to long. The other issue remained since this was not correct.
For the incorrect behavior, use the following to fix it:
answer = [bin(x) for x in str(N)]

