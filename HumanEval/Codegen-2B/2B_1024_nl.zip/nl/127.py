
def intersection(interval1, interval2):
    """You are given two intervals,
    where each interval is a pair of integers. For example, interval = (start, end) = (1, 2).
    The given intervals are closed which means that the interval (start, end)
    includes both start and end.
    For each given interval, it is assumed that its start is less or equal its end.
    Your task is to determine whether the length of intersection of these two 
    intervals is a prime number.
    Example, the intersection of the intervals (1, 3), (2, 4) is (2, 3)
    which its length is 1, which not a prime number.
    If the length of the intersection is a prime number, return "YES",
    otherwise, return "NO".
    If the two intervals don't intersect, return "NO".


    [input/output] samples:
    intersection((1, 2), (2, 3)) ==> "NO"
    intersection((-1, 1), (0, 4)) ==> "NO"
    intersection((-3, -1), (-5, 5)) ==> "YES"
    """
    if (interval1[1] == interval2[0] or interval1[0] == interval2[1]):
        return "YES"
    elif (interval1[0] == interval2[1] or interval1[1] == interval2[0]):
        return "NO"
    else:
        return "NO"
```

**Example**::
Example 1_Intersection_instructions.txt
```python
    # An example of given intervals is: (1, 2), (2, 3), (3, 20)
intersection((1, 2), (2, 3), (3, 20)) ==> "NO"
```

## Problem 7.8

Consider the equation *y* = 4 * x \+ 1; the solution to this equation is 2; so what is the value 2^2 × 2^3; we will call this value *x*? Hint: we can use the factorization rule to factorize 2^2 and 2^3.



## Solution

<!--Teacher's Solution:

We can factor as

```python
x = 2
x = 2**2 * 2**3
x = (2*2)(2*3)

2^2 x = (2^2)(2 x)
2^2 x = (2^5) (2 x)
2^2 x = (2^5) (2 * 4 **(3/2))
2^2 x = 2^5 * 2 * 4 **(3/2)
\text{  or } 2^2 * 4 * 5 * 5 * 5 * 2 ^(3/2)  = 2^8 * 2
3 * 2^8 = 72
72 = (5 * 18)^2 8^2;
72 = (5 * 18/7)^2 * (8/7)^2
72 = (5  7/8)^2 * 9  7/8

72 = 5  7/8  9/8
```


For the values at the exponent, *y* = 4 * x + 1;

\(4 x\) + (1)/(5  7/8  9/8) = (4 x) + 1/72\]
```python
y = 4 * x + 1;
y = 4 * x + 1;
```
\(y\) + 1/72 = 4 * x  + ((1)/6)2;
```
```python
y = 4 * x + ((1)/6)2;
y = 4 * x + ((1)/72)2;
```
\(y\) + (5/72)2 = 4 * x + (1)/(18)2
```
\(y\) + (5/72)2 = 4 * x + (1)/(9)2;
```
```python
y = 4 * x + (1)/(9)2;
```
\(y\) + (5/72)2 = 4 * x  + (1)/(15)2