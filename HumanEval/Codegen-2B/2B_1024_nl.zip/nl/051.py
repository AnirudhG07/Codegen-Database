

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    if not isinstance(text, str):
        raise ValueError('argument : must be str')
    return text[:0]


class Stopwords(object):
    """
    Stopwords is a class that contains a huge list of stopwords.
    Stopwords class is not a singleton. 
    Use stopwords.words('english')
    to get stopwords
    If stopwords is not assigned to a dictionary, it is a new dictionary for you.
    """

    def _init_words(self):
        """
        _init_words is a function that builds a class instance from a dictionary.
        This function helps to define new dictionary.
        """
        return self
      
    def __init__(self,stopwrds_file):
        # load the words from file
        with open(stopwrds_file,'r') as fp:
            stopwords = csv.reader(fp)
            self.stopwrds = [w.strip() for w in stopwords]
            self.stopwrds = stopwords[:].strip().split()

        # remove the last two list at the end of last line at the file
        lasttwo =  [x for x in self.stopwrds if x in [i for i in self.stopwrds if x.isspace()]]
        self.stopwrds = [stopwrds[i] for i in lasttwo]

        # the most common words in the file is used as key for dictionary
        self.dict = {} 
        
        self._init_words()

