
def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''
    if z:
        if x > z: # we're not in the middle
            return not z
        # z is greater than x + y. otherwise, x > y + z is always False.
        if x + y == z:
            return True
        raise ValueError('z should not be in the middle')
    
    elif y:
        return z == x + y
    elif x:
        return z == x + y
    return False

