
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    def check(string):
        cur_len = len(string)
        try:
            next_len = cur_len - len(string.lstrip('[]')) - len("]]]")
        except ValueError:
            return False

        if 1 < next_len < len(string):
            # there is an even non-zero offset between a single-bracket and multi-bracket
            return ''.join([x for x in string if ('[' in x) and (len(x) == 1)]) in string
        return False

    return check

is_nested('[][]')  # passes, because the entire sequence is in single-bracket strings
is_nested('[][]]')  # passes, because the entire sequence is in single-bracket strings
is_nested('[]]]}]]')  # passes, because the entire sequence is in single-bracket strings
is_nested('[][]][[')   # passes, because the first sequence that's a single-bracket is followed by a two-bracket sequence
is_nested('[]][]][[')  # passes, because the first sequence that's a single-bracket is followed by a two-bracket sequence
is_nested('[][]]][]]')  # passes, because the entire sequence is in a multibracket
is_nested('[][]]]][[')  # returns false, and the last two brackets are nested

This code demonstrates that if any bracket in a subsequence is nested, then the subsequence is too, even if it's part of an unordered sequence like '[[]].
Here is an interactive Python console session:
>>> function = is_nested
>>> function('[[[]])
>>> function('[][]')
>>> function('[]]]][[')
>>> function('[]]]]]]')
>>> function('[]]]]](')
True
>>> function('[]]]})]']');
>>> function('[][]]}']];');
False
>>> function('[[]]]][[')
False
>>> function('[][]][[')
True
>>> function('[][]][[])
False
>>> bool(function('[[]][[')))
True
>>> bool(function('[][]][[]) is False)
False
>>> bool(function('[][]][[]) is operator.eq(False))
False

In other words, the function can never identify the brackets as nested, but it can always determine the sequence of brackets as all nested. How could that be? Here is an attempt:
