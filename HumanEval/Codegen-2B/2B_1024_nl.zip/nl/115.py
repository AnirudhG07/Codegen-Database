
def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """
    # Input
    grid = []
    fill = []
    capacity = -1
    bucket_capacity = -1
    
    bucket_capacity_array = []
    if (bucket_capacity == -1):
        bucket_capacity = grid[-1][0]
        
    if (bucket_capacity == -1):
        raise "invalid_input"
    
    min_b = 0
    max_b = bucket_capacity 
    for i in range(len(grid[0])):
        min_b = grid[i][0]  
        max_b = grid[i][0] 
        
        min_fill = 0
        min_max_fill = math.min(max_b, max_fill) 
        for j in range(len(grid[0])-1):
            min_fill = max_fill
            min_max_fill = math.min(max_b, max_fill)
            if (min_fill == max_fill):
                min_fill = 1
            if (grid[i][j] == 0):
                max_fill = 1
            if (grid[0][j] == 0):
                min_fill = bucket_capacity_array[i]
                min_max_fill = bucket_capacity_array[i]
                if (grid[i][j] == bucket_capacity_array[i]):
          