

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    a = 1
    while (p!=0) and (n <= a):
        a *= p
        n = n-1

    return (a*n)%p

print(modp(99, 101))

A:

It seems that the idea might be to use the remainder of n % p.
Let's start by testing different sizes.
Using p = 9, the code
print(modp(99, 9))
mod = 0        # starting value
step = 3       # step size
for n in 0, 3, 7, 11:
    print(n, step*modp(n, 9))     # check
    mod += step                    # increment mod
    step = -step                   # step size
print(n, mod)

is working fine, with the result (not rounded):

1 0
3 1
7 5
11 17

We can compute the remainder for each number in turn.
print(modp(99, 100))
print(modp(101, 100))
print(modp(109, 100))

Printing the remainder value is not quite as easy as in Python, due to the different behaviour from Python.
print(modp(99, 100))

gives
-3

while the other two return the remainder.
This can be fixed by setting the minimum value of step to 5 (which means we can safely round modp(99, 99) to 1):
print(modp(100, 199))
print(modp(101, 199))
print(modp(109, 199))

So far so good.
Now, let's try for values of step smaller than 5, e.g. 4.
modp(99, 4)
print(modp(99, 4))
mod = 0
step = 4
for n in 0, 2, 6, 15, 20, 27:
    print(n, step*modp(n, 4))      # check
    mod += step                    # increment mod
    step  = -step                  # step size
print(n, mod)

This gives the same result as we always had for the above values of step, so no changes were needed.
We can of course keep the rest of the steps the same if we want the values rounded.
print(modp(45, 4))
print(modp(46, 4))
print(modp(59, 4))

So far so good.
Now step is set to 2, but it gets tricky.
print(modp(99, 2))
# modp(0, 2) is still one in IEEE 754,
# so we want modp(0, 2) == 1 % 2 == 1
print(modp(99, 2))
# modp(0, 2) is still one,
print(modp(99, 2))
# modp(0, 2) is still 0

We have to find the solution for step = 1. But in the worst case it can be at most 3, and then the remainder value can overflow. (When step = 1 modulo p is zero it is also equal to the remainder value, but only when both modulus and remainder value are whole numbers, here I'm not sure which value wins in that case.) So I won't be able to give a better solution than this:
