
def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """
    lst1 = list(lst1)
    lst2 = list(lst2)
    for x in lst1:
        if x in lst2:
            lst1.remove(x)
            lst2.remove(x+1)
    return "YES" if len(lst1) == 1 and lst1[0] % 2 == 0 else "NO"


if __name__ == "__main__":
    print "Exchange Game"
    print "Enter two lists. To remove a number from the list, use: -1; 1 to add a number to the list; 0 to return error. To quit, press 0."
    lst1 = input()
    lst2 = input()
    exchange(lst1, lst2)
