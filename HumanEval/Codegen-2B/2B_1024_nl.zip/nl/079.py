
def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    binary = ''
    maxsize = max(map(len, decimal.as_tuple()))
    decimal = math.floor(decimal)
    for i in range(len(decimal)):
        if len(decimal) <= i*4:
            binary += 'db'
        else:
            b = decimal % 2
            decimal = (decimal // 2)
            remainder = decimal % 2
            binary += chr(b) + chr(mod(int(i+1),2))
            decimal = decimal + 1
            decimal %= 2
            if remainder:
                binary += chr(remainder)
            binary += 'db'

    print(binary)
    return binary


# In this example we will find the prime factors of a number:
n = 3
a = 2
b = 3
a1 = 2
b1 = 3
for b in range(2, int(n**0.5)+1,2):
    if n%b1 == 0 or n%b == 0:
        break
else:
    print(n)
    print(a)
    print(a1)
    print('Factorization of:'+ str(n))
    
