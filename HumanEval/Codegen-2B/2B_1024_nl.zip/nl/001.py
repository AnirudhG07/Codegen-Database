from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    groups = []
    for i in paren_string:
        if i in ['(', ')', '(()']:
            groups.append(i)
        else:
            if i[0] not in '()(':
                yield i
            else:
                for j in range(i.count(')()') + 1:
                    j_str = i[:j].rstrip('()')
                    yield separate_paren_groups(j_str)

    if groups:
        groups.append(')')
        yield ')'
    return []


