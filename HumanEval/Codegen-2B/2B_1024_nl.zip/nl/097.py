
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    m, k = divmod(a, 10)
    l, n = divmod(b, 10)
    if n == 0:
        return 1
    if m > 0 and n!= 0:
        return 10**k * (10**l) * (10**(l-k)) * m
    if n == 0:
        return 10**(l+m)
    else:
        return 0

So I was hoping that the comments would just show me the exact code for what I'm missing, why is it giving me an indentation error...and what is actually wrong with it? I was just learning Python (still in school) a few days ago. 
EDIT: For those of you wondering how the error happened: It was an indentation error in the if block. Thanks!

A:

It looks like you're trying to add two functions, not code.
Your code is:
