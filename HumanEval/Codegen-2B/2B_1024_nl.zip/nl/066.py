
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    str = s.upper()
    c = 0

    while str!= '\0':
        c += str[c]            #get the sum of upper characters
        str = str[2:]          #remove two more 'a'

    return c

A:

You've got
c += str[c]          

which is equivalent to
c = c + str[c]

The second one updates only c, but then the function returns, so c is never changed in digitSum. If you want digitSum to return c:
c = c + str[c]

But it's really better in your case if you write
return c + str[c]

and return the correct answer.

