
def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    vowels = ["a", "e", "i", "o", "u", "y"]
    consonants_on_right = list()

    i = 0
    dp = len(word)
    while i <= dp:
        if word[i] in vowels:
            s = get_first_consonant(word, i+1)
            j = len(word)
            if s in consonants_on_right:
                j -= 1
            else:
                j -= 2
            vowels_in_span = len(set(vowels) & set(s))
            consonants_in_span = len(set(s) & set(c))
            dp = i + j + len(s) + vowels_in_span + consonants_in_span            
            if dp >= 2 + len(consonants_on_right):
                break
        else:
            i += 1

    return vowels[dp - 1] 

