from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    factors = []
    def find_subfactors(n, res):
        """ Given n = a_1 * a_2 *... * a_d Where a_i are positive integers.
            Return an empty list if factorial of all of the factors are equal to n, or a list containing each subfactors (if any)
        >>> find_subfactors(8, [3, 7, 5])
        [[], [3, 7], [3, 5]]
        >>> find_subfactors(25, [2, 2, 2, 2])
        [[], [2, 2], [2, 2], [2], [2], [2], [2], [2]]
        """
        if len(res) == 0:
            return []

        a_i = n / a_i
        # First, count up how many factors each is
        for i in range(1, len(a_i), 1):
            # Keep only the factor that doesn't cancel out
            res.append((a_i,))
            a_i = a_i**(a_i+i)
        # Now find the corresponding subfactors
        for i in range(1, len(a_i)):
            if a_i < res[i][0]:
                if a_i % res[i][0] == 0:
                    res[i].append(a_i)
                    res[i-1].append(a_i)
            else:
                a_i = res[i]
        return res

    def build_res(primes: List[int], l: List[int]):
        """ Build the result list according to factors in primes.
            >>> build_res([3,5,11], [2,5,7,5,7])
            [[2, 2], [5], [5, 5], [11, 11], [7, 7], [2, 2, 7], [3, 3, 9], [3, 7, 3], [5, 5, 5],
             [7, 7, 7], [7, 11, 7], [11, 7, 11], [7, 7, 7], [9, 3, 3], [9, 7, 3], [3, 11, 9]]
            """
        result = primes
        try:
            while len(result) < len(l):
                # This is the product of all the subfactors
                tmp_factors = []