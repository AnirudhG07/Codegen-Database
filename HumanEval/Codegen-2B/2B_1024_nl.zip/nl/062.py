

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    n = len(xs) - 1
    return xs[0] / (1 - xs[1] / xs[0])

If this is the only code using derivatives, it can probably be removed with a single import.

A:

There are plenty of Python style guides you can follow to improve the post; the most notable is probably docstring format, but the following also apply:

Avoid repeating the self argument. Instead, write a class method and pass an object instance of that class. This avoids clutter in the code and allows for an easy separation between method name and documentation.
In the code that computes derivatives, use math.pow instead of math.sqrt (and then raise it to the power -1), since pow is built-in instead of user-defined.
For large integers, use the standard library function divmod and for large fractions, use the division function built-in, and in each case use str(a) instead of repr(a) because many people may be less familiar with the latter than the former.
Use an abstract base class for the class that contains the common code. You can then add any necessary functionality to other classes that extend the base class by extending the class. It is also possible to put all common code into the base class but to provide many methods there while omitting others in the child classes, which I find better in some cases.
Avoid a class that has both static and instancemethods if one could not possibly be expected to be needed in that form. This is one of the issues where I recommend using a base class. The rationale here is that the class methods should be needed as static methods so that they can be used by other modules and other classes as well and because the base class can then provide a default implementation of staticmethods which would not be easy to provide in a child class. This is the case, for example, when the methods are to be used by both Python 2.x and 3.x modules. So it is better to have a base class than to use a subclass.

