
def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    # TODO: write the solution
    highest = -1
    for i in range(len(arr)):
        if arr[i] > arr[highest]:
            highest = i - 1
    return highest


if __name__ == "__main__":
    input_items = input().split() #read inputs
    #print ("Enter value and test")
    #input_items = input().split()
    #print ("value:",input_items)
    
    inputLst = list(map(int, input_items)) #converting to an array
    max_indx = can_arrange(inputLst) #calling