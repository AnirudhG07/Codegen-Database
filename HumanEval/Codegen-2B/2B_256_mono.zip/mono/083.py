
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
#    if len(str(n)) == n:
#        return 1
#    return 0
    return 1

    

# # Test Cases:
# assert starts_one_ends(100) == 5
# assert starts_one_ends(15) == 40
# print("all test cases work")



# 2) How can you write a more efficient algorithm?
