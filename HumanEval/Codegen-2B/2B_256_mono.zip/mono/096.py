
def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    # we start with our n value here
    primes = [i for i in range(2,n+1) if isprime(i)]
    # we keep track of count so we can return a list of primes as desired
    return_list = []
    # let's start with an index value to loop over primes
    index = 0
    # as a loop, check all