
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 *... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    if n == 1:
        return [1]
    out = f(n-1)
    for i in range(len(out)):
        if i%2 == 0:
            out[i] = out[i]*(i + 1)
            out.append(i+1)
    return out'''
class Solution:
    def fibs(self, n):
        """ Implement the fibs function and return a list of the size n, such that the list elements are
        the Fib numbers and the first element is always 1 (f(1))"""
        return