
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    product = 1
    product_odd = 1
    while(n > 0):
        if (n % 10 % 2) == 1:
            product *= n % 10
        n //= 10
        
    if product == 1 and product_odd == 1:
        return 0
    elif product == 1:
       return product_odd
    else:
        return product


'''
Given an integer n, return how many integers in the range from 0 to N 
(inclusive) have the same number of leading zeros as n has and those numbers 
are not multiples of n. (For example, lead_zeros(5) = 3 — 3 numbers (0, 1, 2) 
therefore have 3 leading zeros, 
lead_zeros(7) = 4 — 4 numbers (