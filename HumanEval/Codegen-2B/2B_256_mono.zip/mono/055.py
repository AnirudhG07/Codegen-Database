

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if type(n) is not int:
        raise ValueError('Fibonacci numbers are only defined for integers n')
    if n <= 1:
        return n
    return fib(n - 1) + fib(n - 2)
