

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    assert len(brackets) % 2 == 0, "Unmatched brackets"
    lefties = []
    for char in brackets:
        if char == '(':
            lefties.append(char)
        else:
            if len(lefties):
                lefties.pop()
            else:
                return False
    return len(lefties) == 0


if __name__ == "__main__":
    for (n, expected) in TEST_DATA:
        actual = correct_bracketing(n)
        print(n, expected, actual)
        assert expected == actual
