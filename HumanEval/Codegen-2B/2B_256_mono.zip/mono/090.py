
def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    lst_copy = lst[:]

    def heapify(lst, i):
        largest = i
        size_lst = len(lst)
        lst2_idx = (2 * i) - 1

        # if left child index > size and right child is equal to largest
        if lst2_idx + 1 <= size_lst and lst[(2 * i)] > lst[lst2_idx + 1]:
            largest = lst2_idx + 1

        if lst2_idx < size_lst