
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    # If the string length is less than 2 then return True or False
    # if it is prime, it must be greater than 2.
    if len(string) <= 2:
        return True
    # First letter in the string must be prime (or not possible)
    letter = string[0]
    if letter in ['a', 'e', 'i', 'o', 'u', 'y']:
        return False
    # Find the prime numbers between 2 and the length of the string
    # for each potential prime number i
    for i in range(2, len(string)+1):
        # If the first i letters in the string are not prime
        # then set the string length to be false
        if not is_prime(i):
