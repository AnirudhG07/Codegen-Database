

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    # if x is a base and 10, we're done.
    if x < 10 and x > -10:
        return str(x)
    # calculate how many digits in base 10
    # need to move to the next digit, after a * 10^a
    # (a is the index at 1)
    num_of_digits = 1
    while x >= base ** num_of_digits:
        num_of_digits += 1

    # calculate the new base
    new_base = base ** num_of_digits

    # calculate how many moves required from the x (new_base) to x
    # subtract the initial x to calculate how many places at the