

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    half_triangle = a / 2
    area = half_triangle * h
    return area


