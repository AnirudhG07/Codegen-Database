
def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    if not text:
        return None
    
    hasher = hashlib.md5()
    hasher.update(text.encode('utf-8'))
    dhash = hasher.digest()
    hash_str = base64.b64encode(dhash).decode()
    return hash_str


if __name__ == '__main__':
    import doctest
    doctest.testmod()                    # Test the DocTest


