

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if n == 0 or n == 1:
        return 1
    if not n & 1:
        return n
        
    for i in range(n, 1, -2):
        if prime_factor(i) > 1:
            return i
    return 1


# # Test Cases
# print(largest_prime_factor(2048))
# print(largest_prime_factor(13195))
# print(largest_prime_factor(1000000007))        

