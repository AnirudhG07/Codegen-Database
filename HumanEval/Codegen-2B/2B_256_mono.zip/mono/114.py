
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    result, curSum, l = float("inf"), 0, 0
    for r in range(0, len(nums)):
        curSum += nums[r]
        while l <= r and l < len(nums) and curSum >= result:
            result = min(result, curSum - nums[l])
            curSum -= nums[l]
            l += 1
    return result if result!= float("inf") else -1

# -----------------------------------------------------------------------------
# 25-Palindrome Permutation - LeetCode
# Given a string s, return true if
# it is possible to reach's' form any permutation of its
# characters by switching some letters
#  A: 'abba' -> ['b