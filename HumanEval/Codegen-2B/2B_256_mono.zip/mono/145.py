
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    # create a sorted list of pairs: (digit sum, sum of item)
    num_map = sorted(
        [(sum(int(number) for number in str(int_num)), int_num) for int_num in nums],
        reverse=True
    )
    # use _sorted.items() because num_map returns a list of pairs
    return [item[1] for item in _sorted.items()]
