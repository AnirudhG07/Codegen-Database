
def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k, 
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation: 
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    result = 0
    for n1 in range(1, n):
        for n2 in range(n1 + 1, n):
            for n3 in range(n2 + 1, n):
                if n1 == n2 == n3:
                    continue
                if (n1 * n1 - n1) % 3 == 0 and (n2