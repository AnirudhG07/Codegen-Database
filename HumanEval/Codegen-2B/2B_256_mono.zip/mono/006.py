from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    paren_stack = []
    for curr in paren_string:
        paren_stack.append(curr)
        while len(paren_stack) > 0 and paren_stack[-1] == "(":
            substr = paren_stack.pop()
            if substr == "(":
                paren_stack.pop()
                while paren_stack and paren_stack[-1]!= ")":
                    substr += paren_stack.pop()
                paren_stack.pop()
            elif substr == ")":
                return "error"