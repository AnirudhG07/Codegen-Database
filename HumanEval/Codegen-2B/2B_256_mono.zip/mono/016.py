

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    # count every character, incrementing the count once we encounter a duplicate
    # then decrement the count once we remove the duplicate
    char_dict = {}
    duplicate_count = 0
    final_count = 1

    for char in string:
        if char in char_dict:
            char_dict[char] += 1
            duplicate_count = 1
        else:
            char_dict[char] = 1
    
    for char, count in char_dict.items():
        if count == 0:
            continue
        elif count == 1:
            final_count += 1

        elif duplicate_count == 1:
            final_count += count-1
            duplicate_count -= 1

    return final_count


