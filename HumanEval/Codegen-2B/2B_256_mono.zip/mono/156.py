
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    n, number_chars = 2, 'IIMX'

    while number >= n:
        tmp_char = 'I'
        while number >= n:
            number -= n
            tmp_char = (number_chars[number:number + n] + tmp_char)
            print(number_chars[number:number + n] + tmp_char)
        n *= 10

    return tmp_char


if __name__ == '__main__':
    import doctest
    doctest.testmod()
