
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
  
    for i in range(len(b)):
        for k in range(len(a)+i,len(a)+len(b)):
            for j in range(len(a)):
                word = a[j:k]
                if(word==b):
                    return True
    return False



if(__name__) == "__main__":
    # test 1
    print(cycpattern_check("abcd","abd"))
    #