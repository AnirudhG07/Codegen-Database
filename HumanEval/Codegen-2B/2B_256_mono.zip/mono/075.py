
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    
    if a % 3!=0: #if not factor in a/it has to be an even number
        return False
    
    sqrt = int(math.sqrt(a))
    factors_of_a = []
    for i in range(3,sqrt+1,2): #for squaring numbers from 2 to sqrt
        if a%i==0: #add it to list
            factors_of_a.append(i)
    
    list_len = len(factors_of_a)
    is_prime = True
    for i in range(list_len-1): #check if the factors of a are prime until the last element
        if factors_of_a[i] == factors_of_