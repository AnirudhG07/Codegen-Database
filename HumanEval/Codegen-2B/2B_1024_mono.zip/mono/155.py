
def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    if num < 0:
        raise ValueError("Please use positive number")
    count_of_odd = 0
    count_of_even = 0
    while num:
        result = num % 10
        if result % 2!= 0:
            count_of_odd += 1
        
        if result == 0 or result == 1:
            return count_of_even, count_of_odd
        else:
            count_of_even += 1
        
        num //= 10

if __name__ == "__main__":
    from common import print_solutions, header, randint_logs
    a, b = randint_logs(1, 20, 5)
    print_solutions(a, b, even_odd_count3)
    header("even_odd_count", a, b)