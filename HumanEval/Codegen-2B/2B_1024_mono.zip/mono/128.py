
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if not arr:
        return None
    neg = 0
    pos = 0
    zero = 0
    for i in arr:
        if i == 0:
            zero += 1
        if i < 0:
            neg += 1
            if zero > 0:
                return None
        elif i > 0:
            pos += 1
            if zero > 0:
                return None
    if neg == 1 and pos == neg:
        return zero + neg * -1 * (zero + neg) * -1
    elif neg == 0 and pos == 0:
        return zero
    elif neg == 1 and pos == 0:
        return zero + neg * -1
    return None


if __name__ == "__main__":
    import doctest
    if doctest.testmod().failed == 0:
        print("\n*** ALL TESTS PASSED. YOU'RE THE BEST!\n")
