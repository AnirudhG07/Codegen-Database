

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    # this can be optimized
    '''
    if n == 0 or n == 1:
        return 1
    return fib(n-1) + fib(n-2)
    '''
    # using memoization
    cache = { }
    def memoized_fib(n=1):
        if n in cache:
            return cache[n]
        result = fib(n-1) + fib(n-2)
        cache[n] = result
        return result


    result = memoized_fib(n)
    return result

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# https://docs.python.org/3/library/functions.html
