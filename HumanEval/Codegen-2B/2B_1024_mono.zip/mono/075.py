
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    # check if the given number is less than or equal to 100
    if a < 100:
        # return false if the given number is less than or equal to 60, 
        # as it must be less than 60 because every integer multiplication of 3 is divisible by 2.
        if a < 60:
            return False
        
        # return true if the given number is divisible by 3
        else:
            return True

# testing to see if the function works.

# print(is_multiply_prime(30))

# print(is_multiply_prime(100))





#
# a = 3
# b = 2
# x = (a * 3) * (b * 2) # 6 times 3
# print(x > 100)