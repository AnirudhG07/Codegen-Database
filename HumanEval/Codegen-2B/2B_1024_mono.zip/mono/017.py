from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o|.| o| o|.|.|.|.| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    string_splitted = music_string.split('|')
    res: List[int] = []
    length: int = 0
    for i in string_splitted:
        length_list = i.split()
        i = length_list[0][2:]
        length_list = int(length_list[0][:2])
        if i == 'o':
            length = (4 * length)
        elif i == 'o|':
            length = (2 * length)
        elif i == '.|':
            length = (1 * length)
        res.append(length)
        length = 0
    return res


#########################
# Tasks from stage1
#########################

