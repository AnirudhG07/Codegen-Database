
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    newLst = []
    
    for i, val in enumerate(lst):
        if i%2 == 0:
            newLst.append(val)

    return newLst


# NOTE: The function above is kind of clunky... We use `lst` instead just to make typechecking easier
# https://en.wikipedia.org/wiki/Alternating_sorting_algorithm
