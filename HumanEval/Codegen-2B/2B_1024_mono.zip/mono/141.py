
def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """
    if len(file_name) < 4:
        return "No"
    if file_name.find(".") == -1:
        return "No"
    file_name = file_name.split(".")[0]
    check = re.findall("\w", file_name)
    for i in range(len(check)):
        if len(check[i])!= 2:
            return "No"
        if check[i][0] < 'a' or check[i][0] > 'z' or check[i][1] < '0' or check[i][1] > '9':
            return "No"
    if file_name.upper() not in {"EXE", "DLL", "TXT"}:
        return "No"
    else:
        return "Yes"
    
# Create a function which checks if a string is a valid email address.
# An email address is considered valid if and only if it consists of an email 
# address within an @ sign, an. sign, and one or more domain names separated 
# by a period (".")
# Domain name examples: m.example.com, www.example.com and yahoo.com
# Examples:
# my_email(.....) => True
# my_email(email@google.com) => True
# my_email(email@.com) => True
# my_email(email @gmail.com) => False
# my_email(email.com) => False
# my_email(abc.com) => True

