

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    xs_length = len(xs)
    l2_list = []
    for i in range(1, xs_length):
        difference = xs[i+1] - xs[i-1]
        # if we know the derivative of x^2 then we only want to include this in the derivative
        if i == 2:
            l2_list.append(difference)
        else:
            l2_list.append(2 * difference)

    # add the first element twice which is 0
    l2_list.append(2 * xs[0])
    l2_list.append(-xs[0])
    return l2_list

