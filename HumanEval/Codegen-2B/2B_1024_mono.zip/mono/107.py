
def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """
    # https://en.wikipedia.org/wiki/Even_integer_palindromic_decomposition
    # the idea here is
    # count the number of odd even integers less than N
    # the even integers less than N can be divided into groups of 2, 
    # if they are already palindromes
    # so first figure the number of even numbers less than N

    odds, evens = 0, 0
    for i in range(1, n+1):
        # odd integers less than i will be odd + odd divisor - 2
        odds, divisor = i, 2
        while(divisor*divisor <= i):
            if i % divisor == 0:
                # i/divisor is even
                evens += (i // divisor)
                odds += (i // divisor)
            divisor += 1
    return (evens, odds)