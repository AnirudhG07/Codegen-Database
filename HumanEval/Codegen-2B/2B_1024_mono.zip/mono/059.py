

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    n = abs(n)
    for p in range(min(n, math.ceil(math.sqrt(n))), 0, -1):
        if n % p == 0:
            return p

###
# Other Solutions:

# def largest_prime_factor(n):
#     factors = []
#     i = 2
#     while i * i < n:
#         if n % i:
#             i += 1
#         else:
#             n //= i
#             factors.append(i)
#     if n > 1:
#         factors.append(n)
#     return max(factors)


if __name__ == "__main__":
    print(largest_prime_factor(137))
    print(largest_prime_factor(2048))
