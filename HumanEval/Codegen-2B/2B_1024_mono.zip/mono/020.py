from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    a = b = numbers[0]
    
    a_idx = 0
    b_idx = 0
    
    while b_idx < len(numbers):
        if abs(a - numbers[b_idx])  < abs(a - numbers[a_idx]): a = numbers[b_idx]
        if abs(a - numbers[b_idx])  < abs(a - numbers[b_idx]): a_idx = b_idx
        b_idx += 1

    end_idx = 0
    while end_idx < len(numbers) and numbers[end_idx] == a:
        end_idx += 1

    return a, a_idx, end_idx


