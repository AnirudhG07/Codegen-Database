
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    if not arr or len(arr) == 0:
        raise ValueError("The given array contains nothing.")
    if len(arr) == 1:
        return 0
    if arr[0] == arr[1]:
        return smallest_change(arr[1:])
    return 1 + min(smallest_change(arr[1:]), smallest_change(arr[:-1]))


if __name__ == '__main__':
    for i, o in [(["1", "2", "3", "5", "4", "7", "9", "6"], 5),
                 (["1", "2", "3", "5", "4", "7", "9", "6"], 4),
                 (["1", "2", "3", "4", "3", "2", "2"], 1),
                 (["1", "2", "3", "2", "1"], 0),
                 (["1", "2", "3", "2", "1", "2", "2"], 2)]:
        for j in range(len(i)):
            print(f"i[{j}] | expected | calculated", end=" ")
            for k in i:
                if k!= i[j]:
                    print(f"{k}*", end = " ")
                    break
                # print(f"{i[j]}*", end = " ")
            print()