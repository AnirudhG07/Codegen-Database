
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    if n == 0: return n

    # start with 1 and only count if it's not (n - 1) because this is 0 not n - 1
    result = 1
    while n!= 0:
        result *= n % 10
        # we don't need to use divmod because the remainder is 0 and we just break the loop
        n = n // 10
    return result

