
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    s = list(s)
    i = 0
    while i < len(s)-1:
        if s[i].isalpha():
            if s[i].isupper():
                s[i] = s[i].lower()
            else:
                s[i] = s[i].upper()
        else:
            if s[i]!= s[i+1]:
                s[i] = s[i]

        i += 1
        
    if s[-1].isalpha():
        return "".join(s)




print(solve("1212"))
