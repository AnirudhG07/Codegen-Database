

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    # first item cannot be smaller than second one
    # this also works for negative lists
    if not l or l[0] >= l[1]:
        return True

    n = len(l)
    first = True
    i = 1

    while i < n and not(first or l[i - 1] < l[i]):
        first = l[i - 1] < l[i]
        if first:
            return False
        i += 1

    if first:
        return l[i - 1] > l[i]

    return l[i - 1] < l[i]


