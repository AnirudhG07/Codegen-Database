

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n <= 1: return 0
    a = 0
    b = 1
    for i in range(2, n+1):
        fib = a + b
        a = b
        b = fib
    return fib


# print(fibfib(1))
# print(fibfib(10))
# print(fibfib(100))


'''
For Example: if you call fibfib(10) the next nine numbers are:
0 0 0 4 0 0 0 1 4 0 0 3
This sequence is one of the fibonacci sequnce, it's also known as the Kaprekar Cipher Sequence,
it's basically an integer sequence that uses the four fibonacci recurrences in succession.

For Example: if you call fibfib(0) the next nine numbers are:
0 0 0 0 0 0 0 1 4 0 0 2
This sequence is one of the fibonacci sequnce, it's also known as the Kaprekar Cipher Sequence.
'''

