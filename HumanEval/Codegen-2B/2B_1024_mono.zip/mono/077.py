
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    if len(str(a)) <= 2:
        return True
    div = len(str(a)) / 3
    for i in range(int(div)):
        if div == str(a)[i]:
            return True
    return False


if __name__ == '__main__':
    input = [[1, 2],
             [2, 4],
             [1, 6]]
    outputs = iscube([1, 5, 8, 10, 17, 20])
    assert outputs == True, "Wrong result"
    print("Success")
