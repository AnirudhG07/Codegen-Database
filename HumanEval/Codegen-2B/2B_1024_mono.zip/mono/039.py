

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    f1, f2 = 2, 3
    while n > 1:
        temp = f1 + f2
        f1 = f2
        f2 = temp
        if is_prime(f1) and is_prime(f2):
            print("Fibonacci Number:", temp)
        n -= 1
    return f1, f2

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)
