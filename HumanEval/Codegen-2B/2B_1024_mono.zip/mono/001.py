from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    paren_set = set(paren_string)

    # check if open_parens.set < close_parens.set
    for i in paren_set.intersection(set([')', ']', '}']) == set():
        new_string = ''
        paren_string = paren_string.replace(i, '')

    paren_list = []
    for i in paren_string:
        paren_list.append(i)

    if len(paren_set) > 1:
        # split nested sets of close parens into different strings (return)
        while paren_list:
            open_parens, close_parens = 0, 0
            next_open = open_parens + 1

            # find last closed paren
            while paren_list[next_open] not in set(['(', '{', '[']) and paren_list[next_open]!= ')':
                next_open += 1

            # find first closed paren
            while paren_list[next_open] not in set(['}', ')', ']']) and paren_list[next_open]!= '(':
                next_open -= 1

            paren_list.pop(next_open/2)
            close_parens = next_open

            for i in range(open_parens, close_parens-1):
                paren_list.append(paren_list.pop(0))
    else:
        paren_list = []
    return paren_list


