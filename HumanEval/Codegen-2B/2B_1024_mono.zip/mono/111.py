
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    dict_of_letters = {}
    for letter in test.lower():
        dict_of_letters[letter] = len(letter)
    return dict_of_letters

# histogram('a b c')

# TODO:

# Write function that checks if there is a palindrome in a given string
# def is_palindrome(s):
#     """Given a string, return True if the string is a palindrome."""
#     for i in range(len(s) // 2):
#         if s[i]!= s[len(s) - 1 - i]:
#             return False
#     return True

# is_palindrome('a') # -> False
# is_palindrome('aab') # -> False
# is_palindrome('aaba') # -> True
# is_palindrome('abcabab') # -> True
# is_palindrome('abbab') # -> False
# is_palindrome("") # -> True


# def is_palindrome(s):
#     """Given a string, return True if the string is a palindrome."""
#     xlen = len(s) - 1
#     if xlen <= 0: return True
#     elif s[xlen]!= s[0]: return False
    
#     return is_palindrome(s[1:-1])

# print(is_palindrome('a'))

# TODO:
# def is_palindrome(s):
#     """Given a string, return True if the string is a palindrome."""
#     xlen = len(s) - 1
#     if xlen <= 0: return True
#     elif s[xlen]!= s[0]: return False
    
#     return is_palindrome(s[1:-1])

# is_palindrome('a')

# TODO:
# def is_palindrome(s):
#     """Given a string, return True if the string is a palindrome."""
#     xlen = len(s) - 1
#     if xlen <= 0: return True
#     else:
#         return s.lower() == s[::-1].lower()


# is_palindrome('a') # -> True
# is_palindrome('aab') # -> False
# is_palindrome('aaba') # -> True
# is_palindrome('abcabab') # -> True
# is_palindrome('abbab') # -> False
# is_palindrome("") # -> True