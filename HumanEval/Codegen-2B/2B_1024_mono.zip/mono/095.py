
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    if not dictionary_data:
        return False
    elif not isinstance(dictionary_data, dict):
        raise ValueError("value must be of type dictionary.")
    elif not isinstance(lower_key, bool) or not isinstance(upper_key, bool):
        raise ValueError("All parameters must be True or False.")

    lower_found = True
    upper_found = True
    for data in dictionary_data.values():
        if not isinstance(data, str):
            raise ValueError("value must be in string format.")
        if upper_found and not data.upper() == data:
            upper_found = False
        if lower_found and not data.islower():
            lower_found = False

    return not lower_found or not upper_found

print(check_dict_case({"a":"apple", "b":"banana"}))
