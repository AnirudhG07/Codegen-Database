from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    lst = []
    if n == 0:
        return lst
    while n!= 1:
        x = n
        i = 0
        # Finding next factor from the square root of the number
        # while x % 2 == 0:  # the program will error on the even number
        #     x = x // 2  # when you divide by 2 the number will be an exact even number
        while x > 1:
            if x % 2 == 0:
                x = x //2
            else:
                i = i + 1
                x = x //2
        lst.append(i)
        n = n//i
    return lst


print(factorize(8))
print(factorize(25))
print(factorize(70))
