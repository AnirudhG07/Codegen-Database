
def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    vowels = ['a', 'e', 'i', 'o', 'u']

    start = 0
    end = len(word) - 1

    while end - start > 0:
        middle = (start + end) // 2
        
        if word[end] in vowels:
            return word[end]

        if word[start] not in vowels and word[start] not in vowels and word[start]!= 'i':
            return None

        if word[start] in vowels:
            if word[start] not in vowels:
                start = start + 1
            else:
                end = middle + 1
        else:
            start = middle
    return ""
if __name__ == '__main__':
    print(get_closest_vowel('yogurt'))

