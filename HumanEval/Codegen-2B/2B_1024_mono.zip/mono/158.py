
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    # if all letters are same
    # return first one
    if len(set(words)) <= 1:
        return words[0]
    # if there are more than one max, return last first
    temp = None
    for i in range(len(words)):
        if temp is None or len(words[i]) > len(words[temp]):
            temp = i
    return words[temp]


# print(find_max(["name", "of", "string"]))
# print(find_max(["name", "enam", "game"]))
# print(find_max(["aaaaaaa", "bb", "cc"]))
