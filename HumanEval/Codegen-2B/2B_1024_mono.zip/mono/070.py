
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    # TODO your code here
    # return sorted(lst, key = len)
    # len -> length, sort key will decide whether or not to sort list
    # lst = sorted(lst, key = lambda x:len(sorted(lst, key = lambda x:len(lst))))     
    while len(lst)!= 0:
        len_min = lst[0]
        temp = []
        i = 0
        while i < len(lst):
            if len(temp) == 0:
                temp.append(lst[i])
                i += 1
            elif len(temp) > 0 and lst[i] == len_min:
                temp.append(lst[i])
                i += 1
            else:
                if i + 1 == len(lst):
                    temp.append(len_min)
                    temp.append(lst[i])

        lst = temp
    return lst
            

## TEST
# print(strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3])
# print(strange_sort_list([1, 2, 3, 3]) == [1, 3, 2, 3])
# print(strange_sort_list([]) == [])
# print(strange_sort_list([1, 1, 1, 1, 1]) == [1, 1, 1, 1, 1])
