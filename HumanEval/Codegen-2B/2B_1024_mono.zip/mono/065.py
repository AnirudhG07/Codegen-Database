
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # if there are <shift> digits, we don't need to do anything
    if shift == 0:
        return str(x)

    shifted_digits = "".join(reversed(str(x)))
    # chop off last digit, add digit shifted_digits
    shifted_sliced = shifted_digits[:-1] + shifted_digits[-1 + shift::]

    return str(int(shifted_sliced))


if __name__ == "__main__":
    unittest.main()
