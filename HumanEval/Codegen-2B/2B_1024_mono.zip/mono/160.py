
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    if(len(operator) == 0) or (len(operand) == 0) or (len(operand) > 2):
        raise Exception("The length of operator is 0, or operand is 0, or operand's length "
                        "is more than 2.")

    # get the corresponding operator function.
    def func(a, b, op):
        """
        Args:
            a (float/int): A.
            b (float/int): B.
            op (str): Operator.

        Returns:
            (float/int)

        """
        a, op, b, operando = operators[operator.index(op)]
        # do the math operation.
        if op == "*":
            return a * b
        if op == "/":
            return a / b
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        print("Error: Undefined operator.")
        exit()

    # use it to evaluate the expression.
    result = 0
    for operand, ele in zip(result, operand):
        result = func(operand, ele, operator.index(op))

    return result


if __name__ == "__main__":
    # This part should be called only when running as main module
    from time import time as timer

    # Testcase
    # test1 = (["+", "+", "+"], [[15, 2, 27]])
    # test2 = (["+", "+", "+"], [[0, 0, 0]])
    # (["-", "-", "+"], [[-2, 5, -3]])
    test1 = (["*", "*", "*"], [[15, 2, 27]])
    test2 = (["*", "+", "+"], [[0, 0, 0]])
    (["//", "/", "*"], [[0, 0, 0]])
    (["+", "+", "+"], [[15, 2, 27]])
    # (["/", "+", "+"], [[0, 0, 0]])
    # (["+", "+", "+"], [[0, 0, 0]])
    # (["+", "+", "+"], [[0, 0, 0]])
    # (["+", "+", "+"], [[0, 0, 0]])
    # (["-", "-", "-"], [[-5, -3, -2]])
    # (["+", "-", "-"], [[3, 5, -2]])
    # (["-", "-","-"], [[-5, 5, 0]])
    # (["-", "-","-"], [[-10, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # (["*", "*", "*"], [[0, 0, 0]])
    # test8
    # a = [15, 0, 0, 0, 0, 0, 0