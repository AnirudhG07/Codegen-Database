
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    vowels = list("aeiouy")
    count = 0
    for c in s:
        if c in vowels:
            count += 1

    return count


'''Write a function vowels_count which takes a string representing
a word as input and returns the number of vowels in the string.
Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    '''

    #def count_vowels(s):
    #    vowels = set("aeiouy")
    #    vowel_count = 0

    #    for vowel in set(s):
    #        if vowel in vowels:
    #           vowel_count += 1

    #    return vowel_count

'''Write a function count_vowels which takes a string
representing a word as input and returns the number of
vowels in the string.
'''
    #def count_vowels(s):
        #vowels = set("aeiouy")
        #vowel_count = 0

        #for vowel in set(s):
            #if vowel in vowels:
                #vowel_count += 1

        #return vowel_count
