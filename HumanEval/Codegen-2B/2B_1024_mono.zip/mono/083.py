
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    d, e = '', ''
    count = 0
    start_pos, end_pos = 0, len(str(n))
    start_count, end_count = 0, 0
    n = str(n)

    while start_pos <= end_pos - 1 and end_pos > 0:
       
        start_digits = n[start_pos:end_pos]
        end_digits = n[0:start_pos]
        if int(start_digits) == 1 or int(end_digits) == 1:
            e = e + str(1)
        else:
            e = e + str(0)
        start_pos += 1
        end_pos -= 1
    print(e)
    count = int(e.count('1')) + int(e.count('0'))

    return count
            
if __name__ == '__main__':
    n = 23145
    print(starts_one_ends(n))
