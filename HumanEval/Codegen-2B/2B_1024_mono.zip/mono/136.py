
def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''
    smaller = None
    larger = None
    for i in lst:
        if i < 0:
            smaller = i
        if i > 0:
            larger = i
    if smaller == None:
        return None, None
    else:
        return smaller, larger

assert ((largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)) == 0), \
   'returns None when there are no positive or negative integers'
assert ((largest_smallest_integers([]) == (None, None)) == 0), \
   'returns None when there are no numbers'
assert ((largest_smallest_integers([0]) == (None, None)) == 0), \
   'returns None when a negative integer is encountered'
# (((None, None) == 0) == True)
# (((None, None) == 0) == 0)
