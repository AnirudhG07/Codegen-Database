
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    pass # Write your code here...

if __name__ == '__main__':
    import doctest
    doctest.testmod()
# if you are reading this code in your notebook, comment out these lines:
# import os as os
# os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
# and run your code from here:

    # run closest integer without using a GPU
    closest_integer("10") # 10
    closest_integer("16.10") # 17

    # run closest integer with a GPU
    # import os as os
    os.environ['CUDA_VISIBLE_DEVICES']='0'
    closest_integer("10") # 10
    closest_integer("16.10") # 17
