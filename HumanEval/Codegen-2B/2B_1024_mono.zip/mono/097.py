
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    
    a = str(a)
    b = str(b)

    while len(str(int(a[0]))) < 6:
        a = '0' + a

    while len(str(int(b[0]))) < 6:
        b = '0' + b

    return int(a[0]) * int(b[0])