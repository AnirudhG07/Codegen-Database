
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    # create a stack with open parenthesis as first item
    s = ["("]

    # while there are open or closing parentheses
    while len(s) > 1:
        # pop top of stack
        x = s.pop()
        # while there are still open parentheses, if not top element
        # x still in a paren, append to stack
        while x!= ')':
            # if top is ) then break, else continue
            if x == '(':
                break
            s.append(x)
            x = s.pop()
        # parens complete
        else:
            # check order and not pop until all of the parenthesis are matched
            if s == ['(', ')'] or s == ['(', ')]':
                return 'Yes'
            else:
                return 'No'
        # update s while parens complete
        s = ['(', ')'] + s
    return 'Yes'


