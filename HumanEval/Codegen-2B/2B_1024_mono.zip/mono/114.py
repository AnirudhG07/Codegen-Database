
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    total = 0
    i = 0
    for j in range(len(nums)):
        total += nums[j]
        while total >= 1:
            total -= nums[i]
            i += 1
        i -= 1
        total -= nums[i]
    return i + 1


print(minSubArraySum([2, 3, 4, 1, 2, 4]))


# %%
import time
from scipy.integrate import simps


