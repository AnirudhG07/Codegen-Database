
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 *... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    # first create a list and set the
    # first n elements with the factorial
    # or in other words set up the f array
    #
    # initialize the list
    f = [0]*n
    # first number to be considered is 1
    f[0] = 1
    # i starts at 1
    i = 1
    while i <= n:    # start from 1 to n
        # set the j to be 0
        j = 0
        # iterate through the list looking for all j's
        while j < i:  # where j increments
            # calculate the current f[j]
            f[j] = f[j] + f[j - 1]  # add to the previous iteration, add 1 for next iteration!
            # increment j by 1
            j = j + 1
        # move to the next index in the factor
        i = i + 1
    # return the list
    return f
# print(f(5))
