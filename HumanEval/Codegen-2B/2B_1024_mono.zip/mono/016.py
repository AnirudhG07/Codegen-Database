

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    result = {}

    if len(string) < 1:
        return 0

    if string == string.upper():
        return len(string)

    for chars in string:
        if chars.upper() in result:
            result[chars.lower()] += 1
        else:
            result[chars.lower()] = 1

    return len(result)

