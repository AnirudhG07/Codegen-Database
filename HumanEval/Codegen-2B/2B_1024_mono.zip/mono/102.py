
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    
    biggest = -1
    
    while x <= y:
        if math.floor((x + y)/2) % 2 == 0:
            biggest = math.floor((x + y)/2)
        x = int(math.floor((x + y)/2))+1
        y = int(math.ceil((x + y)/2))
        
    return biggest


# In the below example, choose_num(0, 10) should return 2.
print(choose_num(-9, -1))

print()

# ----------------------------------------------------------------------
# D. Sum Root to Leaf Numbers
# ----------------------------------------------------------------------

