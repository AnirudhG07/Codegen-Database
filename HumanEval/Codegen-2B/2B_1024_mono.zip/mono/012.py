from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    # First, let's sort
    # The `sorted` built-in is stable, so if we're sorting by length, the
    # length of each element will be sorted
    # This means sort by length instead of string lengths
    # (strings are of different lengths, so the sorting rules are different,
    # and this is better than just getting the shortest string)
    strings.sort(key=len)
    # print(strings)

    # This returns the first string that's of the same length as the longest string
    if strings:
        length = len(strings[0])
        return strings[0] if length == len(strings[-1]) else None


