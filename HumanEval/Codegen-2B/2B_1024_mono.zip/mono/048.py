

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    assert text, 'Input cannot be empty'

    if len(text) <= 1:
        return True

    first_char = text[0]
    rev_text = text[1:][::-1]

    if len(rev_text) > 1:
        second_char = rev_text[0]
        if first_char == second_char:
            return is_palindrome(rev_text[1:])
        else:
            return False
    else:
        return True


