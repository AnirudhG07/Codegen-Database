from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    mean = sum(numbers) / len(numbers)
    outline = ((abs(n - mean) for n in numbers)
                )
    outline = (round(sum(vals) / len(vals)) for vals in outline)
    return out 
    

nums = [2.7, 7.1, 1.5, -2.5, -6.7, 0.4]

print(mean_absolute_deviation(nums))