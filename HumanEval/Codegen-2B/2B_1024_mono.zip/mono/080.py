
def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """
    # Solution's Idea:
    # Check if there are 3 repeating characters and if so see if they are all unique.
    # If not then return false. If 3 repeating characters or no 3 repeating characters
    # and unique then return true
    
    seen = set()
    length = len(s)
        
    if length < 3 or s.isspace(): # or not string
        return False
    
    for i in range(0, length-1):
        if s[i] == s[i + 1] and (s[i] not in seen):
            seen.add(s[i])
        else:
            seen.add(s[i])
            
    # check if length is at least 3 and the string is not repeating
    if length >= 3:
        if len(seen) < 3:    # if more than 3 repeats in same string
            return False
        else:
            return True
    return False


#Test Cases
print "Pass" if (is_happy('aaa') == True) else "Fail"
print "Pass" if not (is_happy('aaaa') == True) else "Fail"
print "Pass" if (is_happy('aaabc') == True) else "Fail"
print "Pass" if (is_happy('aaadbbc') == True) else "Fail"
print "Pass" if (is_happy('aaaabba') == False) else "Fail"