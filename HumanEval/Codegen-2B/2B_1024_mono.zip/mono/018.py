

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    string = substring + 'a'.join(['a']*(len(substring)-1)) + 'a'
    return len(filter(lambda x:string.find(x) >= 0, substrings.split(string)))

