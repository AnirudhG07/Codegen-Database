
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    numberOfEvenSum = 0
    numberOfSum = 0
    while not (numberOfSum < n and
               numberOfEvenSum < 12 and
               numberOfSum!= 2 * numberOfEvenSum and
               numberOfSum!= 0):
        # numberOfEvenSum should be even greater than 0 and less than 12, sum should between 0 and 8
        numberOfEvenSum = numberOfEvenSum + 1 if numberOfEvenSum % 2 == 0 else numberOfEvenSum
        numberOfSum = n - numberOfEvenSum if numberOfSum + numberOfEvenSum <= 12 else 1 + numberOfEvenSum - numberOfSum
    return numberOfSum == 0


@pytest.mark.parametrize(
    "n, expected",
    [
        (4, False),
        (6, False),
        (7, True),
        (8, True),
        (9, False),
        (12, False)
    ]
)
