
def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """
    n = max([n, 3]) # Can't have a 3-stone pile of size 0 after it!
    pile = [n]
    while len(pile) < n:
        level = len(pile)
        num_stone = n - level
        if level % 2 == 0:
            num_stones = num_stone * 2 + 1
        else:
            num_stones = num_stone * 2
        if num_stone + pile[-1] < 4 and len(pile) < n:
            pile.append(num_stone)
            
    while len(pile) > 1:
        pile = pile[:-1] + [pile[-1] + pile[-2]] + pile[1:]
        
    return pile

#pytest.main(["-q", "--color=yes", "--capture=no", __file__ + "." + make_a_pile.__name__ + "_test_all_0.py"])
