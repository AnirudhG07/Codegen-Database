
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    assert 1 <= number and number <= 1000, 'Roman numeral generator only accepts integers between 1 and 1000, try again!'

    number = str(number)
    r_num = ["", "M", "MM", "MMM"]   
    i = 4
    while len(r_num) < len(number):
        x = int(number[i])-1  # value of 'a' -1, 'i' -1, 'u' -1
        if x <= 0:
            r_num += ['', '', '', '',]
        else:
            if i!= 4:
                x -= 1
            r_num += [x*n for n in "IVX"]
        i += 1
    for x in range(len(r_num)):
        if x > 0:
            r_num[x] = int_to_roman_num(int(r_num[x]) )
    return ''.join(r_num)

