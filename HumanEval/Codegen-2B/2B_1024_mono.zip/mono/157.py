
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    assert a + b >= c and a + c >= b, "invalid triangle"
    assert b + c >= a and b + a >= c, "invalid triangle"

    p = c ** 2 + a ** 2 - b ** 2
    q = c ** 2 + b ** 2 - a ** 2
    r = a ** 2 + b ** 2 - c ** 2
    print(a, b, c, a + b + c)
    if p == abs(q) and q == abs(r) and abs(a-c) == abs(b-d):
        print(a, p, q, r)
        return True
    else:
        print(a, b, c, p, q, r)
        return False


print(right_angle_triangle(1, 2, 3))
print(right_angle_triangle(1, 2, 4))
print(right_angle_triangle(1, 3, 4))


