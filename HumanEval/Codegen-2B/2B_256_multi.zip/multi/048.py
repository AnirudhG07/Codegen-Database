

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    length = len(text)
    if length <= 1:
        return True
    half_length = int(length / 2)
    for i in range(half_length, length - half_length):
        if text[i]!= text[length - i - 1]:
            return False
    return True

print(is_palindrome(test_string))
