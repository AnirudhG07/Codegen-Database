
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    return is_sum_even(2, n) and is_sum_even(3, n) and is_sum_even(4, n)

"""
The above 2 functions is used to check for the given number whether the number
can be represented via two integers of sum 4 or whether the number can
be represented via three integers of sum 4 or four integers of sum 4.

Now, I will create another function to write a function is_sum_even(a, n) that takes two integers a and n.
a is the integer sum of the three positive even numbers from 1 to n and n is a positive integer

Here, the function will do four things:

I will use print statements to display the information about our first 2 functions