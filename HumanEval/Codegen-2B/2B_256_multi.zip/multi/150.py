
def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """
    return next(value for n, value in x if n % value!= 0 and n % value == x) if n % x!= 0 else y 

print(x_or_y(20, 4, 33))     # 34
print(x_or_y(16, 5, 1))      # 1
