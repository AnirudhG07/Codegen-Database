from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five','six','seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    # remove non integer strings
    numbers = numbers.split(' ')
    for i, s in enumerate(numbers):
        try:
            n = int(s)
            # check that string actually represents a digit
            if n >= 0 and n <= 9:
                # replace string value with sorted list of all its unique values
                numbers[i] = sorted(list(find_unique_numbers(numbers[i])))
        except ValueError:
            pass
    return''.join(numbers)


