
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # 1. Find min array sum
    # NOTE:
    # I chose do a linear algorithm here and
    # use stack to build solution, i.e.,
    # find the min subarray sum of left + right + left*right
    # as we can go right/left or left/right/right
    # and finally sum them up, as we can find sum of left part
    # of sum and sum of right part of sum
    # it's not nice, but we can just push the
    # number into the stack while computing a subarray sum.
    res = 0
    stack = [0]*(nums[0] + 1)

    for num in nums:
        while len(stack) > 1 and num