
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    numbers = set([ord(c)-87 for c in s])
    count = 0
    for letter in s:
        if letter.isupper():
            for index, number in enumerate(s[count:], count):
                if index % 2 == 0 and ord(number) - 87 >= 65:
                    break
                if index % 2 == 0 and ord(letter) - 87 >= 65:
                    break
                if index % 2 == 0 and ord(number) - 87 < 65:
                    break
                if index % 2 == 0 and ord(letter) - 87 < 65:
                    break
            else:
                count += 1
            if letter == 'd' and 'B' in numbers:
                count -= 1
    return count
