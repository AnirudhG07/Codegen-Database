

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    ys = [0] * (len(xs) + 1)
    for i in xrange(len(xs)):
        ys[0] += xs[i]
        for j in xrange(1, len(ys)):
            ys[j] += xs[i] * ys[j-1-i]
    return ys

