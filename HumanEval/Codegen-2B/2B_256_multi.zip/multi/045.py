

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    ha = (abs(h) > abs(a))  
    (h,a) = (abs(h), abs(a),)
    return ha * h / 2.0 + (0.5,)

