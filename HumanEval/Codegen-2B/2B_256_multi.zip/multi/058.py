

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    if not l1:
        return []
    if not l2:
        return l1
    assert isinstance(l1, collections.abc.Iterable)
    assert isinstance(l2, collections.abc.Iterable)
    if len(l1) > len(l2):
        return common(l2, l1)
    common: list = []
    for i in range(len(l1)):
        if l1[i] in l2:
            common.append(l1[i])
    l1 = sorted(list(set(l1) - set(common)))
    return common + sorted(l1)


if