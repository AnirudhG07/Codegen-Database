

def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    return sum(range(1, n + 1))


class Problem15():
    """Problem15: Sum of distinct elements

   In the 20-letter problem list (Problemlist.txt),

    Let f be the given function.
    Let L be the longest repeating subsequence.
    Write a function that, given input of f such as

      sum_to_n(30): 0 for n == 10
      sum_to_n(100): 0 for n == 8
      sum_to_n(10): 459 for n == 3
      sum_to_n(1): 1 for n == 1

    find all the sublists of the same length of