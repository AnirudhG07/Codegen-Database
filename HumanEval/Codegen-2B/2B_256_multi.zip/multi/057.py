

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    l = sorted(l)
    firstval: Union[int, float] = l[0]
    lastval: Union[int, float] = l[-1]
    if firstval > lastval:
        l.reverse()
        firstval, lastval = lastval, firstval
    return next((x < firstval for x in l), firstval!= lastval)
