
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    def circular_circumorder(x, shift):
        string = [str(x % 10)]
        while x / 10 >= 1:
            x /= 10
            string.insert(0, str(x % 10))
        string.insert(0, str(x))
        shifted = []
        while string:
            x, string = string[0], string[1:]
            shifted.insert(0, x)
        return "".join(reversed(shifted))


    if shift > len(x):
        return circular_circumorder(int(x), len(x))
    return circular_circumorder(int(x), shift)


