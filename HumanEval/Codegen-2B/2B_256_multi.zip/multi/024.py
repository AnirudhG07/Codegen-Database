

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    mod = n % 2
    n  = n // 2
    if mod == 0:
        return n
    while n % 2 == 0:
        n = n // 2
    return n

'''
Takes an input number, returns it as the largest number that divides evenly
'''
