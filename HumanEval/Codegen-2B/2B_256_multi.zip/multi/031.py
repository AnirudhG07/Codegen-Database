

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    prng = range(2,int(n)+1)
    nbrs = 0
    for index in range(len(prng)):
        p = prng[index]
        for i in range(2,n):
            if p*p + (n-i) > n: break
            if p*p + i < n:
                return False
        nbrs += 1
    return nbrs == 1
    
