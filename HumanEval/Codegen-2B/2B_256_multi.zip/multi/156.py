
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    mininum = "M"
    while number > 0:
        roman = "".join(
            [mininum[num[i]] for i in range(1, sum(number) + 1)])
        number, roman = number // 10, roman[:-1]
        mininum = roman[0] + mininum[1]
    return roman
