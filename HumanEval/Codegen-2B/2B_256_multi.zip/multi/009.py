from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    for element in numbers:
        while len(numbers) > 1 and element <= numbers[-1]:
            numbers.pop()  # elt below max
        numbers.append(element)
    return numbers


if __name__ == "__main__":
    import doctest

    doctest.testmod()
