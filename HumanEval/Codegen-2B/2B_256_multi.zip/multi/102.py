
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    while y >= x + 1:
        yield x
        x += 1

    while True:
        if x <= y:
            x += 1
        else:
            y -= 1
            x -= 1


class TwoLayersNetwork:
    """This class is designed to represent the neural network for the two
    layers problem. It will take 2 inputs representing the number of the
    left hand side of the equation and the number of the right hand side of
    the equation and return the sum of the inputs."""

    def __init__(self, num_l_inputs):
        """Constructor"""
        self.num_l_inputs = num_l_inputs

