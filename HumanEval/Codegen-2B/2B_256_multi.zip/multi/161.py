
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    res = []
    i = 0
    j = len(s) - 1
    if len(s) == 0:
        res.append(s)
    for char in s:
        if isalpha(char):
            res.append(chg(char.lower(), char.upper()))
        else:
            res.append(char)
    while i < j:
        if ord(res[i]) > ord(res[j]):
            res.insert(i, chg(res[j], res[i]))
            break
        elif ord(res