

def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    n_odds = [n for n in range(len(l)/2) if n % 2 == 1]
    n_evens = [n for n in range(len(l)/2) if n % 2 == 0]
    return sort_even(n_odds + n_evens, l[n_odds:]) + [j for j in l[:n_odds] for k in xrange(len(l[:n_odds]))] \
    + sorted(l[n_evens:])


