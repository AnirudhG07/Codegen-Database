
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    # Assigning unique characters to each word
    unique = set(words)
    # Creating a map whose key is word and value is a list of unique
    # characters in that word.
    chars = {}
    for elem in unique:
        if elem in chars:
            chars[elem].append(elem)
        else:
            chars[elem] = [elem]

    # Return the word with maximum number of unique characters
    maxnum = max(chars, key=lambda d: d