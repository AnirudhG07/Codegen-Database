
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    # Make a dictionary from the string and fill in each letter with the number of times it appeared in the string
    letters = {}
    for letters_, freqs in re.findall('[abcdef][a-f]', test):
        letters[letters_] =''.join(freqs[::-1]).zfill(letters_)
    letters = dict(sorted(letters.items(),  key=