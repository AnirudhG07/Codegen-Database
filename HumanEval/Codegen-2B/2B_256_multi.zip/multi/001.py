from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    paren_string_split = paren_string.split('(')

    paren_dict = {
        ")": "(",
        "))": ")("
    }

    paren_list = [paren_dict[paren] for paren in paren_string_split]

    # Remove unnecessary trailing empty strings from the list
    for string in paren_list:
        if len(string) == 0:
            paren_list.remove(string)

    return paren_list


