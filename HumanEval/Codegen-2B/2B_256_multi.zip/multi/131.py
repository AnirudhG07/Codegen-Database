
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    return sum(map(lambda i, x: x % 2, str(n)))

class Solution:
    # @param {integer} n
    # @return {integer}
    def reverse(self, n):
        if not n:
            return 0
        if not n % 10 or n % 100 > 53 or n % 100 < 12:
            pow = 10
        else:
            pow = pow(10, (n % 10) * 10)
        n = n // 10
        res = n * pow
        return res
