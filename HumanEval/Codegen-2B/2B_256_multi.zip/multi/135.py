
def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    seen = [None]*len(arr)
    def arrange(arr, i):
        if arr[i] > arr[seen[i]]:
            if i >= len(seen): # i is last position in arr
                return i
            seen[i] = arrange(arr, seen[i])
        else:
            i = seen[i]
        return i
    return arrange


