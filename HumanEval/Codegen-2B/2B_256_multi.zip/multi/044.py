

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    
    numeral_regex = re.compile('(\d+)(?:[a-zA-Z]+)?(?=\s*[^a-zA-Z]+|\s*$|\s*\Z)', re.MULTILINE)
    return ''.join(re.findall(numeral_regex, base_to_numeral(dec_to_bases(x, base))))



if __name__=='__main__':
    num_input = input("Input number: ")
    print(num_input)
    print("Base 3")
    print(num_input_to_numeral(num_input))
