

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    n_minus_1 = n - 1
    n_minus_2 = n - 2

    fizz = 0
    buzz = 0

    # loop over the first two digits of n, if a digit is 7, increment both
    # fizz and buzz, if a digit is 6, increase buzz, otherwise reset both
    # and proceed
    for i in range(n - 1):
        if i == n_minus_1:
            fizz += 1
        elif i == n_minus_2:
            buzz += 1
        else:
            fizzy = fizz * 7
            buzzy = buzz * 6
            fizz = fizzy + fizzy
            buzz = buzzy + buzzy

    return fizz