
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    def decode(r):
        new_r = ''
        for c in r:
            new_c = c.swapcase
            # if it's a vowel, replace the other 2 letters with the
            # letter that's in 2 places ahead of that letter in the
            # english alphabet.
            if c.isupper() and (message.isupper() or
            message[(r.index(c) - 1):(r.index(c) + 2)] not in string.ascii_lowercase):
                new_c = message[(r.index(c)