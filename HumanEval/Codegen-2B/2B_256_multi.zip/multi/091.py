
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    bored = 0

    for word in S.split('.'):
        if word == 'I':
            bored += 1

    return int(bored)


if __name__ == '__main__':
    sol_1 = 'The rain in Spain falls mainly on the plain.'
    sol_2 = "This is a boring sentence."

    assert is_bored(sol_1) == 1
    assert is_bored(sol_2) == 0

    total_bored = 0

    for i in range(10_000):
        sentence = str(random.random())