
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    starts = starts_digits(n)
    # If starts consists of only single digit, we can do it directly.
    if n - starts.count('1') in range(2, 10):
        return starts.count('1')
    return int(numpy.ceil(starts.count('1') * 1.0 / len(starts)))
