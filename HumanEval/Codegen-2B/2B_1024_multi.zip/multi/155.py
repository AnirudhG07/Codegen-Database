
def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    return (len([x for x in str(num) if int(x) % 2 == 0]), len([x for x in str(num) if int(x) % 2 == 1]))


num = int(input())

odd_even_count = even_odd_count(num)

print('num : %d' % num)
print('odd_even_count : %s, %s' % (odd_even_count[0], odd_even_count[1]))

# num = 100
# count = ['one', 'two', 'three']
# even_or_odd_count = [0, 0]

# for i in count:
#     odd_or_even_count[i % 2] += 1
#     if i % 2 == 0:
#         even_or_odd_count[0] += 1
#     else:
#         odd_or_even_count[1] += 1

# print ('num : %s' % num)
# print ('even_or_odd_count: %s, %s' % (even_or_odd_count[0], odd_or_even_count[1]))


x = 0
y = 0
cnt = 1

for i in range(num):
    if i % 2 == 0 and i < 100:
        x += 1  # x is the number of 'even' numbers
    elif i % 2!= 0 and i < 100:
        y += 1  # y is the number of 'odd' numbers
    else:
        cnt += 1  # This will occur 99 times. That is no solution.

    if cnt % 1000 == 0:
        print('The %d most frequent characters were :' % num, end='')
        if y >= x:
            print('%d, %d' % (x, y))
        elif y == 0:
            print('even', end='')
        elif x == 0:
            print('odd', end='')
        else:
            print('',x,y)

    cnt = 1
