

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    coefficients = list(list(i) for i in xs)
    N = len(coefficients)
    derivative = list()
    for i in range(1, N):
        derivative.append(1.0)
        derivative.append(coefficients[0])
        for j in range(1, i):
            derivative.append(coefficients[i-j]*derivative[i-j] +
                              coefficients[i]*derivative[i-j])
    return derivative
