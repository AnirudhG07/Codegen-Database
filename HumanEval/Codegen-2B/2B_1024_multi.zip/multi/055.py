

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    # See https://en.wikipedia.org/wiki/Fibo_sequence
    a, b, c = 0, 1, 1
    while a < n:
        c, b = b, c + b
        a, b = a + b, c + b
    return c + b

# A more efficient approach
# def fib(n):
#     """
#     Return nth Fibonacci number.
#     >>> fib(10) == 55
#     True
#     >>> fib(1) == 1
#     True
#     >>> fib(8) == 21
#     True
#     >>> fib(-1) == -1
#     True
#     >>> fib(-8) == -21
#     True
#     """
#     if n < 0:
#         return -1
#     try:
#         n = list(fib(n // 2), 0) + list(fib(n // 2), 0) + [n]
#     except ZeroDivisionError:
#         pass
#     return n[0]

if __name__ == '__main__':
    import doctest
    doctest.testmod()

    print(__doc__)
    print("-" * len(__doc__))
    print(fib(2); print(fib(3); print(fib(4)), 3))
    def fib(n):
        if n < 0:
            return -1
        try:
            return list(fib(n // 2), 0) + list(fib(n // 2), 0) + [n]
        except ZeroDivisionError:
            pass
        return n
    print(fib(2); print(fib(3); print(fib(4)), 3))
    print(fib_1(20))





    