
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello!!!Wdlor'
    """
    wordlist = []
    for w in s.split():
        for i in range(len(w)):
            for j in range(i+1, len(w)):
                if w[i] > w[j]:
                    wordlist.append(w[:j] + w[j+1:])
                    wordlist.append(w[:j] + w[j+1:])
                    wordlist.append(w[:j] + w[j+1:])
                    wordlist.append(w[:j] + w[j+1:])
                    wordlist.append(w[:j] + w[j+1:])
                    wordlist.append(w[:j] + w[j+1:])
                    wordlist.append(w[:j] + w[j+1:])

    # Return the unique list.
    return repr(list(set(wordlist)))


print(anti_shuffle('hello world'))

# Testing cases
s = 'how do you do?'
print(anti_shuffle(s))

s = 'Hi'
print(anti_shuffle(s))

# Outputs:
# 'h i e h o', 'hu w l d', 'hi h ue', 'hi h o', 'he h i', 'hu w l d', 'hu w l d'

