
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    if -1 <= a <= 255:
        # for each x between 0 and 255 inclusive, check for
        # x * x * x = a.
        padsum = 0
        for i in xrange(1, 3):
            a *= a
            padsum += a
        return padsum == a
