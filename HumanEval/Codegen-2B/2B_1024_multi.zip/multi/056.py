

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    n_open = 0
    n_close = 0
    for i in range(len(brackets)-1):
        if brackets[i] == '<': n_open += 1
        if brackets[i] == '>': n_close += 1
    if n_open!= n_close and n_close!= 0:
        return False
    return True

if __name__ == "__main__":
    import doctest

    doctest.testmod()

"""
if __name__ == "main":
    import doctest

    doctest.testmod()
"""