
def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    # write your code here
    L = len(array)
    if L == 0:    return array
    pos = L - 1
    neg = 1
    while pos > neg:
        #print pos, neg, L
        while pos < L and array[pos] == 0:
            pos += 1

        while neg >= 0 and array[neg] == 0:
            neg -= 1

        if neg + pos + 1 < L:
            print "pos", pos, "neg", neg, "pos + neg", pos + neg
            t = sum(array[:pos] + array[pos + neg + 1:])
            if t % 2 == 1:
                pos = pos + 1
            else:
                neg = neg + 1
        else:
            break
    return array

if __name__ == "__main__":
    arr = list(map(int, raw_input().strip().split(",")))
    print " ".join(map(str, sort_array(arr)))



