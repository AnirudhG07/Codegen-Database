from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    dists = []
    for value in numbers:
        dists.append(distance(numbers[0], value))
    for i in range(len(numbers)):
        for j in range(1, i + 1):
            prev = numbers[i - 1]
            next = numbers[j]
            # Calculate distance between prev and next, taking into account that
            # there is a small error between two values
            # For example, 0.5 + 0.2 => 0.6
            dists[i] = distance(prev, next) - dists[j - 1]
            # If the distance between prev and next is less than or equal to
            # the given threshold, return True
            if abs(1.0 - dists[i]/dists[j]) <= threshold:
                return True
    return False
