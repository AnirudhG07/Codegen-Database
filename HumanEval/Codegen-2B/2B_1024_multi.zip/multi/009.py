from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    maxes = [x for x in take(int(len(numbers) - 1), numbers)]
    idx = 1
    for number in numbers:
        if number == maxes[idx - 1]:  # We only need to take the maximum from one list
            maxes[idx - 1] = number
        else:
            maxes[idx] = max(maxes[idx - 1], number)
        idx += 1

        if idx == len(maxes):
            maxes = maxes[:idx]  # If more elements were rolled, roll again for the next list

    return maxes
