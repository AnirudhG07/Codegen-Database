
def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    # Initialize largest valid index; initialized to -1.
    largest_valid_index = -1
    # For each element in the array
    for x in arr:
        # Ignore an element that has not been set to a minimum value
        if smallest > x:
            smallest = x
            # If there isn't any index greater than the current element
            # then we have found the largest valid index
            # which is at least the current element and before it in the array
            if largest_valid_index == -1:
                largest_valid_index = i
        # After finding a new valid index just go to the next index
    # If the given array will not contain any element greater than the
    # smallest_index we return smallest_index
    if (largest_valid_index!= -1):
        return largest_valid_index
    else:
        return -1

largest_valid_index = can_arrange(
    [1, 17, 3, 11, 0, 2, 11, 37, 43, 1, 7, 13, 24, 29, 8, 20, 10, 2]
)
print largest_valid_index

largest_valid_index = can_arrange(
    [1, 17, 3, 11, 0, 2, 11, 37, 43, 1, 7, 13, 24, 29, 8, 20, 10, 2]
)
print largest_valid_index

largest_valid_index2 = can_arrange(
    [0, 1, 5, 3, 4, 9, 21, 28, 22, 29, 30, 31, 37, 38, 39, 40, 42, 43, 45, 66, 77, 78, 79, 88, 90]
)
print largest_valid_index2

largest_valid_index3 = can_arrange(
    [1, 17, 3, 11, 0, 2, 11, 37, 43, 1, 7, 13, 24, 29, 8, 20, 10, 2]
)
print largest_valid_index3

