
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    cycm= []
    for i in range(0,len(b)):
        cycm.append([True] * 32)
    b=b+b[0]
    for i in cycpattern_step(a,len(b),0):
        for j in range(0,len(i)):
            cycm[i[j]][j] = False

    for j in range(len(a)):
        cycm[j][0] = False

    for i in range(0,len(a)):
        if cycm[i][0] is True:
            for j in range(1,len(a[i])):
                for k in range(0, len(b)):
                    if cycm[i][k] is False and cycm[k][j] is True:
                        cycm[i][j] = True
    return cycm[0][-1]

