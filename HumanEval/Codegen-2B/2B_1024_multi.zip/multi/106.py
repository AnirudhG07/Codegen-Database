
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 *... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    ans = [1]
    for i in range(1, n + 1):
        ans.append(ans[i] + ans[i - 1])
    return ans


if __name__ == "__main__":
    T = int(input())
    for t in range(T):
        N = int(input())
        n, k = map(int, input().split())
        answer = list(map(lambda x: f(x) if x % 2 == 0 else 0, range(k, n + 1)))
        print(*answer)
