
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    def decimal(value):
        return float(value)

    def integer(value):
        return int(round(float(value)))

    def closer(a, b, c):
        '''
        Compares the first two arguments, returning a negative number if the
        first is closer to the first argument of the function, a positive
        if the second is closer, or 0 if the two are the same.
        '''
        d = c - a
        if abs(d) < abs(b - a):
            return d
        else:
            return b - a

    def get_closest(value):
        if round(decimal(value)):
            return integer(value)
        elif decimal(round(value)) >= 0:
            return integer(round(value))
        elif decimal(round(-value)) >= 0:
            return -integer(round(-value))
        else:
            return 0

    def closest(value):
        '''
        Returns the closest integer to the number, or 0 if there's any
        difference.
        '''
        if closest_value == value:
            return closest_value
        else:
            return get_closest(value)

    closest_value = get_closest(value)
    if closest_value == value:
        return value
    else:
        return closest(closest_value)


