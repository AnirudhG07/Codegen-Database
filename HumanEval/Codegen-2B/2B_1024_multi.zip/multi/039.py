

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    p = [1]
    k = 2
    while k <= n and not any(s in p for s in p):
        s = p[-1]
        p.append(s+s)
        k += 1
    return k

