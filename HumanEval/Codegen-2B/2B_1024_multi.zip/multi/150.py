
def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """
    if n >= 2 and n % x == 0 and n % y == 0:
        return n
    else:
        return y
            
#test xor_y
tests = [
[31, 5, 7, 4],
[17, 7, 5, 3],
[17, 8, 4, 3],
[11, 7, 5, 2],
[11, 16, 4, 2],
[11, 16, 5, 2],
[16, 4, 10, 10],
[8, 4, 10, 10],
[8, 10, 12, 10],
]

for test in tests:
    print("x = %d, y = %d" % (test[0], test[1]))
    print("result = %d" % x_or_y(test[0], test[1], test[2]))
    
    