from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    result = []
    len_prefix = len(string)
    pre_index = 0
    while True:
        if pre_index + len_prefix > len(string):
            result.append(string[pre_index:])
        else:
            pre_index += len_prefix
            break
    result.reverse()
    return result


if __name__ == '__main__':
    import doctest

    doctest.testmod()
