
def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''
    counter = collections.Counter(elem for elem in lst)
    ret = max(elem for elem in sorted(counter) if counter[elem] >= lst.count(elem))
    return ret 
'''
For this problem, we will assume the numbers in the given list are positive. We use a dictionary to store 
the frequencies of the integers. A dictionary entry stores a pair of integer (key, value).
The frequency of a given integer is the number of times it appears in the given list.
Here, we start with the key 0.  Thus, we need to get a value with frequency zero as we proceed through our 
analysis.
We also initialize the dictionary with a pair of integers for the key 0. This pair means there is exactly 
one integer in the list which has frequency zero.
When we add an entry to the dictionary, we keep track of the value of our newly created pair so that we 
can use it later.
Here comes the real core of the algorithm:
When we traverse through our dictionary and encounter a zero value, we call a dictionary entry out of 
balance. We know:
    The zero value (pair) we encountered is (k, v) (our original value), with a frequency of zero, and we 
    have a value v in the dictionary with a frequency of k-1
    And we encounter a non-zero value and we know that pair (k, old) (we are on the wrong page). We have a new pair 
    (new, old) of key v and value k and we update the dictionary with the new pair, with the value of old as 
    a value for the zero key.
We repeat the process until it stops.
'''