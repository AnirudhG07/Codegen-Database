
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    test = test.upper().replace(' ', '')
    counts = defaultdict(int)


    # Remove consecutive characters and check that it's a valid case
    for i in range(len(test)):
        if test[i + 1] == test[i]:
        # For the first character, remove the 'a' because it shouldn't be repeated.
            if test[i] =='' and i < 2:
                continue
        # For the others, remove it if it's not a digit.
            elif not test[i].isdigit():
                test = test[i + 1:]

        counts[test[i]] += 1        
    result = {}
    # Iterate through the remaining test as a series of digits
    for i in range(len(test)):
        value = int(test[i])
        if 0 <= value < 10:
            result.setdefault(value, 0)
            result[value] += 1
    return result


    
if __name__ == '__main__':
    import doctest
    doctest.testmod()
