

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    num_divisors = [
        prime(n // i)
        for n // i in range(0, math.floor(math.sqrt(n)))
        if 0 <= i < int(math.sqrt(n)) and n % i == 0
    ]
    return num_divisors[0]


