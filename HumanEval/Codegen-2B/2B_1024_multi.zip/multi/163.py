
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    generator = range(a, b + 1)
    for _ in range(2, int(sqrt(b)) + 1):
        for i in range(a, b + 1 - i):
            if not (b % i):
                generator.append(b / i)
    return [int(e) for i, e in enumerate(reversed(sorted(list(generator))), start=1)][::-1]

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 get_first.py first_num last_num")
    elif (sys.argv[1] > sys.argv[2]):
        print("First number is greater than last number")
    else:
        a = int(sys.argv[1])
        b = int(sys.argv[2]) + 1
        print("First {0} - Last {1}".format(a, b))
        print(generate_integers(a, b))
