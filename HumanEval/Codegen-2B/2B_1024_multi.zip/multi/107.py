
def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """
    if n <= 1:
        return 0, 0

    odd_count = 0  # Counted even integers in the range from 2 to n
    odd_start = 2
    odd_end = n

    # The count for even integers
    even_count = 0
    even_start = 1
    even_end = n

    while odd_end > odd_start + 1:
        start = odd_start
        end = odd_end

        # Find a range of odd integers with the same length (n)
        odd_start = end
        odd_end = end + (end - start + 1) % 2
        # Find a range of even integers with the same length (n)
        even_start = end
        even_end = end + (end - start + 1) / 2

        # If length of odd integers is 2 or greater, start palindrome counting
        # from the end of the range and the beginning of another palindrome
        # range.
        if odd_end > odd_start + 1:
            odd_count += even_end - 1
            even_count += end - start + 1

    return odd_count, even_count
