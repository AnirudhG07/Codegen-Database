
def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''
    if len(lst) < 2:
        return True  # empty list is sorted
    sorted_list_length = len([i for i in lst if i!= i - 1])
    if sorted_list_length == len(lst):
        # sorted list of length of list, just to save the first element
        return is_sorted(lst[:-1] + [lst[0]])
    else:
        return False  # sort failed


class Solution:

    # @param k, an integer
    # @return a string

    def largestPalindrome(self, k):
        # Step 1: The largest palindrome product could potentially be the maximum integer.
        answer = str(max(k * k, 0))
        if k > 1:
            # Step 2: Find the largest palindrome product which is less than k.
            answer = '(' + str(self.largestPalindrome(k - 1)) + ')*' + answer
        else:
            return answer

        # Step 3: Find the largest palindrome product which is greater than k.
        answer = '(' + str(self.largestPalindrome(k + 1)) + ')*' + answer
        # print('Step 3 return:' + answer)

        return answer


if __name__ == '__main__':
    solution = Solution()
    print(solution.largestPalindrome(10))
