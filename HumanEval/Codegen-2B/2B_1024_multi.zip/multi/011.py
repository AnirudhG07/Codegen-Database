from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    bits = [ord(a[0]) >> 1 & 1, 0 if len(a) > 1 else ord(a[1]) >> 4 & 1]
    bits.extend([0, 0] if len(b) > 1 else [ord(b[0]) >> 1 & 1, 0])
    return ''.join(map(chr, bits))


