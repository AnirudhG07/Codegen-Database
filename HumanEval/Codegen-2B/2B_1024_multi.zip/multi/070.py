
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    def get_min(lst):
        min_val = int(min(lst))

        return min_val

    if not lst:
        return lst

    result = []

    min_val = get_min(lst)

    # start with the minimum value, then move to the maximum,
    # and so on for each remaining integer
    for i in range(min_val, len(lst) + 1, min_val):
        for j in range(len(lst) - i, 0, -1):
            result.append(lst[j])

    return result


