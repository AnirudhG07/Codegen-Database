
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    start_count = 0
    end_count = 0

    for i in range(1, n + 2):
        for x in range(1, n):
            if str(i) == str(x) + str(n - x):     # Example: "21" + "6" -> "21"
                start_count += 1
            elif str(x) + str(n - x) == str(i):   # Example: "6" + "21" -> "6"
                end_count += 1

    return start_count, end_count


if __name__ == "__main__":
    n_cases = 1
    for _ in range(n_cases):
        print("testing {0}".format(n_cases))

        start_count, end_count = starts_one_ends(random.randint(2, 20))
        print("counting started:{0}, end:{1}, count:{2}".format(
                start_count,
                end_count,
                str(start_count) + str(end_count)),
              end='')
        print('-')
