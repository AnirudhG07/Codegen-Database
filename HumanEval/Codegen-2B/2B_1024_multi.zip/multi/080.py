
def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """
    ans = len(s)
    letters = set()
    for i in range(ans):
        if s[i] not in letters:
            ans -= 1
        elif i is not 0:
            ans -= 1
            while i + 1 < ans and s[i + 1] in letters:
                ans -= 1
        letters.add(s[i])
    return ans >= 3

start = timeit.default_timer()

ans = 0
for s in s:
    ans = max(ans, is_happy(s))

end = timeit.default_timer()

print(end-start, ans)
