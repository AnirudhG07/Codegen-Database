
def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    if n == 0:
        return []
    prime_found = [0, 1]
    if n <= 2:
        return prime_found
    prime_found = prime_found + count_up_to(n-2)
    sieve = [True] * (n+1)
    j = 1
    prime_found[1] = 1
    while j < n:
        if sieve[j]:
            prime_found[j] = 0
        for p in prime_found:
            sieve[p+j] = False
        j += 1
    prime_number_counter = n
    while prime_number_counter > 2:
        p = prime_number_counter
        while p % 2 == 0:
            prime_number_counter -= 1
            p //= 2
        prime_found[p] = 0
        prime_number_counter += 1
    result = []
    for i in range(2, n + 1):
        if prime_found[i] == 1:
            result.append(i)
    return result

if __name__ == '__main__':
    # print(count_up_to(5))
    print(count_up_to(11))
    print(count_up_to(4))
    print(count_up_to(100))
    print(count_up_to(100))
    print(count_up_to(0))
    print(count_up_to(20))
    print(count_up_to(1))
    print(count_up_to(18))
