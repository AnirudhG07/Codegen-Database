
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    count = 0
    for i, num in enumerate(nums):
        if num > 100:
            if num % 10 == 0 and num % 100 > 10 and num < 200 and \
                    sum(num % 10) % 2 == 1:
                print >>sys.stderr, "nums contains element >= {}, {}".format(num, nums)
            count += 1
            print num
    print count
    return count


