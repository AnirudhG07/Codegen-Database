
def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """
    col_w, row_h = len(grid), len(grid[0])
    res = [[0 for j in range(row_h)] for i in range(col_w)]
    for i in range(col_w):
        for j in range(row_h):
            cur_value = grid[i][j]
            if cur_value:
                for b_id in range(bucket_capacity):
                    res[i][j] += 1
    def check_val(a, b, c):                    # p(b,c) = 0 if a < 0 and b < 0 and c < 0 and a+b+c < 0
        return sum([i for i in a, b, c if i!= 0])

    for i in range(col_w):                      # p(b,c) : p(b,c)|p(c,b)
        if res[i][i] > 1:
            res[i][i] = 1    # p(b,c) : p(b)|p(c)
        else:
            res[i][i] = 0
        for j in range(row_h):
            if res[i][j], res[j][i]:          # p(c,b) : p(c)
                res[i][j] += res[j][j] > 0   # p(b,c)|p(b)|p(c)

    for i in range(col_w):
        for j in range(row_h):
            if res[i][j]:            
                res[i][j] = check_val(res[i][j], res[j][i], 1) # p(b,c)|p(b,c), p(b,c)
            else:
                res[i][j] = 0
    return sum(res)

if __name__ == "__main__":
    print(max_fill([[0, 0, 0, 0], [0, 1, 1, 0], [1, 1, 1, 0], [0, 1, 1, 1]], 1))
    print(max_fill([[0, 0, 1, 0], [0, 1, 0, 0], [0, 1, 1, 1]], 1))
    print(max_fill([[0], [0], [1]], 0))
