
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    def increment_for_roman(base, i):
        while i >= 9:
            base = 'M' + base[:2] if base.endswith('M') else base[:-1] + 'M'
            i -= 9
        return base + str(i+1)
    return ''.join(increment_for_roman(m, i) for i in range(1, 1000+1)
                   if i <= number).upper()

