

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    assert isinstance(string, str), \
       'string parameter %s must be of type str, but is of type %s' % \
        (string, type(string))
    return len(string)


