
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    if not dict:
        return False

    # check for all dictionary keys in lower case
    for key in dict:
        if key.lower()!= key:
            return False

    # check for all dictionary keys in upper case
    for key in dict:
        if key.upper()!= key:
            return False

    return True


# check_dict_case("{'id': 1, 'title': 'Title', 'content': 'Content'}")
# check_dict_case("{'id': 1, 'title': 'Title', 'content': 'Content'})
# check_dict_case({"id": 1, "name": "Name"})
# check_dict_case({"id": 1, "name": "Name"})
# check_dict_case({"id": 1, "name": "Name", "dynamic": "value"})

# check_dict_case({1: None, 2: None})
# check_dict_case({"1": None, "2": None})
# check_dict_case({"1": None, "2": None})
# check_dict_case({1: '', 2: None})
# check_dict_case({"1": '', "2": None})
# check_dict_case({"1": '', "2": None})

if __name__ == '__main__':
    main()