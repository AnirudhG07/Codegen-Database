from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return ''.join(string for string in strings if string).strip()


if __name__ == '__main__':
    # The solution above is N logN solution
    cases = [
        ([], 'abc'),
        (["", "a"], "a"),
        (["a", "a", "a"], "abc"),
    ]
    for c, s in cases:
        print('Case {}: ". ".join(["".join(s)] + [s2.split(" ")[1].lower() for s1 in s for s2 in s1])'.format(c))
