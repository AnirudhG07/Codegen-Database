
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    subsum = [0 for _ in range(1, n + 1)]
    sum_so_far = 0
    for i in range(n - 1, -1, -1):
        cur = nums[i]
        if cur == 0:
            if i in subsum:
                sum_so_far += cur
                subsum[i] -= 1
            continue
        k = i - 1
        newsub = [subsum[j - 1] + nums[k + j] for j in range(1, i + 1)]
        newsub.append(subsum[i])
        subsum = newsub
        sum_so_far += cur
    return sum_so_far
        