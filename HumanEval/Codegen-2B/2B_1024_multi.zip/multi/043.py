

def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """
    sums = []
    for p in l:
        sums.append(p)
        sums.sort()
        for i in range(1, len(sums)):
            if sums[i]+sums[i-1]==0:
                return True

    return False

if __name__=="__main__":
    num_cases = int(raw_input())

    for case in range(1, num_cases+1):
        num = raw_input()
        if pairs_sum_to_zero(num.split(" ")):
            print ""
        else:
            print "Case #" + str(case) + ": " + str(num) + " is not pairs-sum to zero"
