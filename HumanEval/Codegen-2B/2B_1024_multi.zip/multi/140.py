
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    
    
    text = ""
    text2 = ""
    text3 = ""
    
    for i in text:
        if (i!=''):
            text3 += i
        if i =='':
            text = text3
            text2 = ""
            text3 = ""
        elif i =='':
            text = text2
            text2 = ""
            text3 = ""
    text = text3
    text = text.strip()

    return text.replace(' ','_').replace(',','-').replace('/','-').replace('&','-').replace('\\')


