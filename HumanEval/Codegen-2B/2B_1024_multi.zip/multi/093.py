
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    # I used PyMOL's encode command for the code below, but it was too hacky.
    
    # encode the message using PyMOL's encode command
    result = ""
    for letter in message:
        if 'a' <= letter <= 'z':
            # letters within the range of A-Z can be encoded as ascii
            result += chr(48 + ord(letter) % 36)
        else:
            # letters between A-Z and a-w are case-swapped
            result += chr((ord(letter) - 65) % 36 + 65)
    return result


