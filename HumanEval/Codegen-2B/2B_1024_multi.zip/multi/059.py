

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    prime_factors = [1]
    i = 2
    while n // i >= 1 and i < 10**6:
        n //= i
        if n == 1:
            return i
        prime_factors.append(i)
        i += 1
    n = n % i
    for j in xrange(1, int(math.sqrt(n)) + 1):
        if n % j == 0:
            prime_factors.append(j)
            if j * j!= n:
                prime_factors.append(n / j)
            if j * j == n:
                break
    return n if len(prime_factors) == 1 else prime_factors[-1]


class TestTheorem(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(TestTheorem, self).__init__(*args, **kwargs)

    def runTest(self):
        pass

    def shortDescription(self):
        return None

if __name__ == "__main__":
    unittest.main()
