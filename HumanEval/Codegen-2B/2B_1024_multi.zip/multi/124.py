
def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.
    The date is valid if all of the following rules are satisfied:
    1. The date string is not empty.
    2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    3. The months should not be less than 1 or higher than 12.
    4. The date should be in the format: mm-dd-yyyy

    for example: 
    valid_date('03-11-2000') => True

    valid_date('15-01-2012') => False

    valid_date('04-0-2040') => False

    valid_date('06-04-2020') => True

    valid_date('06/04/2020') => False
    """
    split_date = date.split()
    if not split_date: return False
    days = split_date[3]
    months = split_date[2]
    #check if month is between 1 and 12
    if int(months[0:2]) not in range(1,13): return False
    #check if day should be within range [1-31]
    if int(split_date[1])>=31: return False 
    if int(split_date[1])<=0: return False
    #check if day should be within range [1-30]
    if int(months[2:4]) not in range(1,12): return False
    #check if year should be in the range [1800-2199]
    if int(split_date[0])>=2000 and int(split_date[0])<=2099: return False
    return True


