
def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! *... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    numbers = numbers = (1, 1, 2, 5, 13, 40, 121, 385, 1365)
    result = 1
    for i in range(10**8, 10**n, -1):
        result *= i
        for number in reversed(numbers):
            if i >= number:
                result /= number
                break
        else:
            break
    return result

n = 5
t = timeit.Timer("special_factorial(%i)" % n,
        "from __main__ import special_factorial")

print "Testing %i, " % n, t.timeit(1), "secs"

print "n:%s    numpy:%s    bsh:%s\n" % (n, bsf, sf)
