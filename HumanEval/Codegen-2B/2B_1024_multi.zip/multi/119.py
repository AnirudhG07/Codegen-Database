
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    # stack is to store opening parentesis and closing parentesis that should be paired up
    stack = []

    for a in lst:
        # if a not a parenthesis character, then
        if a!= '(' and a!= ')':
            continue

        # if a is a parenthesis, and there's a character in the stack
        # (meaning one opened and closed a parenthesis), we pop them off the stack as well
        if a == '(':
            if stack:
                stack.pop()
            stack.append(')')
        elif a == ')':
            if stack:
                stack.pop()
                stack.pop()

        # if a is a parenthesis, and there's no character in the stack
        # (meaning it's not paired with an opening parenthesis), that closing parenthesis
        # should be pushed
        # else discard a
        elif a == ')':
            if stack:
                stack.pop()
            else:
                stack.append(a)
    return not stack or stack == []

# Test cases
