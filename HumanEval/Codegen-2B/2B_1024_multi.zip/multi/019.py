from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five','six','seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    res = ''
    while True:
        n = int(numbers[2:])
        while True:
            if numbers[:2] in ('-1', '00'):
                res += '0' * n
                numbers = numbers[2:]
            else:
                res += numbers[:2]
                numbers = numbers[2:]
                break
    return res


