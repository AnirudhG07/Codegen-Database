
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    # The alphabet should be rotated by 2 characters to two places
    # then repeated three times to complete the function. 
    # There is no limit for how often a character is rotated, however all
    # characters are cycled 3 times. 
    rotated = [list(s)]
    for i in range(len(s)):
        for o in range(3):
            rotated.append(rotate(s[i], o ))
    enc_s = []
    for r in rotated:
        enc_s.append( r[0])
    return enc_s

