
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    result = []
    for word in sentence.split():
        while len(result) > 0 and len(word)!= len(result[-1]):
            result.pop()
        result.append(word)

    return " ".join(sorted(result))


class TestMethods(unittest.TestCase):
    def test_1(self):
        self.assertEqual(words_in_sentence(sentence="This is a test"), "is")
        self.assertEqual(words_in_sentence(sentence="lets go for swimming"), "go for")


if __name__ == "__main__":
    unittest.main()
