

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    word = text.lower()
    for i in range(len(word) / 2):
        if word[i]!= word[-i - 1]:
            return False
    return True

if __name__ == '__main__':
    f = lambda s: s!= '' and s.isalpha() and s.isdigit()
    print(__name__ + ':'+ str(is_palindrome('')))
    print(__name__ + ':'+ str(is_palindrome('abc')))
    print(__name__ + ':'+ str(is_palindrome('ba')))
    print(__name__ + ':'+ str(is_palindrome('abca')))
    print(__name__ + ':'+ str(is_palindrome('zz')))
    print(__name__ + ':'+ str(is_palindrome('aaaa')))
    print(__name__ + ':'+ str(is_palindrome('zbcd')))