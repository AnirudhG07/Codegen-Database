from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    paren_string = paren_string.replace('(', '').replace(')', '').strip()
    paren_count = paren_string.count('(') - paren_string.count(')')
    open_paren = paren_string[paren_count * 2:]
    num_paren = paren_string[paren_count:-paren_count*2]
    paren_list = []
    for p in num_paren.split('()'):
        if p!= '':
            paren_list.append(p)

    return paren_list


if __name__ == "__main__":
    # Test code
    print("Example 1:", separate_paren_groups('()(()(())))'))
    print("Example 2:", separate_paren_groups('())))((())))))()'))))()(")))()(((()))))(())))))(")))()))))()
    print("Exact string :", '())))))()))()()((()))()()))()()()()')
    print(
        "Your paren_count is",
        separate_paren_groups(
            "())())())())()))()()()())())(())(())()))))")
    print("Your paren_count is", separate_paren_groups(
        ')()))())(())))()()()()()(())(()))(())()()()())()())()()()')))))()()(())()()()())()()()()())()()(()))()())())()())()()()()()()()(()))()()()()()()()()'))())()('())('))()()()()()())())()()()()()()()()()()())()()()())()())())(()())(())(())(())()())(()))))(())(()))()()()()()())())(())(())()() )(())()()())(())))()@))))()((()))))))())))))))
    #print(separate_paren_groups('(  ))  (((     (     )()( )()(  )))))() ))))((  ))( )()() (")
    #  ())()() ()))()())() (())() )())(()())()()))()()()() ()(()))() ))(()()())(())())(()))() )))))))()))))())()()()))))))))())))()( )()()()))()()()()()()()()()()()()()()()()()())()()()()()()()()()()()()()())()()))())()(()))()()()()()()()()()()()()()()()()( )()()()())))()()()()()())())())()()())()()()()))( )(())()())()())#(()))))((()))))()))
