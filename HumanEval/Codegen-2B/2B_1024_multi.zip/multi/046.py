

def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    a, b = 0, 1
    while n > 4:
        a, b = b, a + b
        n -= 4
    return a

if __name__ == "__main__":
    #These "asserts" using only for self-checking and not necessary for auto-testing
    assert fib4(3), 'fib4(3)'
    assert fib4(5), 'fib4(5)'
    assert fib4(4), 'fib4(4)'
    assert fib4(5), 'fib4(5)'

    import time

    start = time.time()
    print('Answer: {}'.format(fib4(22)))

    print('Elapsed: {0},  Time: {1}'.format(time.time() - start, start))
