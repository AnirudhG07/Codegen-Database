
def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """
    name_pattern = re.compile("[0-9a-zA-Z.]+")
    if len(file_name) == 1:
        if file_name_ok(file_name[0]) is 'Y':
            return 'Y'
        elif file_name_ok(file_name[0]) is 'N':
            return 'N'
        return ''
    if file_name.count('.') == 0:
        return ''
    if file_name_ok(file_name[:3]) is 'No' or file_name_ok(file_name[0:3]) is 'No':
        print("Please fill out the file name: \n" + file_name)
        return ''
    elif file_name_ok(file_name[:3]) is 'Y' or file_name_ok(file_name[0:3]) is 'Y':
        if name_pattern.findall(file_name)!= []:
            return 'Y'
        return 'N'
    else:
        filename = file_name[0:3]
        # if file_name_ok(filename) is 'Y':
        # print filename, 'is valid as it has exactly one dot.'
        # else :
        # print False
        return 'N'
    # if file_name_valid(filename) is 'Y':
    # return 'Y'
    # else :
    # print 'No, the filename "' + str(filename) + '" is either invalid or already exist in another file of the same name.'
    # print 'Please only use letters and digits from the latin alphanpit range.'
    # return False

# file_name_check("test.txt")

