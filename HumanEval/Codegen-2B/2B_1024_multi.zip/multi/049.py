

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    return pow(2, n % 100, p)


if __name__ == "__main__":
    t = int(input())
    for _ in range(t):
        n, k = [int(i) for i in input().split()]
        for _ in range(k):
            p = pow(10, 1000 - k)
            a = int(input())
            b = float(input())
            x = p * a
            n, _ = fst(x, p)
            y = modp(b, p)
            z = modp(k+1, p)
            print(n, '=', z * x / y)