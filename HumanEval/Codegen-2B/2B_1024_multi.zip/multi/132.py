
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    #TODO: replace the nested brackets with a list of lists 
    nested_brackets = ['[']
    
    #Loop through all the strings in the input string
    for j in range(len(string)):
        curr = string[j:j+1]
        if curr == '[':
            nested_brackets.append(curr)
            #If we found a non-nested bracket within our nested brackets list, the nested bracket at that position
            #must be valid because it is a subsequence of an existing nested bracket
            if nested_brackets[j:].count(string[j:]) > 0:
                return True
    
    return False

#-------------------------------Helper Functions--------------------------------------

#This is an example implementation of a function that takes a string as input
#and returns true if its size is greater than the size of any string in the input
#such that by placing its elements in any order, we find a solution
