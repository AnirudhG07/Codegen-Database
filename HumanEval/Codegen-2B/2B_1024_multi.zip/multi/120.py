
def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """
    assert k > 0 and k <= len(arr)
    maximum = arr[0]
    new_arr = [maximum]
    for i in range(1, k):
        maximum = arr[i] if arr[i] > maximum else maximum
        new_arr.append(maximum)
    return new_arr


class Solution(object):
    def maximumKSquares(self, n, k):
        """
        :type n: int
        :type k: int
        :rtype: List[List[int]]
        """
        if k <= 1:
            return [[]]
        res = [[]]
        max_ = n * n
        for i in range(k, n + 1):
            res.append(sorted(maximum(frozenset(res[-1]), i)))
        return res[:]


if __name__ == '__main__':
    print Solution().maximumKSquares(3, 2)
