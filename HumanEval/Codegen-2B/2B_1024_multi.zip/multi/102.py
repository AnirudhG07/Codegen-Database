
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    if x > y:
        return -1
    result = x
    while x < y:
        x += 1
        result = max(0, result)
    return result



if __name__ == "__main__":
    import sys
    if len(sys.argv) < 6:
        print "Usage: sortfile.py <length> <min> <max> <num> <filename>"
        sys.exit(1)
    print choose_num(int(sys.argv[1]), int(sys.argv[2]))
    #print str(random.randrange(int(sys.argv[1]), int(sys.argv[2]+1)))
    