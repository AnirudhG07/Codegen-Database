
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    # I hate my programming language for not having such an elegant 
    # way of detecting things that I know, but there are some real-world 
    # data sets I'm unsure of that need to be tested against for bugs, and 
    # there, just in case I'm mistaken or if there are any issues with 
    # Python's built-in for loops. Also, if this takes forever, there is 
    # another option from Google... :S
    count = 0
    for word in S:
        if word in BOREDOMS:
            count += 1
    return count

if __name__=='__main__':
    print (is_bored("This is the sentence: I love I"))
    
    



