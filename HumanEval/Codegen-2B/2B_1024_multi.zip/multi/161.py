
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    ret = []
    for i in range(len(s)):
        if s[i].isalpha():
            ret += s[::-1].translate({_key: _method[_key[::-1]] for _key in _method})
        else:
            ret.append(s[i])
    # return str(ret)
    return ''.join(ret)


# p = Solution()
# print p.solve("#a@C")
# p.solve("#a@C")
# print p.solve("A1 B2")
# print p.solve("a2")
# print p.solve("abc")
# print p.solve("")
# print p.solve("a")
# print p.solve("aaa")
# print p.solve("AA")
# print p.solve("aabb")
# print p.solve("a2b3")
# print p.solve("ab2c3")
# print p.solve("")

r = '#a@C'
print solve(r)


# print Solution().solve(r)