

def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """
    return string.replace('a', 'A').replace('e', 'E').replace('i', 'I')\
              .replace('o', 'O').replace('u', 'U').replace('\xfc', 'u')


# if __name__ == '__main__':        
if -1!= __name__.find('docascode__'):
    from docascode.napoleon_extension import *
else: # pragma: no cover
    from docascode.docscrape import *
    from docascotext.docscrape import *
    
__all__ = [get_docscrape_all()[0]]
