from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    assert len(numbers) >= 2

    smallest_numbers = list(numbers)
    largest_numbers = list(numbers)

    smallest_numbers.sort()
    largest_numbers.sort()

    smallest_number = numbers[0]
    largest_number = numbers[0]

    for (current_item, next_item) in zip(smallest_numbers, largest_numbers):
        if current_item!= next_item:
            smallest_number = min(smallest_number, current_item)
            largest_number = max(largest_number, next_item)

    return (smallest_number, largest_number)
