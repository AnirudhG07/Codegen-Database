

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    if len(l1) < 1 or len(l1) > 2:
        raise IndexError()
    if len(l2) < 1 or len(l2) > 2:
        raise IndexError()
    for k in l1:
        for i in l2:
            if k in i:
                return [k]
    if len(l1) == 2:
        return l1
    return [e for e in l1[1] if e not in l2]

if __name__ == "__main__":
    import doctest

    doctest.testmod()
