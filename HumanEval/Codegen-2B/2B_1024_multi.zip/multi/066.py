
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    sum = 0
    for i in range(len(s)):
        sum += chr(s[i])
    return sum


if __name__ == "__main__":
    assert digitSum("hello E") == 69
    assert digitSum("wo ArBld") == 131
    assert digitSum("woAArB") == 66
    assert digitSum("woAAr") == 66

    assert digitSum("XWAAAAX") == 151
    assert digitSum("AAA") == 8
