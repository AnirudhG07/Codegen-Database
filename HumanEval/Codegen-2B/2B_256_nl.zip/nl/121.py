
def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """
    return sum(lst[::2] if i%2 == 0 else i for i in lst)

There are other variations you can make but this version works. There may be a faster algorithm to compute the sum if you change lst to have the larger numbers at the start of the list and smaller numbers at the end.
I hope this helps you to start looking at algorithms for problems. If you get stuck trying to implement one, ask more specific questions!

