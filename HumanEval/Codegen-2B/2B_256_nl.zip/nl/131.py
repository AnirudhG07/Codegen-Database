
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    c = int(n)

    # This is the most efficient way I know of, and it's the best way for my
    # machine of course. Don't try to optimize too hard!
    b = 0
    while c > 0:
        c <<= 1
        b += 1

    if c < 0:
        return 0

    return b

