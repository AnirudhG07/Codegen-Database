
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    n = len(x)
    rn = [ None if i == '0' else n - i + 1 for i, n in enumerate(x) ]

    if shift < 0:
        return '0' * (n + shift + 1)

    for i in range(n - shift, -1, -1):
        rn[i]+='0'
        rn[rn[i]+1]-= '0'

    return '.'.join(rn)

Note in the below example, I replace the '.' with