

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if n < 2:
        raise ValueError("n must be > 0")

    if (n & 1) == 0:
        return 2

    if (n & 1) == 1:
        return 3

    m = 3

    prime_list = []

    while m <= n:
        prime = m

        if m!= 2 and m not in prime_list:
            prime_list.append(m)

        for x in range(3, (prime&1)+1, prime):
  