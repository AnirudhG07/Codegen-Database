
def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    counter = 0
    count_even = 0
    count_odd = 0
    while num:
        num, end = divmod(num, 2)
        if end:
            counter += 1
        elif counter % 2 == 0:
            try:
                count_even += 1
            except ZeroDivisionError:
                pass
 