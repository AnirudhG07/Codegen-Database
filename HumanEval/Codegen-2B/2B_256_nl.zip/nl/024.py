

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    r, c = [int(x) for x in map(str, str(n.bit_length()))[::-1]]
    return largest_divisor(r)
