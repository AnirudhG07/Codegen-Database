

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    import math
    import itertools

    x = math.ceil(math.sqrt(n))

    def is_prime_aux(n):
        """Return true if is_prime(n) is true as determined by is_prime(factorial(n)).
        :return: True if n divides factorial(n)
        :rtype: bool"""