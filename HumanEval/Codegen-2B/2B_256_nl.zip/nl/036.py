

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    return sum(range(1, n+1) if p in (11, 13) else range(1, n-1) for p in [(i for i in xrange(1, int(n+1))) if p%11==7]]


print(fizz_buzz(100))

print("HelloWorld\n")
