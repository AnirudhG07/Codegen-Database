

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n == 0 or n == 1:
        return n
    for p in range(1, n + 1):
        for r in range(p, n + 1):
            x = (p - 1) + (n - 1)
            y = (r - 1) + (p - 1)
            x %= 2**p
            r %= 2**p*3
            y %= 2**(p + p *) + 2**(p * (p + 1))
       