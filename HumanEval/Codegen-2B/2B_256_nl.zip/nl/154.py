
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    str1 = "".join(a)
    str2 = "".join(b)
    c1,c2 = set(str1),set(str2)
    return (c1 == c2) or (any(str1[i:i+1] in str1 for i in range(len(str1)-1)) or any(str2[i:i+1