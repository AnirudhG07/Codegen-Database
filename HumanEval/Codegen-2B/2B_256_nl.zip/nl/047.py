

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    if not l:
        return None
    return int(max(l)[::-1][::-1] + mean(l))

if __name__ == '__main__':
    import doctest
    test = doctest.TestSuite()
    test.make_test(median,'median.Test')
    result = test.generate_examples(1000) # optional
    if result == 0:
        print "OK with doctest"
    else:
        print "doctest failed"
        print result

    print "----------------------------------------------------------------------"
   