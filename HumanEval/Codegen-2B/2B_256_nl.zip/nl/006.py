from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    group_positions = [i for i, p in enumerate(paren_string) if p == '(')]

    if len(group_positions) == 0:
        return []  # No grouping.

    group_depth = 1
    for i in group_positions:
        group_depth *= 2
        pos = group_positions.index(i - 1)
      