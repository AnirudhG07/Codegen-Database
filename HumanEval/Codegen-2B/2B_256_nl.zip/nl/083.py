
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    return int(len(sorted([(i + 1, _) for _ in range(2*x+1) if i + 1 == n+1])[1::2]-2)) if n else 0

#                                                                                                                       #
#                             