
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    n = len(words)
    uniq_chars = dict()
    for word in words:
        uniq_chars[word[0]] = uniq_chars.get(word[0], 0) + 1

    if n == 1:
        return uniq_chars.get(words[0], 0)

    max = uniq_ch