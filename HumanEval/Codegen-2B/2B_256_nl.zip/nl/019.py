from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five','six','seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    if len(numbers) not in range(9):
        return numbers

    numbers = str(numbers)
    number_index = numbers.index(' ')
    if number_index not in range(9):
        return numbers

    # Get the index where each number ends
    end_indexes = [numbers.rindex(" ", number_index) + number_index//10]

    # Convert the index to a number between 0 and 9
