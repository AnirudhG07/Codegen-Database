from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    prefix_generator = (
        prefix_generator
        for prefix_generator in string
        if prefix_generator!= ''
    )

    prefixes: List[str] = []
    for prefix in prefix_generator :
        if prefix in prefixes:
            raise ValueError("Cannot have two duplicates in a row. Found: %s" % (prefix,))
        prefixes.append(prefix)
    return prefixes


