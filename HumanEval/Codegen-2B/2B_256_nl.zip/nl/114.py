
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    result = [0] * len(nums)

    minSum = None
    for i in range(len(nums)):
        curSum = 0
        for j in range(nums[i], -1, -1):
            curSum += nums[i]
        result[i] = curSum
        if curSum < minSum:
            minSum = curSum
    return minSum

