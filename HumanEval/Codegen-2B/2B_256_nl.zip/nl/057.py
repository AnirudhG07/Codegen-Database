

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    return any(a <= b for (a, b) in zip(l, l[1:]))

# ----------------------------------------------------------------------
# The list's indexing can be replaced by a generator
# We use it for a generator of sorted values
# that we pick using a tuple
class Index(object):
    """
    Index of a value in a list
    >>> l = xrange(100)
    >>> list(Index(i) for i in l)
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18