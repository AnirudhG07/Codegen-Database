
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    sum = 0
    evenSum = 0

    for number in nums:
        if number % 2 == 0:
            evenSum += number
            sum += 1
        elif number > 10:
            sum += 1
            evenSum -= number
        else:
    