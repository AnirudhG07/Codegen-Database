

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    c = None
    for i in range(min(a, b), max(a + 1, b + 1)):
        if c is None:
            s = (a + b) // i
            while c!= s:
                if c == s % i:
                    c = s // i
                    return c
        else:
  