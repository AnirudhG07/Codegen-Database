

def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    if y == 0:
        return x

    res = x + y
    return res

if __name__ == "__main__":
    add(2, 3)
    add(5, 7)
