

def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    if number < 0:
        return 0
    if number == float and (number % 1 or number % 1):
        return 1
    dec = 1
    i = number
    while i < len(decimal) and decimal!= 0:
        dec *= decimal
        decimal >>= 1
    return int(dec)
