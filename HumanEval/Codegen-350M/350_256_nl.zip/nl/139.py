
def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! *... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    for i in range(0, special_factorial(n-1)):
        result = 0
        for j in result:
            if i % j == 0:
                result = result*j + i
    return result
print special_factorial(4)

for special_factorial(4) in special_factorial(3) or special_factorial(8):
    print special_factorial