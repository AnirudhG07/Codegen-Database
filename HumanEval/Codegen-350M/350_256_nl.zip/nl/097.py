
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    n, k = a, b
    try:
        c = n * k
    except NameError:
        return 0
    return np.multiply(c, c)

The result is  the number (not digits) of the number that was multiplied.
For the first two cases  it's the product of the 2nd and 2nd digits. If the first 2 digits are zero, nothing is expected.

A:

You may consider taking a look at np.sum for this.

A:

Note that if