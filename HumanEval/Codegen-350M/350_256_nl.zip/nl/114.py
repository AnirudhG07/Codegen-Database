
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    sub_nums = set(nums)
    assert len(sub_nums) == len(nums)
    for i in sub_nums:
        return(i[0]*sub_nums[i[1]])

