

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    def find_distinct_characters(s: str) -> int:
        for char in s.split():
            if char.tolower().count('?')!= 4:
                yield False
    count = 0
    find_distinct_characters(string)
    for character in s[::-1]:
        if find_distinct_characters(character) == True:
            count += 1
    count
    return count

