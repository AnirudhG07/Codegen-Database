

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    assert isinstance(text, str)
    for i in xrange(len(text) - 2):
        if text[i]!= text[i + 1] : return False
    return True


# def get_moves_as_palindromes(string: str = None) -> char:
#    if string is None or is None:
#        return None
#    elif isinstance(string, (str, str, None)):
#        string = string.split()
#  