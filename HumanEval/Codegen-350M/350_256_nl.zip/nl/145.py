
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    num_items = len(nums)

    def first_order_item(iter):
        return num_items[iter]

    sort_by_digits = lambda i: first_order_item(next[i+1:])
    items = [next[i] for i in items]

    for i in range(len(items) - 1):
        items[i] = items[