
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    spaces = re.findall('(?P<=(\\p{Spaces})[' + str(unicode("") + '$|\\\\)])')
    if len(spaces) == 2:
        self.change_all_spaces(spaces[0], spaces[1])
    if spaces[0] == spaces[1], spaces[2] == spaces[3]:
        return False
    return