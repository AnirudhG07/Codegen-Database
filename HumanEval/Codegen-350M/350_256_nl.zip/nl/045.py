

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    return a * (a + 10) // 3

What am I missing here... Is why this isn't working?

A:

The trick with recursion is to think of it as a set - called the recursive set - that traverses the domain, finding all the triangles where a(i) < a(i+1), for values i in [0, a(1).
For example, in Python 2,
a(i)

if i<1
a(i)

for i in [0, a(1)]:
    triangle_area(a(i), a(i + 1))

If you do it in Python 3, 
a(i)
[4, 7, 1]
> triangle_area (5, 3)
7.5

Then recursion would never be hit.
I'm not sure this is how it does it,