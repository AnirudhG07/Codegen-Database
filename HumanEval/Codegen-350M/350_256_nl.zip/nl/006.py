from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    result = []
    for char_range in paren_string.split():
        if char_range:
            paren_value = parse_char_range(char_range)
            if char_range!= "(" and char_range!= ")" and not paren_value:

                nested_parens = []
   