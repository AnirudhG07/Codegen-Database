
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    return word_count(S) == 0


class WordCount(object):
    """
    You can add functions for counting how many words there are, or how many words
    you have seen or are currently reading.

    The functions all evaluate the function `sum()` to get the total.  You can
    then add methods for each of these to your class to create new words.
    """
    def __init__(self, s):