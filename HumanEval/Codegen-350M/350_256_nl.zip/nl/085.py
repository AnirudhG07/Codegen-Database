
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    new = [[2]] * len(lst)
    for m in lst:
        if m > old-1 and m < m-old:
            m += 1
        else:
            m = m - 1

        new.extend(list(new) + add(add(lst)))
    return m


if __name__ == "__main__":
    print(add)
    print(add([]))
