

def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    """
    a = l[0]
    h = l[1]
    return a * h + b for a, b in zip(l, [x for x in a if x > b] )

The basic usage of the function takes the following arguments:
-l: list to return,
-h: a value to calculate positive values,

There are several ways of using this function:

Using a function that returns a value before the sum, something like this:
(import itertools from itertools)
