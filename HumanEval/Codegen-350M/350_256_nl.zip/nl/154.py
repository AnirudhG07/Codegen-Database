
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    # check for 2 "word pairs" (this is how all of "Cycle Pattern" tests use names)
    for i in xrange(len(a)):
        if a[i]==b[i]: return True
    return False

cycword_check = cycpattern_check( "abcd", "ab" )

A:

Your