

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    try:
        res = sorted(n)
    except ValueError:
        res = n

    divisors := res[1:]

    if divisors[0] == len(n) >> 1:
        # no need to check if the divisor is even
        return len(n) // 2
    else:
        # can be divisible by n at most, it is no multiple of n since it is only
        # even so it is smaller than the largest number that divides it
        val := int(res[1]) // n

        n -= res[0] // val