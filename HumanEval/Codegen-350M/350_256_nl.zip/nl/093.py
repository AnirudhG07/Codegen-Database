
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    if word == 'a':
        return ''.join([u'u', u's', u'd', w'{']) for u in word]
    elif word == 'e':
        return ''.join([u'u' for u, v in word.items() if isalpha(v)] for u, v in word.items())
    elif word == 'g':
 