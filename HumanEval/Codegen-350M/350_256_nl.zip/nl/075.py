
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    assert isinstance(a, integer) and a.is_prime, "Can only make primality check if a is number"
    m = float.factorial(a)
    assert m == 1 and is_multiply_prime(m) == False
    assert m == 0 and is_multiply_prime(20) == False
    assert m is x.next_negative and is_multiply_prime(x.next_negative) == False
    assert is_multiply_prime(x.next_negative) and is_multiply_prime(a) == False
    assert 1.__class__ is Multiplicative