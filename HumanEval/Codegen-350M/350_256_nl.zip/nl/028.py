from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return string.join(strings, separator).replace(separator, '')


class Function(object):
    def __init__(self, f: Function) -> None:
        self.f = f
        self.fun = f.__init__
    def __str__(self) -> str:
        return self.f.__class__.__name__ + '(' + self.fun().__call__() + ')'

