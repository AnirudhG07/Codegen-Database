
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    choice, = int(input('Choose number of digits? [y/z] '))

    if choice < 0:
        return -1
    if choice == 0:
        choice = 12

    if choice > 1:
        return choice

    choice = choice + chosen_digits[1:] + chosen_digits[::2] + chosen_digits[3:]
    return choice

