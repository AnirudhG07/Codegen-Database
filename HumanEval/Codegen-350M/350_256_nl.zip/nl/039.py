

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    n = int(power(n, n % n))
    if (n % n) && n % (n % n) == 0:
        return n
    return n % n

# The base module
module = __builtin__.__new__(__name__, (type(n), base(n)))

class BASE(object):
    def __init__(self, x, y):
        # x and y will always be