
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    c = chr(s.rfind("\u") + len(s))
    try:
        return c[0]+c[1]+(c[2]&0x0f)+c[3]
    except ValueError:
        raise Exception("unexpected character with code '"+str(c)+"' in input")


