
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    result = n % 2
    if result == 1:
        return len(start_one_ends(n))

    if result == 2:
        return len(stop_one_ends(n))

    return 0


