

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    for string in brackets.split("<")[::-1] + (" "):
        match, prev, next = string.match(r"\([^"]*\)")
        assert match is prev, "brackets must be closed"
        assert match[1:], "brackets must have one or more closing characters"
        previous, next = match.groups()
        if previous[-1] == "!":