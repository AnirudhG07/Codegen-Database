
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    s_list = lst
    for i in range(len(s_list) - 2):
        if s_list[i] < s_list[i + 1]:
            s_list[i] = s_list[i + 1]
        else:
            s_list[i] = s_