
def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """
    ret = x
    for i in range(n - 1):
        ret = ret + x
    return y

# the following functions return a given value with its correct multiplicity modulo 1
