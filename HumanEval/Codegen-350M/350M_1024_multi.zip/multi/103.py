
def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """
    n = min(n, m) 
    n = max(n, m)
    if(n == 0)  if (m == 0)  return "0b0"
    if(n > m):
        a, b, c, d = (n, m, 1, 1)
        a, b, c = rounded_avg(a, b), rounded_avg(c, d)
        return "%d"%b
    else:
        d = m-n
        b = (1 << m)*d
        return "0b%d" %d

