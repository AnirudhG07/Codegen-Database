
def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1, 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """
    
    if type(arr) not in tuple(range(0, 10)):
        return arr        
    
    new_arr = []
    len_arr = len(arr)
    
    arr = array(arr, 'int') 
    i_first = arr[1]
    i_last = arr[-1]
    if len(i_first)!= len_arr:
        i_first = "None"       
    if len(i_last)!= len_arr:
        i_last = "None"
    len_arr = len_first = len_last = i_first.digits_len
    
    for y in xrange(len_first, 0, -1):
        if i_first[:y]!= '%d' % ((arr[y]+i_first[:y]) % 10):
            new_arr.append(i_first[:y])
            i_first[:y] = "10001"
            i_last[:y] = '100' 
            
    while i_first[:len_first] == '100':
        i_first[:len_first] = '1001'
    while i_last[:len_last] == '10001':
        i_last[:len_last] = '1'
    
    return new_arr