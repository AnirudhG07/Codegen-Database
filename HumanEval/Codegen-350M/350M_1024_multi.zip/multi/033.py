

def sort_third(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the indicies that are not divisible by three, while its values at the indicies that are divisible by three are equal
    to the values of the corresponding indicies of l, but sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    n = len(l)

    if n <= 1:
        return l

    divisors = []
    for i in reversed(range(len(l))):
        divisor = [int(number) for number in l[i:i + 3]]
        if all(divisor[i % 3] > divisor[(3 * i) % 3] for i in divisor):
            divisors += divisor
            break

    divisor_tens = [int(number) for number in l[i:i + 3]]
    if all(divisor_tens[i % 3] > 0 for i in divisor_tens):
        divisor_tens += [0] * (3 * len(divisor_tens) - len(divisor_tens))

    divisor_tens += [0] * (3 * len(divisor_tens) - len(l))

    return [divisor_tens[i % 3] for i in range(len(divisor_tens), (3 * len(divisor_tens)) + 1)]


# O(N^3) implementation (see http://math.stackexchange.com/?p=18092)
