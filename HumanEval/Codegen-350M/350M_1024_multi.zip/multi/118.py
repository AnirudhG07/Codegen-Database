
def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    m = _common_matches('a', 'e')

    # First match for all possible cases, including no match.
    #
    # As an example, consider that word is "yogurt" and will be matched up
    a_matches = match_for_all(m, 'a', 'e', 'g')
    if a_matches:
        return a_matches[0].replace("g", "")
    else:
        return ""
