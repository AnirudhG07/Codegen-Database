
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    try:
        if str(a[b]) == str(b)==" " or  str(a[b] )!=str(b) : 
            return False
        else:
    #    if a!= str([b]):#dynamic check
    #        print("Dynamism!")
            return True

    
    except Exception as e:
        e.Message = str(e.Message)
        raise


if __name__ == "__main__":
    a  = "abcdabcd"  #b = "edfcfced"
    b  = "ecdf"
    t  = cycpattern_check(a,b)
#    T.show(t)

    

