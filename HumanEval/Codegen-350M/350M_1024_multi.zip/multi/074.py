
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''
    if lst1 == lst2:
        return lst1

    # return if both lists are empty
    if len(lst1) == 0 or len(lst2) == 0:
        return lst2

    # if these are equal, return len()
    elif all(char in lst1 for char in lst2):
        return len(lst1)

    # find the left most element of the two lists
    lst_leftmost = max(lst1, key=len)
    lst_rightmost = min(lst2, key=len)

    # now add them to the original list
    lst1.append(lst_leftmost)
    lst2.append(lst_rightmost)

    # return if the left and right of the new list are the same
    if lst_leftmost == lst_rightmost:
        return lst1

    # set the rightmost element to the rightmost element in the other list
    lst_rightmost = lst_rightmost[len(lst1):]

    # now get the left and right of the new list
    lst1.append(lst_leftmost)
    lst2.remove(lst_rightmost)

    # return the new list
    return lst1 + lst2


# get length of the longest substring that contains at least 1 char.
