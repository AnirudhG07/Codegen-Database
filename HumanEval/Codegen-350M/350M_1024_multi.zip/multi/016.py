

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    characters = map(lambda s: s.lower() if isinstance(s, str) else s, string.lower())
    return max([c in characters and len(characters) or 0 for c in characters])


if __name__ == '__main__':
    main()
