
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    n, i = 0, len(string)
    while i < n:
        if string[i] in 'rcucf':
            n, i = i + 1, 0
            if prime_number(string[i:]):
                return True
        elif not(n % 3):
            n, i = i + 1, 0
            if prime_number(string[i:i + 1]):
                return True
    return False

if __name__ == "__main__":
    s = "hello world"
    print(prime_length(s))
