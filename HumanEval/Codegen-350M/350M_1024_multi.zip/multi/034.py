

def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    s = list(l)
    if len(s) == 0:
        return []
    m = set(s[0])
    for i in s[1:]:
        m.add(i**3 + i**2 + i)
    return m


# def first(x: int) -> int: 
