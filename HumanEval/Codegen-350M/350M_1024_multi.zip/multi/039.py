

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n == 0:
        return True
    v, a = n, n
    # n==1 has a prime
    if n < 2:
        return True
    i = 1
    if n == 2:
        a /= 2 # only 1 possible prime
        while i <= a:
            i += 1
        return
    # n==2
    if n == 2**i:
        return True
    while get_prime(v):
        i += 1
        n = v ** i
        if n == 2:
            return True
        if n % 2 == 0:
            if n % 3 == 0:
                return False
            v += 1
    return False


