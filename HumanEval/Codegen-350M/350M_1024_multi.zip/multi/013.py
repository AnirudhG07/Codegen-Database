

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    low = (a - b + 1) // 2
    high = a % b + (b - a + 1) // 2
    result = (high * a) % b
    if result == 0:
        return low + 1
    return (low * (b - result)) // result

if __name__ == '__main__':
    print(greatest_common_divisor(1000, 20))
    print(greatest_common_divisor(5, 10))
    print(greatest_common_divisor(22, 26))
