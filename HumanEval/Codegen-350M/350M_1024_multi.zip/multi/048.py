

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    # We check both to prevent a segfault
    left = text.lower()
    return left == text or len(text) % 2 == 0 and \
       left.endswith(text[::-1])


