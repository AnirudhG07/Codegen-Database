
def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.
    you should return an array of [ total number of eaten carrots after your meals,
                                    the number of carrots left after your meals ]
    if there are not enough remaining carrots, you will eat all remaining carrots, but will still be hungry.
    
    Example:
    * eat(5, 6, 10) -> [11, 4]
    * eat(4, 8, 9) -> [12, 1]
    * eat(1, 10, 10) -> [11, 0]
    * eat(2, 11, 5) -> [7, 0]
    
    Variables:
    @number : integer
        the number of carrots that you have eaten.
    @need : integer
        the number of carrots that you need to eat.
    @remaining : integer
        the number of remaining carrots thet exist in stock
    
    Constrain:
    * 0 <= number <= 1000
    * 0 <= need <= 1000
    * 0 <= remaining <= 1000

    Have fun :)
    """
    
    count = 0
    
    # Make this a greedy function so that it will be a constant.
    def count():
        """
        Get the current count.
        """
        return count
    
    # Make an array to store the number of eaten carrots after our meals.
    eateds = []
    # Make an array to store the total number of eaten carrots after our meals.
    total = 0
    
    while count < need:
        # Get the current count.
        count = count()
        # If we haven't eaten any carrots, add the number of carrots from your
        # previous position to the total of your finished meal.
        if count == 0:
            eateds.append(total)
            # If we have eaten only two carrots.
            total = [ eaten[-1], eaten[0] ]
            eateds.append(total[0] + eaten[1] + total[1] - eaten[0] - eaten[1])
            # If we have eaten at least two carrots, the total number of
            # eaten carrots is the previous number.
            if count <= 2:
                total = [ total[0], eaten[1] - eaten[0] + eaten[0] ]
                # Note the additional two eaten carrots are added to the total number
                # of eaten carrots.    
                # If the total number of eaten carrots is not the number of
                # total carrots to your previous position, your total eaten
                # carrots is the previous two potatoes.
                if not count:
                    total = [ total[0], eaten[1] - eaten[0] - eaten[0] ]
        
        # Add the number of carrots that we eat.
        eateds.append(total[0] + eaten[1] + total[1] - eaten[0] - eaten[1])
        # Eat the number of carrots.
        
        # Return the number of eaten carrots from your last position.
        remaining = need - count
        if remaining > 0:
            eateds.append(remaining)
        return [ eateds[-1], eateds ]
    return eateds
    

