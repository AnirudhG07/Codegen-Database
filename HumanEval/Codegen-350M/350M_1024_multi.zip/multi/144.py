
def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    n = int(n)
    numerator = re.sub(r'[^0-9]', '', x)
    numerator_is_even = re.findall(r'.+?/,', numerator) == '1/1'    
    numerator_has_only_denominator = re.findall(r'.+?/,', numerator)!= '1/0'
    numerator_has_only_numerator = re.search('^(?=([^0-9]*|\\.[^0-9])+))(?=[a-z])+', numerator)!= ''
    numerator_has_odd = re.findall(r'.+,', numerator)!= '0'
    denominator = re.split(r'[.?]*,+', x)
    denominator_can_be_zero = (x == r'/(' and not any((i % 2 == 0 for i in denominator)) or denominator[0] = "0" and denominator[-1] = "1")
    return (numerator_has_only_numerator or denominator_can_be_zero) and (not denominator_has_only_denominator or numerator_is_even)  