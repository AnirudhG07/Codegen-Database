
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    arr_list = [[] for i in range(len(arr))]
    counts = []
    for i in range(len(arr)):
        count = 1
        while count!= 0:
            if count == 1:
                continue
            if i % 2 == 0:
                arr_list[i].append(i)
            else:
                arr_list[i].append(arr[i])
            count -= 1
        if i > 0 and i % 2!= 0:
            arr_list[i].append(i)
        else:
            arr_list[i].append(arr[i])
    for i in range(len(arr)):
        if arr_list[i] < arr_list[i + 1]:
            arr = sort_array(arr_list[i:])
            continue
        arr_list[i][arr_list[i + 1]] = i
        del arr[i]
    return arr, num

class Kata(Node):
    def __init__(self):
        Node.__init__(self)
        self.root = None

class Solution(object):
    def invertKernel(self, arr):
        """
        :type arr: List[int]
        :rtype: List[int]
        """
        kata = Kata()
        kata.root = None
        count = 0
        for i in range(len(arr)):
            if count == 0:
                count += 1
                next_count = 0
                current = i
                while True:
                    node = find_node(arr, current, i)
                    if current > node:
                        current = find_node(arr, current, next_count)
                    if current > node:
                        kata = kata.clone_instance(current)
                        count = next_count + 1
                    if kata is None:
                        return
                    break
                    next_count = count
                    count += 1
            kata.swap_child(count, i)
            if next_count > 0:
                count %= kata.size_in_numbers()
                current += next_count
            else:
                next_count = 0
        return kata.root.nums

