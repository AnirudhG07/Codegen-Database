
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    def is_nested_and_brackets(string):
        '''
        This function should return True if the subsequence of brackets where
        all there exist is a valid subsequence that is nested or a nested but
        the last one exists
        '''
        return not all([]) and all([nest_to_bracket(substr.replace('[[', '[]').replace(']]', '[]')) in str(string)])
    if sys.version_info < (3, 0) and is_nested_and_brackets(string) == False and 
    is_nested_and_brackets(string) == True:
        return is_nested(string)
    return is_nested_and_brackets(string)

