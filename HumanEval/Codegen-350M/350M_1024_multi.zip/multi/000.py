from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if len(numbers) == 0:
        return False
    if len(numbers) == 1:
        return numbers.count(numbers[0]) < threshold
    else:
        for number in numbers:
            if number < threshold:
                return number < float(len(numbers) - 1)
            elif number > float(len(numbers) - 1) - threshold:
                return True



class Solution(object):
    @staticmethod
    def close_elements(numbers: List[float], threshold: float) -> List:
        """
        :type numbers: List[float]
        :type threshold: float
        :rtype: List[float]
        """
        close_elements_set = set([])
        for number in numbers:
            close_elements_set.add(has_close_elements(numbers, threshold) and not has_close_elements(numbers[:], threshold) and not has_close_elements(numbers[:], threshold))
        for i in range(len(numbers) - 1, - 1, - 1):
            close_elements_set = set.difference(close_elements_set)
        return close_elements_set

if __name__ == "__main__":
    sol = Solution()
    actual = sol.close_elements([0.0, 1.0, 2.0, 3.0])
    expected = [True, True, True]
    print("Close element set: ", actual)
    print("Expected: ", expected)
    assert actual == expected
    # Actual result: [False, True, False]
    actual = sol.close_elements([2.0, 12.0, 2.8, 3.0])
    expected = [True, True, False]
    print("Close element set: ", actual)
    print("Expected: ", expected)
    assert actual == expected
