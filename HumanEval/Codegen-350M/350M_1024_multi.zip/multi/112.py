
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    for c in c:
        inp = list(s)
        index = inp.index(c)

        inp = reversed(inp[::-1])
        for i in reversed(range(1,len(inp))):
            if inp[i] == inp[index-1]:
                index -= 1
        index = len(inp)
        
        inp.append(inp[:index] if index >= 1 else inp[0])
        
        for i in range(index/2):
            inp[i+1] = inp[i]
    
    s_inp = inp
    
    for l in reversed(s_inp):    
        if ''.join(l) == ''.join(s_inp):
            return ''.join(('c',False)), False
    return None, False


