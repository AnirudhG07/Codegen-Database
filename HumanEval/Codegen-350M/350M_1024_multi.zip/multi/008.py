from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    products = ([0] * len(numbers)) + [1]
    sum = 0
    for s, _ in products[:-1]:
        sum ^= s
        products[-1] ^= s
    return sum, products[-1]


class Calculator2:
    def calculate(self, number_1: int, number_2: int) -> Tuple[int, int]:
        """ Calculates the product of numbers. Both number_1 and number_2 must be in range of 1.
        >>> calculator.calculate(1, 2)
        (6, 16)"""
        return sum_product([number_1, number_2])[0]
