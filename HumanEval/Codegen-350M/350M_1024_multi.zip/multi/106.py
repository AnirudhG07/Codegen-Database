
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 *... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    # we are already called as f with the number, so here we have to recursively
    # call the call f recursively to do all the differents calls to our function f
    # first the value of the first element of the list.
    res = [1]*n

    for i in range(n-1):
        for j in range(i+1,n):
            res += [f(j)]
            print(res)

    return res

# print(f(9))
# print(f(3))
while True:
    print(f(7))

# print(f(7))

# while True:
#     answer = raw_input("Enter a number : ")
#     n = int(answer)
#     print(f(n))
