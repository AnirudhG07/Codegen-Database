
def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """
    # This is necessary as the result of the function is always the result of calling
    # the equivalent function which takes two lists of numbers as input. But, on some platforms
    # (I know!), you must make the result into a string of equal length, which the function
    # is designed to expect. So, it is a requirement.
    size_of_lst1 = len(lst1)
    size_of_lst2 = len(lst2)
    remain_size = size_of_lst1 - size_of_lst2
    if remain_size <= 0:
        return
    # If there are no more than one possible element between one and another
    # do a 1-step exchange of all elements. Otherwise, this function is
    # an exchange, but for simplicity, it is assumed that if the two lists
    # have been sorted they will not be.
    def exchange(i, j):
        # Use the `next element` function and always end at last element
        r = lst1[i]
        while r!= lst2[j]:
            lst1[i] = lst1[i][0] + lst1[i][1]
            i -= 1
            r = lst1[i]
        exchange(i, j)
    exchange(0, 0)

