from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    if len(strings) == 0:
        return ''

    result = []
    for s1 in strings:
        new_s = str(s1)
        new_s = new_s + s2 if s2!= '' else s1
        result.append(new_s)

    return ''.join(result)


