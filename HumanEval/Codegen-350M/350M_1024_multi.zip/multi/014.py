from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    from pandas.util.preprocessing.conversion import preprocess_iter_list
    patterns = preprocess_iter_list(string)
    to_prefix = dict(zip(patterns, _PATT_TO_PREFIX))
    return sorted(to_prefix.view(_PATT_TO_PREFIX))
