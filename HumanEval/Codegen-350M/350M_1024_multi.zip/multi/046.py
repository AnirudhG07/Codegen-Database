

def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    if n < 2:
        return n
    # If n is even, simply return 0
    if n & 1 == 1:
        return 0
    # 1st element of the fib4 sequence will result in an n-1 element if there's an even number,
    # we can use the binary search algorithm to do this, but we won't do that until all else
    b = 1
    for n1 in range(n):
        if (n1 > 1) & (n1-1 < n):
            b = b + fib4(n1+1)
            n1 = n1 + 1
    return b

if __name__ == "__main__":
  # print(fib4(7))
  # print(len(fib4(10)))
  # print(fib4(1)*7)

  # This should return 3.5 for the n-th element of fib4
  print("The fib4 sequence will have sequence number: ", fib4(0))
  # print(fib4(5))
