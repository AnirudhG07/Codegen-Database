
def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1,... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
    if "," in txt:
        word_upper = map(to_upper, txt.split(','))
        word_lower = list(map(to_lower, word_upper))
    elif len(txt)<2:
        word_upper = map(to_uc_case, to_lower(txt).split(' '))
        word_lower = list(map(to_uc_case, word_upper))
    else:
        word_upper = map(to_uc_case, txt.split(' '))
        word_lower = list(map(to_lower, word_upper))
    return [word_upper[i] + str(i) + word_lower[i] for i in range(len(word_upper) + 1)]

