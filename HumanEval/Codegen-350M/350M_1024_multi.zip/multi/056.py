

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    # find open and close brackets
    open = [0 for x in brackets]
    for index in range(0,len(brackets)-1):
        # close is a special tag (e.g. ">>")
        if brackets[index] == ">" and brackets[index+1] == ">":
            break
        if brackets[index] == "<" and brackets[index+1] == ">":
            open[index] = index + 1
        elif brackets[index] == "<" and brackets[index+1] == " ":
            open[index] = index + 1
        else:
            return False
    else:
        return False
    # go through all brackets
    for index in range(0,len(brackets)):
        # close is a special tag (e.g. "<<<")
        if brackets[open[index]] == brackets[index+1] and brackets[open[index+1]] == brackets[index+2]:
            return True
    return False
