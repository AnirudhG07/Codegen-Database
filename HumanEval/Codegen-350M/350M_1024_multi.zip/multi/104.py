
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    digits = dict()
    for x in xrange(1,len(x)):
        d = str(x)
        if d in digits:
            digits[d] += 1
        else:
            digits[d] = 1
    return sorted(digits.keys())

