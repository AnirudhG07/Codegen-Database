

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    for bracket in brackets:
        if not bracket.startswith("("):
            continue
        if bracket.endswith(")"):
            if bracket[-1]!= ")":
                return False
        else:
            if bracket[0] == bracket[-1]:
                return False
    return True



class Solution:
    def solution1(self, n: int, k: int):
        """
        :type n: int
        :type k: int
        :rtype: int
        """
        # pylint: disable=inconsistent-return-statements
        assert 2 * (n + k) * k < n, (n, k)
        if k == 1:
            return k * (n + k) + 1
        else:
            return max(0, r * n + (n + 1) - k)



# Your Solution object will be instantiated and called as such:
# sol = Solution()
# sol.solution1(n, k)
