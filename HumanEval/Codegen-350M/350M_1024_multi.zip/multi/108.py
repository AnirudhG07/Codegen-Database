
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    nums = 0
    for c in arr:
        nums = c*0 + nums
    return nums

class TestEvaluate:
    """
    A collection of unit tests for evaluators.
    """

    def test_sub_numbers(self):
        exp = 1234
        num_1 = int(exp)
        num_2 = (exp - num_1)
        assert num_2 == num_2

    def test_sub_list(self):
        num = list(range(10))
        exp = list((exp - num[i-1])/num[i] for i in range(5))
        assert exp == num_1

    def test_unaryOps(self):
        assert int(1) == - 1
        assert int(0) ==  0
        assert 100 == 100
        assert num_1 == -1
        assert num_2 == 0
        assert num_3 == 20
        assert num_4 == 4
        assert 0 == num_5
        assert 5 == 2 * num_5

    def test_binaryOps(self):
        assert 11 == 10**11
        assert 10 == 10**10
        assert 10**5 
        assert 10**-5 == 10**-10

    def test_binOpBinaryOps(self):
        assert 9 + 10 == 11 + 1
        assert 10 + 3 == 11 + 9

suite = allTests(TestEvaluate)

if __name__ == "__main__":
    TextTestRunner(verbosity=2).run(suite)
