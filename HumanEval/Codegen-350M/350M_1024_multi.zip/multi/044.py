

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if x < base:
        return str(int(1000 % x))
    else:
        return str(x)

class MyObject(object):
    def __init__(self, x_in):
        self.x = x_in

test_number = 3
i = 2
while i < 100:
    obj_num = MyObject(i)
    new_obj_num = MyObject(i + test_number)
    print('new obj_num:', new_obj_num)
    i = i + 1
    obj_num = MyObject(i)
    new_obj_num = MyObject(i + test_number)
    print('new obj_num:', new_obj_num)
