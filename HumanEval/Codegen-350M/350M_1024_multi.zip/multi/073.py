
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    # Create a new, empty array to get the count of elements that will be changed.
    all_change := len(arr)
    # Now, we have a new array of arr[:-1].
    new_arr := []

    for i in range(all_change):
        # If there is more than one element.
        temp_arr := []
        # Get the count of changes from the current array.
        temp_change_count := len(arr)
        # If there are no changes in the current array add the element to the current array.
        if temp_change_count <= i:
            new_arr.append(arr)
            arr = []

        # Loop through all other elements from the previous array.
        for j in range(i+1, all_change):
            if j!=i:
                # If there are changes between the previous and next array and no other change in the next array.
                # Add the previous element to the new array and the current one that will be changed.
                for k in range(j):
                    # If there is no change in the current array.
                    if k == i:
                        # If it is on the next array.
                        if j == i+2:
                            # The other one.
                            prev = new_arr[j+1]
                            temp_k := []
                            for k in range(j+1,len(new_arr)-1):
                                # If prev is on both the next and the previous array.
                                if prev[k]==next[k]:
                                    temp_k = []
                                    temp_change_count_k := len(new_arr[j:k+1])
                                    for k in range(j,k+1):
                                        # If temp_k not on the next array.
                                        if k not in temp_k:
                                            temp_k.append(arr[j+k-1])
                                            // If temp_k was on the previous array but this array was changed in the next array.
                                            if (j+k-1)!= k and k not in temp_k[:-1]:
                                                temp_k[j+k-1] = prev[k]
                                        if len(temp_k)-1 == k and k not in temp_k[:-1]:
                                            new_arr.append(prev[k])
                                            break
                                # Else if prev is on both the next and the previous array.
                                else:
                                    new_arr.append(prev[k])
                            new_arr = new_arr.remove(temp_k)
                        # If there is no other change in the i-th array and there is no change in the next array.
                        # Add the j element to the new array and continue with the next array.
                        else:
                            new_arr.append(arr[i+j])

                arr = new_arr
        print("".join(str(i+1:-1)))
        all_change -= 1

    array_with_changes_count := len(arr)

    return (array_with_changes_count,all_change) # return the count and the other amount of changes

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print("usage: "+sys.argv[0]+" <number of changes> <first index in the array> <next index(> in the array> <last index in the array>)")
        print("example: "+sys.argv[0]+" 3 5 5-4-2 4")
        exit()
    change = int(sys.argv[1])
    index = int(sys.argv[2])
    begin = int(sys.