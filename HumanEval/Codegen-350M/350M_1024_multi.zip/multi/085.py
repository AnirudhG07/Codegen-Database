
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    m = len(lst)
    if m % 2 == 1:
        return [str(i) for i in lst]
    else:
        return add([lst[i]: lst[m - 1] + (i + 1) % 2 * (lst[m - 1] - lst[i] ))

class SolutionRecursion(object):
    def solve(self, s):
        """
        :type s: str
        :rtype: str
        """
        if '(' in s:
            first, rest = s.split('(', 1)
            s = first
            s += rest + '('.join(['(' + add([''.join(['['.join(i) for i in s.split(']')[-1]]), ']'.join(['', [
                s + '.' + first
            ], s.split('\n', 1)[1]
        ]]) for i in range(2, len(s) + 1)])
            r = s
        else:  # first is "()"(e.g. "(1", "(a,c)"), with s = "(1"
            r = add([add(['(']) + s
        return r

import cProfile

