
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    ans = 0
    for c in s:
        v = len(c)
        if v >= 2 and not c == "u" and c!= "A" and c!= "Y" and c!= "e" and c!= "i" and c!= "o" and \
              c!= "u" and c!= "x" and c!= "y" and c not in ("i", "y", "") and c not in ("z", "u"):
            ans += 1
    return ans

