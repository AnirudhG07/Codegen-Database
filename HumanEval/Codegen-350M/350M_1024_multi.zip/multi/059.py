

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if n in {2}:
        return 2
    elif n < 2 or n & 1:
        return
    last = largest_prime_factor(n - 1)
    prime = 2
    for i in range(2, last + 1):
        if n % i >= i:
            prime = max(prime, last - i)
        else:
            break
    return prime

