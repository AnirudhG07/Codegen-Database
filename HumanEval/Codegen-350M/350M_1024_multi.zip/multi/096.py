
def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    if n - 2 > 0 and n - 3 >= n:
        count = [False for i in xrange(n + 1)]
        for i in xrange(n + 1, n - 3):
            if i > n - 2:
                if count[i - 1]:
                    break
                count[i] = True
        return sorted(count)
    else:
        return [(n,) + (1 if count[k] else (-1 for k in xrange(k+1, n)))]


