from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o|.| o| o|.|.|.|.| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    beat_intervals = [None] * 32
    if music_string[0:2] in 'o|':
        beat_intervals[0] = 4
        hit_intervals = [None] * 32
    elif music_string[0:2] in '|':
        beat_intervals[0] = 1
        hit_intervals = [None] * 32
    elif music_string[-2:0] in '.':
        beat_intervals[31] = 3
    else:
        raise Exception('Unknown musical format: %s - see: https://s3.amazonaws.com/rk-test/api/v0/music/' % music_string)

    beat_intervals_list = []
    hit_intervals_list = []
    for idx, beat_interval in enumerate(beat_intervals, 1):
        for idy, beat_hit_interval in enumerate(hit_intervals, 1):
            beat_interval = beat_intervals[idy]
            beat_hit_interval = beat_hit_intervals[idy]
            # print(str(beat_hit_interval) + '\n' + str(beat_interval) + '\n',)
            # print(idx,"\t",)
            if beat_hit_interval is not None:
                beat_interval = beat_hit_interval
            beat_interval = beat_intervals[idy]
            hit_interval = hit_intervals[idy]
            new_interval = beat_interval / beat_interval_mult
            beat_interval_list.append(beat_interval)
            hit_interval_list.append(hit_interval)
            # print(beat_interval_list, hit_interval_list)
    beat_interval_list = sorted(beat_interval_list)
    hit_interval_list = sorted(hit_interval_list)
    return beat_interval_list + hit_interval_list

