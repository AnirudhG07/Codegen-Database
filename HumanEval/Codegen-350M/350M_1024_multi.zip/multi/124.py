
def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.
    The date is valid if all of the following rules are satisfied:
    1. The date string is not empty.
    2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    3. The months should not be less than 1 or higher than 12.
    4. The date should be in the format: mm-dd-yyyy

    for example: 
    valid_date('03-11-2000') => True

    valid_date('15-01-2012') => False

    valid_date('04-0-2040') => False

    valid_date('06-04-2020') => True

    valid_date('06/04/2020') => False
    """
    retval = False
    if not date:
        return retval
    if len(date) < 4 or len(date) > 10 or len(date.split("-")):
        return retval
    if (len(date.split("-"))-2) not in [int(tmp) for tmp in date.split("-")+[13,12,31]]:
        return retval
    if date.split("-")[-1] not in [str(partner) for _ in ('0', '1', '3', '5', '7', '8', '10', '12')]:
        return retval
    months = date.split("-")[:-3]
    for i in months:
        if month_name(i) not in ['0', '1', '3', '5', '7', '8', '10', '12']:
            return retval
    return True

if __name__ == '__main__':
    # print all of the valid date strings before printing the next one
    retval = True
    while valid_date(sys.argv[1]):
        retval = False
        # check if string is empty or not.
        if len (sys.argv[1]) == 0:
            sys.exit("Please enter a valid date as well.")
        else:
            date = parse_date(sys.argv[1])
            retval = valid_date(sys.argv[1])
            print(sys.argv[1])
            if retval:
                sys.exit("This date is already in a valid format, but is not correct.")
    sys.exit(0)
