from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    values = [v.encode('utf-8').decode('utf-8') for v in values]
    return [i for i in range(len(values)) if values[i] is not None]


class Interval(typing.List):
    def __new__(*args):
        return list.__new__(list, [])

    def __init__(self, *args):
        super().__init__(*args)
        self.__init__ = self.__new__

    def __getitem__(i_p: int, *args: Any):
        # type: (int, *Any) -> Interval
        result = len(self)
        if i_p < result:
            return result
        elif i_p >= result:
            return Interval(self[i_p:])
        raise IndexError('Index out of bound:'+ str(i_p))


class SummingFunction(object):
    def __init__(self, *args):
        super().__init__(*args)
        self.sum = self

    def _log(self) -> float:
        return math.log(sum(self))

    def __repr__(self) -> str:
        args = []
        if isinstance(self.__code__, type):
            args.append('{}({!r})'.format(self.__code__.__name__, self.sum))
        else:
            args.append(*self.__code__.args)
        return 'SummingFunction({})'.format(', '.join(args))


class SumMap(dict):
    def __getitem__(self, *items: Any):
        return super().__getitem__(*items)

    def __setitem__(self, key, item):
        super().__setitem__(key, item)


class BaseFunction(object):
    def __repr__(self) -> str:
        return '{}({!r})'.format(super().__repr__, self.sum)


class Lambda(BaseFunction):
    def __init__(self, *args):
        super().__init__(*args)
        self.sum = self

    def __repr__(self) -> str:
        return '{}({!r})'.format(super().__repr__, self.sum)


class LambdaFunction(BaseFunction):
    def __init__(self, *args):
        super().__init__(*args)
        self.sum = SummingFunction(*args)
        self.sum.sum = self.sum.sum


