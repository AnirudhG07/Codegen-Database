
def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    
    
    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    
    guesses=guess.split(" ")
    scores=score.split(" ")
    print(guesses)
    print(scores)

    i=0

    guesses1=scores
    guess1=guesses
    guets=max(guesses1)+max(guesses)

    for i in range(len(scores)):
        if guesses1[i] == "correct":
            guesses1.remove(guesses1[i])
            guess1.remove(guess1[i])
            guests=max(guess1)
            break
    
    print("guesses",guesses)
    print("guesses1",guess1)
    print("guet",guets)

    i=0
    #score,guesses=guesses1,score.split(" ")
    for i in range(len(scores)):
        if score1 [i] == scores[i] and guess1 [i] == guesses1[i]:
            print("MATCH!",scores,guesses1[i])

            guesses1.remove(guesses1[i])
            guess1.remove(guess1[i])
            guets=max(guess1)

    if scores[len(scores)-1] == "correct" and scores[0] == scores[-1]:
        return [0, 0]

    return [score1,guess1]

class score:
    def __init__(self,score):
        self.m=map(lambda x: int(x), list.__getitem__(score, 0, None).split(" and "))

    def __getitem__(self, i):
        return self.m[i]

