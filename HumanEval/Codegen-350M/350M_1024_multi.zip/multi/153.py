
def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) =='my_class.AA'
    """
 
    ret = ''
    for extension in extensions:
        if len (extension) == 0:
            continue
        # This is where the quality of the extension is determined
        extension_strength = -1
        # This is where the quality of the extension is determined
        found_it = False
        # The strength of the extension starts from 1 (the one of the first letter)
        level_1 = 1
        # The number of the uppercase letters in the extension's name
        strength = 1
        # This is where the quality of the extension is determined
        found_it = False
        # Find the maximum extension strength
        strength = len (extension)
        if not found_it:
            level_1 = 0
        if level_1 == 0:
            ret += extension
        else:
            extension_name = extension
            extension_strength = 0
            for i in range (0, len (extension)):
                # Find the lowercase letters by their length
                level_2 = len (extension[i])
                while level_2 > 0:
                    extension_strength += level_2
                    # Go the level above until a constant value is found
                    for constant in [1, 2, 3, 4]:
                        level_2 = level_1
                        if constant <= int (extension_strength): 
                            # Change it to that constant value
                            extension = extension[:i] + extension[i+constant]:
                                extension = extension[:i] + extension[i:i + constant]
                            extension = extension.replace (extension.upper ().lower (), extension[0])
                            break
                        level_2 = level_1
                    found_it = True
            # The longest extension already found
            while not found_it:
                extension *= level_1 + 1
                extension_name = extension[0] + extension
                extension_strength = 0
                for constant in [1, 2, 3, 4]:
                    extension = extension
                    # Go the level above until a constant value is found
                    for constant in [1, 2, 3, 4]:
                        level_2 = level_1
                        if constant <= int (extension_strength): 
                            # Change it to that constant value
                            extension = extension[:i] + extension[i+constant]:
                                extension = extension[:i] + extension[i:i + constant]
                                extension = extension.replace (extension.upper ().lower (), extension[0])
                        level_2 = level_1
                    found_it = True
            ret += extension_name
    return ret