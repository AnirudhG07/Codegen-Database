
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    if len(sentence) <= 0:
        # if the input is zero.
        return ""

    # We have to keep the string in a temporary variable
    sentence_temp = sentence
    solution = ''

    # We use the next line of code to loop over characters
    # in the original sentence.
    for char in sentence_temp:
        # If given a char as the character to be tested
        # it will increment the number of digits needed
        # to be a possible solution for the current char
        digits = (len(str(sentence_temp.count(char))))
        if digits > 1:
            # we have to repeat the original char until it can get the
            # the number of characters for which digits are different
            while words_in_char(char)!= (digits - 1):
                digits = (len(str(sentence_temp.count(char))))
            digits = (len(str(sentence_temp.count(char))))
            if digits > 1:
                # we can continue with the next char
                digits = (len(str(sentence_temp.count(char))))
    solution = sentence_temp
    return solution

