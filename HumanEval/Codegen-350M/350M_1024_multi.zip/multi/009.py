from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    roll_nums = [j for j in numbers if k - j > 0]
    return map(lambda num: max(roll_nums), roll_nums)


@pytest.mark.parametrize(
   'reason', [
        'The first element of the list is greater than the second element of the other list',
        'There is no element equal to 3',
        'The first element of the list is greater than the second element of the other list',
        'The third element of the list is greater than the fourth element of the other list',
        'There are no values for all elements in two lists'
    ]
)
