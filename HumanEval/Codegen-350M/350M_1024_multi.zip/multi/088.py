
def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    pivot = len(array) / 2
    i, j = -1, -1

    while j <= pivot:
        if sum( array[j : j + 2]) % 2:
            i = j
        else:
            j += 2

    i += array[0]

    if (array[j] - array[pivot]) % 2:
        array.insert(i, array[pivot + 1])

    elif (array[pivot] - array[pivot + 1]) % 2:
        array.insert(i, array[pivot + 1])
        array.insert(i, array[pivot])

    else:
        array.insert(i, array[pivot])
        array.insert(i, array[pivot + 1])

    return

count = 100

for index in range(0, count):
    print(count)

    array = [0] * count