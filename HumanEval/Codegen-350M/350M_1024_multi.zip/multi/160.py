
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    if len(operator)!= 2:
        raise IOError('operands must contain integers')
    elif len(operand)!= 2:
        raise IOError('operands must contain integers')
    operator = operator[0]
    if operator is None:
        if operator is'+ ', operator is'- ':
            return None
        else:
            raise IOError('expected a single operator symbol')
    operand = operand[0]
    if operand is None:
        if operand is'+ ', operand is'- ':
            return None
        else:
            raise IOError('expected a single operand symbol')
    return operator + operand

