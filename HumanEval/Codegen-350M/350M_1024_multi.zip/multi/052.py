

def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    return len(np.asarray(l)) >= t and all(np.asarray(l) <= t)

# --- Test all functions of the form below_threshold --------------------------------

class TestAllFunctions():
    @decorators.skipif(os.environ['CI'])
    def test_below_threshold_when_all_false(self):
        """
        If all numbers returned by below_threshold() are false,
        return False
        >>> below_threshold([0, 1, 5, 18, 4], 50)
        False
        >>> below_threshold([0, 1, 6, 18, 4], 50)
        True
        >>> below_threshold([0, 2, 3, 6, 10], 50)
        False
        >>> below_threshold([0, 2, 3, 6, 10], 15)
        True
        """
        assert below_threshold([8, 9, 0, 11, 2], 3) is True
        assert below_threshold([2, 5, 4, 12, 3], 9) is True
        assert below_threshold([-9, 2, 5, 4, 12], 0.5) is False
        assert below_threshold([2, 5, 12, 3], 7) is True
        assert below_threshold([2, 100, 3], 100) is True
        assert below_threshold([2, 3, 6, 10], 200) is True
        assert below_threshold([-1, 1, -2, -3], -3) is False

    # --- Below_threshold -----------------------------------
    @decorators.skipif(os.environ['CI'])
    def test_below_threshold(self):
        """
        If all numbers below 1,0 and above 2 are true,
        return True
        >>> below_threshold([-1, 0, -3, 3, -2], 2)
        True
        >>> below_threshold([1, 0, -3, 3, -2], 2)
        True
        >>> below_threshold([0, 1, 0, -2, 3], 2)
        True
        >>> below_threshold([0, 1, 0, -2, 3], 5)
        True
        >>> below_threshold([0, 1, 0, -2, 3], 15)
        True
        """
        assert below_threshold([-2, 0, -1, 3, 0], 3) is True
        assert below_threshold([1, 0, 0, -2, 3], 0) is True
        assert below_threshold([2, 0, 0, -2, 3], 1) is True
        assert below_threshold([1, 0, -2, 3], 2) is False
        assert below_threshold([-1, 1, 0, -2, 3], 0.5) is True
        assert below_threshold([0, 1, -2, 3], 2) is True
        assert below_threshold([5, 6, 2, -16, 11], 15) is True
        assert below_threshold([18, 18, 0, -2, 7], 1) is True
        assert below_threshold([18, 18, -2, -50, 3], 0) is True
        assert below_threshold([18, 18, -2, -50, 3], 1) is False

if __name__ == "__main__":
    test.main()
