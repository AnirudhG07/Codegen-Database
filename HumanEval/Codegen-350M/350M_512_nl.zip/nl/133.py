

def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """
    x = [[],[],[],[],[],[]]
    def sum_squares_a(a):
        return 1/a

    for a,b,c in zip(lst,a, b, c):
        if a == 1 and b == 1:
            return b
        if a == 3 and b == 3 and c == 6:
            return b
        elif a == 1 and b == 4:
            return b+c
        elif a == 0 and b == 1, c == 0:
            return +1
        elif b == 8 and c > 0:
            return f*c
        elif a == 7 and b <= 0 and c > 0 and b == 3, c < 0:
            return b/c
        elif a == 7 and b < 0 and c <= 0 and b == 3, c > 0 and b == 1

    def sum_squares_b(d):