

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    seen = [0] * len(l1)  # list.append of each value is a no-op
    seen[0:len(l1)] = [1]  # push value onto list
    seen[1:len(l2)] = [0]
    result = [1] * len(l2)  # empty-array of values in result
    for i in range(len(l1)):
        for j in range(i + 1, len(l2)):
            if seen[i] == 1:
                # The value seen for this element is already present
                result += [seen[j]]
                seen[j] = 1
            