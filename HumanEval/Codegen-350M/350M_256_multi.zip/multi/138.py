
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    if not n:
        return False
    else:
        return is_equal_to_sum_even(ceil(ln(2)-n))

# def is_prime(n):
#     """Returns True if n is prime, False otherwise"""
#     if not has_odds([n]):
#         return False
#     for prime in Prime.prime_classes(): # This just checks prime numbers
#         if has_odds([prime]) > 1:
#             return False # Primes can have odd numbers. So, need to check them all too
        
#     retval = True
#     retval = is_prime(n-1)
#     retval = is_prime(n