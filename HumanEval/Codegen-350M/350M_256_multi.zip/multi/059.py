

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if n <= 1:
        return 1

    return n.mod(n)


if __name__ == "__main__":
    for i in list(range(15))[::-1]:
        sum = 0
        print (i, 0, i/2, 0)
        for n in range(i, 0, -1):
            n = n % 2
            s = i if n < 2 else 0
            while n!= 1:
                s = s + 3*n
                num = 1 if n % 3 == 0 or n % 5 == 0 else 0
                sum += num
                n = (n * n) % n
            sum %= n
            for d in range(1, 2):
                if (
                    sum < 99999
                    and sum!= 1
                    and sum >