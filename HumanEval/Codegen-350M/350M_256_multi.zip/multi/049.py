

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    return ((((n & 0xFFF) << 8) | (p & 0xFFF)) << 8) | (p & 0xFFF)

# ------------------------------------------------------------------------------
# Solution of "Modulo Inverse Modulos Arithmetic"
# In this example, a modulo-inverse operation and an integer modp


# ---- Main function for solving modulo operations from Python ---

