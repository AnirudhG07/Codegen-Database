

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    while True:
        i = pow(n, i + 1, mod=int(2 ** 6))
        if i % 1:
            return i
        else:
            i = divmod(i, n)


