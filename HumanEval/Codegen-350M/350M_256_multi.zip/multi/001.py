from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    paren_groups: List[int] = []
    for group_string in paren_string.split(')') + paren_string.split(')[]'):
        if group_string.startswith('('):
            bracket_positions: List[int] = []
            for position in range(0, len(group_string) - 1):
                pos_string_start: int = group_string.find(group_string[position:])
                if pos_string_start == -1:
                    break
                bracket_positions