

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    if isinstance(l[0], numpy.array):
        l = l.tolist()
        s = numpy.array(l)
        pos = numpy.ceil(numpy.less(s, 0)).tolist()
        for i in xrange(numpy.floor(numpy.max(s, 0)) + 1):
            if l[i] > 0:
                pos.append(i)
        return numpy.array(pos) == numpy.linspace(0, numpy.max(s, 0), len(l))
    else:
        return numpy.array(l) == numpy.max(l)


