
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    odd = False
    for i in lst: 
        if odd:
            odd = False
            continue
        odd = True
        if i % 2 else odd
            lst.append(i)
    if odd:
        lst.append(2)
    return lst

