

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    result: bool = True
    for btag in brackets:
        if btag.startswith('>>>'):
            bracket_starts: str = btag[2:]
            if bracket_starts.startswith('>>'):
                bracket_ends: str = bracket_starts[2:]
                if btag.endswith(bracket_ends):
                    result = branch_not_corresponding(bracket_starts,
                                                      bracket_ends)
                else:
                    result = self.is_bracket_correct if result else False
    return result
