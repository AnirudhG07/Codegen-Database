from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    result = numbers
    for value in number_set(result, set()):
        tmp = value
        while True:
            tmp_old = result
            result = result.__contains__(value)
            if not result:
                break

    return result or [item for value, item in numbers if value in result]


