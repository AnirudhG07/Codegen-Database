

def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    if number == 0:
        return 0
    decimal = round(math.ceil(number), -2)
    min_precision = min([precision for precision in range(10, 20)])
    smaller_precision = min_precision

    rounded_num = math.copysign(
        decimal - (precision - 1) * (decimal % precision)
        if decimal % precision > 0
        else 1
    )

    if rounded_num < 0:
        return larger_precision * (-rounded_num + 1) / 2
    return smaller_precision * rounded_num


