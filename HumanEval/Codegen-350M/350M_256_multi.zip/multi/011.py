from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    i = 0
    j = 0

    res = ''

    while i < len(a) and j < len(b):
        ch1 = a[i]
        ch2 = b[j]

        if ch1 == ch2:
            res += ch2
            i += 1
            j += 1
        elif ch1 < ch2:
            res += ch1
            i += 1
        else:
            res += ch2

    if i < len(a):
        res = a
    if j < len(b):
        res = res + b
    return res


@partial(string_xor, isstr=True)
