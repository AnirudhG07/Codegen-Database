

def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """
    v=[[s] for s in l]
    v2=[v]
    v4=[]
    new=[v4]
    for v2i in v2:
        v4i=(incr_list(v2i))
        v4.append(v4i)
    if l.count(v4[0][0]), len(v4)>1:
        new.append(v4)
    return new


# test:
