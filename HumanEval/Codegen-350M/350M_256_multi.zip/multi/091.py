
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    # The words that the task needs to evaluate
    words = S.split('.')

    # If nothing is left, it's a failure
    if words[-1] in ('!', '?'):
        return 0

    # Each word is a little bit different, and so it has a type different
    # because it's a word that starts with word 'I'
    if words[-1] in ('I', '!'):
        # I need to count how many boring people are
        count_count = 0
        for word in words:
            if word == 'I':
                count_count