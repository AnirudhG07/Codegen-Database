
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    # this is a linear search!

    def _index_of(string):
        _, index = 0, 0
        for char in string:
            if char == "a":
                break
            elif char == "b":
                index += 1
            elif char == "c":
                index += 1
                index += 1
            elif char == "d":
                index += 1
                index += 1
                index += 1
            else:
                index += 1
        return index

    # build a dictionary from