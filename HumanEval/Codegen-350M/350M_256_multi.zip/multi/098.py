
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    res = set()
    for i in itertools.count(0) :
        if i >= len(s) :
            res.add(i)
    return res.count(u)

if __name__ == '__main__':
    s = input('First Name: ')
    m = input('Last Name: ')
    
#    f = CountVowels(s)
    
    f = count_upper(s)
    print('A set of pairs (upper) was found', s,'->', f)
    
    
