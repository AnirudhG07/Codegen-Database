
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    c1 = b
    c2 = a

    found = False

    if c1 == "" and c2 == "":
        found = True
    else:
        newc1 = ""

        newc2 = ""
        while c1!= "":
            if c1.lower() == c2.lower():
                newc2 = newc1
                newc1 = str(c1).lower()

            newc1 += c1
            newc2 += c2