

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    chars = str(string).split(" ")
    characters = "\t\n\r\f"
    length = len(chars) + len(characters)

    return len(chars) < 9 and len(chars) > 0 and \
        count(chars) == characters.count(characters) and \
        chars[-1] in characters
