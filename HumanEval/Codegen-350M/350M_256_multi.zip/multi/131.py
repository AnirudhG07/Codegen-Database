
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    if n <= 0:
        return 0
    odd_numbers_to_be_combined = [x % 2 == 1 for x in range(1, n + 1)]
    if not odd_numbers_to_be_combined:
        return 0

    odd_numbers = odd_numbers_to_be_combined.pop()
    product_to_be_combined = even_digits_to_combine_by_repeating_digits(odd_numbers)[0]
    digits = len(n) - 1

    result = []
    while 0 < digits:
        if digits % 2 == 1:
            result.append(product_to_be_combined)
        else:
            result.append(0)
        if digits > 1:
