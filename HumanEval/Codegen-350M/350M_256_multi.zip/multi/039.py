

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    p = n//2
    last = p

    for x in range(n):
        if n % x == 0:
            if not x % (x + 1):
                last -= 1
                continue
            prime = False
            n = x * x
            continue
        prime = True

        if prime:
            last -= 1
            continue

        if not x % (x + 1) or n <= last:
            next = x
            n = next * next
        else:
            prime = False
            x = x * x
            n = x + n
    return n


