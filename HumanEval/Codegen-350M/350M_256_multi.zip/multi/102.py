
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    r = int(min(x, y))
    n = int(max(x, y))
    if r!= n-1 && r % 2 == 0 or r % 2 == 1: 
        return r
    return -1

"""
This function will generate the same problem as choose_num() but will use the
inputed range [from, to) as the range where the function is asking for the
tournament. It will generate the same number of points between the range
[from, to).
"""
