
def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """
    mock_list = list(lst)
    odd_elems = []
    for i in range(len(mock_list)):
        if mock_list[i] % 2 == 1:
            odd_elems.append(i)
    odd_sum = 0
    i = 0
    for num in odd_elems:
        odd_sum += num * num
    return odd_sum
