
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    result = 0
    digits = []
    prec = len(a)
    for digit in a:
        # If the digit has been used, it's not prime anymore.
        if digit in digits:
            result *= 10 
            prec -= 2
            break
        digits.append(digit)
    for i in reversed(range(prec)):
        if digits[prec - i - 1] > 0:
            break
    result = result * 10 ** digits[-i - 1]
    
    
    return result

