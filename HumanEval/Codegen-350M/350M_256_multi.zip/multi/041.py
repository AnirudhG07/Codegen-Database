

def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """
    # How many collisions there are in the entire car's race?
    nc = 0

    # Calculate the length of a straight road to the right at the end of a car race
    # This is the length of its left end segment:
    segment_len = nc_len(segments(n, n))

    # Also, see if this race is longer than what we expect
    # If the segment length of the