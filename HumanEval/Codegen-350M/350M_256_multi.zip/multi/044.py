

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    sign = 1
    if x < 10:
        sign = -1
        x = '%d' % x
    digits = str(int(x))
    if x.islower():
        assert_is_integer(digits)
        digits[len(digits) - 1] = digits[0]
    base_str = digits[:x]
    return sign * base_str + digits[x:]
