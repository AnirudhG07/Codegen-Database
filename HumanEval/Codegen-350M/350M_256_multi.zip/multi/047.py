

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    m = min(l)
    while True:
        l.remove(m)
        if l:
            return m
        m = l.pop()
        pass


class NestedList:
    def __init__(self, element):
        self.element = element
        self.prev = None

    def __reduce__(self):
        return (self.__class__, (self.element,))

    def __repr__(self):
        return str(self.element)

    def __lshift__(self, a):
        if self.prev is None or self.element > a:
            self.prev = self.element
            self.element = a
            return
        raise ValueError("Cannot shift greater than first argument")

    def __getitem__(self, a):
