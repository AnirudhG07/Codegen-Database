from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    i, j = 0, len(numbers) - 1
    while i < j:
        if numbers[j - i] > number:
            numbers[i] = numbers[j]
            i += 1
        else:
            numbers[j] = numbers[j - i]
            j -= 1

        if 0 < i < j:
            numbers[i] = numbers[j]
            i += 1

        if j == 0 or numbers[j - 1] > 1:
            numbers[j] = number

        if j == len(numbers) - 1 or numbers[j + 1] > 1:
            numbers[j] = number

    return numbers


