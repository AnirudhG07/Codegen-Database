
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    if not nums:
        return 0

    sum = [0 for cnt in range(0, nums[-1] + 1, -1)]
    for num in nums:
        subarr = nums[:-1] if ((num > 0) and (num % 2 == 1)) else nums[1:]
        sum[0] += sum[1] + subarr[0]
        for j in range(2, len(subarr)):
            sum[j] -= sum[j-1] + subarr[j]
    return min(sum)


# Your linear program here.
