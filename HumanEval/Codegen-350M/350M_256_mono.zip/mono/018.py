

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    length, start_index, end_index, count = 0, 0, 0, 0
    for index, char in enumerate(string):
        if char == substring[start_index]:
            count += 1
            if count > 1:
                for i_char in range(count, length):
                    end_index = index
                    if character == 'a':
                        if string[i_char + 1] == 'a' and string[i_char]!= 'a':
                            end_index += 1
                        elif string[i_char] == 'a' and string[i_character+1]!= 'a':
                            end_index += 1
                            break
                    else