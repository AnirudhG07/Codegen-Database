

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    for bracket in brackets[::-1]:
        if bracket in ["<", "<>"]:
            return False
        else:
            if bracket == " ":
                pass
                # check whether the correct opening bracket is in "openings"
            else:
                if bracket in ["<", "<>"]:
                    if bracket not in ["<", ">", ">"]:
                        return False
                    else :
                        pass
                        # now we look to see if this close bracket is valid in the opening bracket
                 
                    # if the closing bracket in the opening bracket is <>, we do an '<='. So there may be a close bracket with the opening bracket >