
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    # Calculate the determinant of that triangle.
    det = (a * c) - (b * c) - (a * b)
    
    # If it turns out that the determinant is zero or is an odd number,
    # then the angle between the three sides does not make sense.
    if (det == 0) or (det % 2 == 0):
        return False

    # Check if the left angle is more than 90 degrees.
    if (a * a) + (b * b) > (b * c) + (a * c):
        return True

    # Check if the