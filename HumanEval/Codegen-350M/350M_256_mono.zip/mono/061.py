

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    assert bracketing_check(brackets)
    stack = []
    for bracket in brackets:
        if bracket == '(':
            stack.append(True)
        elif bracket == ')':
            assert stack.pop()
            if stack[-1]:
                continue
            return False
    if len(stack) == 0:
        return True
    return False

