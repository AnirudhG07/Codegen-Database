from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    # Note: here we are performing the factorial of each number in reverse order
    # in order to get biggest factorial first and then return reversed numbers

    # Initialize array
    array = [1]
    factorials = [1]

    # Loop through n's digits until the final result would be greater than 100 or it would be a factorization
    while (n-sum(array) > 100 or n-sum(factorials) >= sum(array)):
        # Get smallest factor of input as the array element
        smallest_factor = min(array