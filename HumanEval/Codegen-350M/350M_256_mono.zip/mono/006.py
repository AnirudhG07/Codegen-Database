from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    paren_lst: List[str] = []
    for c in paren_string:
        if c == '(':
            paren_lst.append(1)
        elif c == ')':
            if paren_lst[-1] == 1:
                pass
            else:
                paren_lst.append(1)
            if paren_lst[-1]!= 0 and paren_lst[1] == 0:
                paren_lst.pop()
            elif paren_lst[1]!= 0 and p