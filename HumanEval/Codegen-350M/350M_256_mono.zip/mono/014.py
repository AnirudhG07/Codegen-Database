from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    prefix = {'a': [], 'b': [], "c": []}
    prefix_len = len(prefix)
    print()
    """
    print('prefix', string)
    print('prefix_len', prefix_len)

    if string[:len(prefix)*.5] not in prefix:
        if len(string) >= len(prefix)*3:
            return []
        print()
        prefix[string[:len(prefix)*.5]] = [string[:len(prefix)*.5]]
        prefix[string[::-1]] += [string[::-1]]
        return prefix.keys()
    else:
        result: List[bool] = []
    # print(string, prefix)
        for i in range(len(string)):
            result += all_prefixes(string[i