from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    res = []

    for s in strings:
        if substring.upper() in s.upper():
            res.append(s)
        elif s[:len(substring)] == substring:
            res.append(s)

    return res

"""
For some reason, I'm not sure this problem is actually useful, it can be improved further to give out
a better alternative.

# I'm going to use regex, but it is too slow, so I was not going to do it.

>>> filter_by_substring([], 'a')
[]
>>> for _ in range(5):
...     filter_