
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # 使用dummy：指针，剪枝，动态规划：
    # 重新补全解为列表
    
    # d1:长度，[左界，插入位置]
    # d1
    # -2 +1 +1
    # 总有小于0的数字数目
    # 最小值的数字从1开始，无越小，�