
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    romans = ["i", "v", "x", "c", "d", "l", "m"]
    roman = {
        100: "M",
        999: "DCC",
        900: "CCC",
        900: "CCC",
        900: "M",
        900: "XICC",
        900: "IXIC",
        900: "X",
        900: "IIII",
        900: "VII",
        900: "III",
    }
    num = []
    num_map = {0: "", 1: "II", 2: "VI