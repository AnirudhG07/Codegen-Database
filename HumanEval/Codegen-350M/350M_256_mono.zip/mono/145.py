
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    nums = sorted(nums)
    new_arr = []
    for num in range(len(nums)):
        new_arr.append(nums[num] + nums[num+1])
    new_arr.append(sum(nums))
    new_arr.sort()
    res = []
    for i in range(len(new_arr)):
        res.append(new_arr[i])
    return res

    pass


# @lc code=end

# @lc main=start
if __name__ == '