
def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    def is_simple_power_(x, n):
        cnt = 0
        while abs(n)!= 1 and cnt<1000:
            if n//1023**cnt == x:
                return True
            cnt += 1
            if cnt < 1000 and n % 1023**cnt ==0:
                cnt += 1
        return False
    return not any(is_simple_power_(x, n) for n in range(