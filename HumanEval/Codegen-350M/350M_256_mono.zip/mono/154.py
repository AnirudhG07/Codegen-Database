
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    if type(a)!= str or type(b)!= str:
        return False
    pattern = r"^" + "".join(a)+r"\W+"+ "".join(b)+ r"$"
    return bool(re.search(pattern, a)) and bool(re.search(pattern, b))