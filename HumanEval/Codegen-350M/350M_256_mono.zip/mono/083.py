
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    if n <= 1:
        return 0

    digitcounts = [0 for _ in range(10)]
    for digit in str(n):
        if 1 < int(digit) < 10:
            digitcounts[int(digit)] += 1

    digitcounts = [count for count in digitcounts if count > 0]
    return len(digitcounts)


