
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    
    for i in x:
        if len(str(i)) % 2 == 0:
            list1.append(i)
    list1.sort()
    
    return list1


# Problem 19
# Given a number x, return True if the number, x, 
# appears at least n times in the series, including more 
# times than the previous entry. Return True if such an entry 
# does not appear.



# For this question, you can assume n is always 
# in {2, 3}

