
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    if a > 0:
        sqr_list = [num**3 for num in range(1, a + 1, 2)]
        for element in sqr_list:
            if element == 1:
                return True
        return False
    return None


print(iscube(2))
print(isdir(4))

#

# TODO: Complete the function printNumbers which takes an integer number 
# an as a parameter.
