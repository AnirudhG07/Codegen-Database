
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    #a, b are lists of numbers. len(a) > 0 and len(b)>=0. A list can be a nested list.
    #A nested list is a nested list, that is [[3, 4, 5, 6], [7, 8, 9, 10]]
    return sum( list( map(sum,zip(a,b)) ) )//len(a)

# print(multiply([148,412],[28]) ) # returns (16, 72)
# print(multiply([19,28],[1851]) ) # returns 0
# print(multiply([14,-15],[-15]) ) # returns (20,)
# print