
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    integers = []
    i = 0
    while i < a:
        i = i + 1
        integers.append(i)
    digit = 0
    while  digit <= b:
        digit = digit + 1
        integers.append(digit)
    return integers


print(generate_integers(2, 8))
print(generate_integers(8, 2))
print(generate_integers(10, 14))