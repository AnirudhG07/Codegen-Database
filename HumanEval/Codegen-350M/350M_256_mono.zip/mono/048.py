

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    # We'll check if all letters in the string are in alphabetical order
    lower_alphabet = "abcdefghijklmnopqrstuuueyz"

    # Create dictionary with all letters
    lowerUpper:dict[str] = {} # This will use a dictionary to convert "ZAB" to "abZC"
    for c in lower_alphabet:
        lowerUpper[c] = c.upper()

    # Iterate over string
    for char in text:
        # Get lowercase char and replace if it's in lowercase
        if char.islower():
            lower = char.lower()
            if lower in lowerUpper:
                # If char is in alphabetical order, create a