

def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """
    string2 = string.lower()
    string2 = ''.join([(string2[i]) for i in range(len(string2))])
    return string2.upper()

TinyDict = dict(tinydict=tinydict, isstring=isequal)

# print(flip_case("Test case", True))
