
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    # find all numbers within the range (x,y)
    x_val = []
    for i in range(x, y+1):
        x_val.append(i)

    new_num = 0

    if len(x_val) > 0:
        for num in x_val:
            if num % 2 == 0:
                new_num = num
                break

    if new_num == 0:
        return -1

    return new_num

