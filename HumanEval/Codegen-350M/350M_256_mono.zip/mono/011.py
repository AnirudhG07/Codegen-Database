from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    c = []
    a = list(a)
    b = list(b)
    for x in a:
        c.append(chr(int(x, 2) ^ int(b[len(b)-1], 2)))
    return ''.join(c)

if __name__ == '__main__':
    a = input("Give first binary character: ")
    b = input("Give second binary:")
    if(b == '0'):
        result = string_xor(a, b)
    else:
        result = string_xor(a, '0' * len(a))

    # Print XOR results to console
    print(result,file=open("binary_xor_result.txt",