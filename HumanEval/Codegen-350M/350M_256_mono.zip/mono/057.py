

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    # If element is not unique, find its previous/next
    return not l[0]) or not l[-1] or (not l[-1]-l[0] < 0 ) # l[-1] = max value, l[0] = min value

