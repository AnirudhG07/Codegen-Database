

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    
    try:
        # for some unknown reason returns type int
        return np.asarray(np.cumprod(xs))
    except ValueError:
        # for some unknown reason returns type int, as it does not know 
        # what data types it produces (ex: np.poly1d might try to cast it).
        return np.arange(1, len(xs) + 1) * np.cumprod(xs)

