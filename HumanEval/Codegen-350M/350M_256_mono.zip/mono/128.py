
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if not arr: return None
    
    mps = [0] * len(arr)
    
    m_s = product_signs(arr, mps)
    if not m_s: return None
    
    if m_s[0]!= 0:
        for i, elt in enumerate(arr):
            mps[i] = -arr[i] * m_s[i]
        
        m_s = product_signs(arr, mps)
    
    return sum(m_s)


if __name__ == '