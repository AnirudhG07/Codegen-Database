

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    return (a * h) / 2
    pass


# ------------------------ MAIN -----------------------------------
if __name__ == "__main__":
    area = triangle_area(5, 3)
    print("A triangle of " + str(5) + " with a base of " + str(3) + " is [area = " + str(area) + "]"
          "\n")
