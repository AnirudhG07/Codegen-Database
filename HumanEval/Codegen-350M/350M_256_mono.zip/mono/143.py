
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    sentence = sentence.strip()
    nkmer = [0, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 17, 19, 21, 22, 23, 24, 25, 28]
    c_min = 9999
    res = {}
    for k, v in nkmer.items():
        c = count_pairs(