from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    left, reverse_left = [], list(range(len(numbers) + 1))
    found = 0

    # Check for duplicate
    for i in numbers:
        if i in left:
            found += 1
        else:
            left += [i]
            reverse_left[len(left) - 1] = left.pop()

    # Return result
    new_numbers = [x for x, _ in enumerate(numbers) if x not in left]
    return new_numbers + reverse_left[found:]

