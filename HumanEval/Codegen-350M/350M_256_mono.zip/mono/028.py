from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    if len(strings) == 1:
        return strings[0]
    if not strings[-1].endswith(strings[0][-1].swapcase()):
        return ''.join(strings[:-1]) + strings[-1].swapcase()
    else:
        return strings[0] + ''.join(strings[1:])
