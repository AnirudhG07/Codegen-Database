from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    x = 0
    i = 0
    temp = [0 for _ in range(numbers[0])]
    while x < numbers[0]:
        if numbers[i] > temp[x]:
            temp[x] = numbers[i]
        else:
            x += 1
            if x == x:
                x = numbers[i]

        i += 1
        print(temp)
    return temp


