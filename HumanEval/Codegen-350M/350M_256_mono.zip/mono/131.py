
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    even = 0
    odd = 0
    while n:
        if n % 10 == 0:
            even = even + 1
        else:
            odd = odd + 1
        n = n // 10
    if even:
        return even * odd
    else:
        return odd * 0


# @lc code=end