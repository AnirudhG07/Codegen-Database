from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if not numbers or not numbers[0]:
        return []

    left = numbers[0]
    right = numbers[1:] if len(numbers) < 3 else numbers[:2]
    return left + [delimeter, sum(right) if right else right]