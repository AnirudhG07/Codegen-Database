

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    counter = {}
    gcd(a, b)
    for x in range(1, a + 1):
        if a % x == 0:
            if int(x) not in counter:
                counter[int(x)] = []
            if int(b) not in counter[int(x)]:
                counter[int(x)].append(int(b))
            continue

    gcd = max(counter.values())

    for key in counter:
        if counter[key] == []:
            counter.pop(key)
    
    return gcd


#%%


