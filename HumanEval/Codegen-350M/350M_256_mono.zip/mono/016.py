

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    return len(set(string.lower()))


if __name__=="__main__":
    assert count_distinct_characters('') == 0
    assert count_distinct_characters('aaa') == 4
    assert count_distinct_characters('Abba') == 1
    assert count_distinct_characters('aa') == 3
    assert count_distinct_characters('a') == 0
    assert count_distinct_characters('1234') == 0
    assert count_distinct_characters('Yayyayyayyay') == 0
    assert count_distinct_characters('ababab') == 0
    assert count_distinct_characters('AAABAAxyz') == 3
