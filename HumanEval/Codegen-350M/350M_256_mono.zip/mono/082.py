
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    nums_list = []
    for num_i in range(len(string)):
        if string[num_i] in '1234567890':
            nums_list.append(int(string[num_i]))

    nums_list.sort()

    for num in nums_list:
        if num % 2 == 0:
            return False

    return True

