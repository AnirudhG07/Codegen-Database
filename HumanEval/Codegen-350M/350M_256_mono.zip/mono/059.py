

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    sq_n = n
    sq_n_2 = n
    sq_sq_n = 2*sq_n
    i = 0
    max_factor = 1
    while i < sq_sq_n+1:
        if (sq_sq_n % i) == 0:
            if i == 1:
                return sq_sq_n
            sq_n_2 *= sq_sq_n // i
            i = 0
        else:
            i += 1
            sq_sq_n //= i
    if sq_n.is_prime == True:
        return sq_n_2
    else:
        return 1

