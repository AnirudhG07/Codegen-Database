
def odd_count(lst):
    """Given a list of strings, where each string consists of only digits, return a list.
    Each element i of the output should be "the number of odd elements in the
    string i of the input." where all the i's should be replaced by the number
    of odd digits in the i'th string of the input.

    >>> odd_count(['1234567'])
    ["the number of odd elements 4n the str4ng 4 of the 4nput."]
    >>> odd_count(['3',"11111111"])
    ["the number of odd elements 1n the str1ng 1 of the 1nput.",
     "the number of odd elements 8n the str8ng 8 of the 8nput."]
    """
    i = "." * len(lst)
    while i > 0:
        i -= len(lst) // 2   # clear out the extra n
        new_i = i % 2 // 2
        # if i is odd and it's a plus symbol (3 or more), the n must equal 1
        if new_i not in ['+', 'n']:
            new_i = 1                     # or you can use a n!=1 check here to avoid messing up the rest of the input
            new_i = new_i + new_i         # or if n isn't a number that's odd,
                                           # add 1 to it
        else:
            i = i + 1                     # replace this for efficiency
        new_i = i + new_i                 # or if n isn't a number that's odd,
                                          # add 1 to it
    if new_i % 2 == 0:
        raise ValueError("Your number contains only numbers and commas between 1 and the number of chars to be entered")
    new_str = "(%s and %s)" % (i, new_i.)
    for _ in xrange(len(lst) - new_i):
        _ = lst[new_i + _]
    return new_str.apply(lambda x: x.capitalize())

