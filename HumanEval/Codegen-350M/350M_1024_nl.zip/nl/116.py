
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    def is_even(n):
        yield n
        for i in range(0, len(arr)):
            if n % i == 0:
                return len(arr[i:])!= 0
        n = int(n) // 2 ** (len(arr) - 1)
        if is_even(n):
            return [i + n for i in arr]


class WordWise(WordWiseOrDie):
    """
    For many different WordBase.word_base types with same input length,
    different output length, and different output types, this class generates
    distinct outputs. The following code is an example of a "wordwise" variant
    of "word" or "wordbase". Any class could be used to make the same point by
    passing a keyword argument for all the other types.

    :param count: How many bits per WordBase (or WordBaseOrDie) will be output,
                   the input length, or a combination, as desired.
    :param count_bpp: The number of bpp will be output.
    """

    __slots__ = ['count', 'count_bpp']

    def __init__(self, count=0, count_bpp=16):
        """
        :param count: Number of bits per WordBase or WordBaseOrDie
        :param count_bpp: The number of bpp will be output, as desired
        """
        assert count > 0
        self.count = count
        self.count_bpp = count_bpp
        self._count = count

    def count(self):
        return self._count

    def count_bpp(self):
        return self.count_bpp

    def get_input(self):
        return [int(u) * 2 for u in self.count as b]

    def get_word_base(self, bpp=16):
        return bpp

    def word(self):
        assert self.count_bpp == 16
        return self.count_bpp


class WordWiseSymbols(WordWise):
    def word(self):
        return self._count

    def get_input(self):
        return self._count

    def get_word_base(self, bpp=16):
        return self.count_bpp as (str, float, bool, dict, char)

class WordWiseOrDie(WordWise):
    def word(self):
        return self._count

    def get_input(self):
        return self._count
