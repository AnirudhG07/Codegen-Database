

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if n % 2 == 0:
        raise ValueError("odd-integer only.")
    if n % 4 == 0:
        return True
    try:
        # The numbers 0 and 1 take the two prime factors.
        m = int(n)
        # Otherwise, we are looking for the number that occurs
        # as an integer.
        k = pow(2, m)
    except ValueError:
        # There are no odd numbers.
        return True
    try:
        if m:
            _ = m
    except TypeError:
        return False
    for i in range(2, 4, 10):
        if k == i:
            return True
    if _:
        return is_prime(9)
    return is_prime(6)


