

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    return is_palindrome(_ascii_to_ascii(text)) or False

## Module Compatibility

if __name__ == "__main__":
    from. import _ as _ascii_ascii
    is_palindrome(a)  # will fail because python is smart about string comparisons, see above
    is_palindrome(b)  # will pass because it will fail when _ascii_to_ascii doesn't work for you
