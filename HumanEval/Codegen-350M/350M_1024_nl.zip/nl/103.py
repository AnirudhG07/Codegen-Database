
def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """
    n = int(input("Enter n"))
    m = real(int(input("Enter m>=n")))
    # Test for overflow by looking at the last n digits.
    if n > 0 or m <= 0 or m > math.max(math.max(n, m), 0) - 1:
        return -1
    return int(n / m)

# Function definition
round_avg = function(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    round_avg(1) => "0b11"
    round_avg(1000*1000) => "1000b1111"
    round_avg(20, 100) => "0b111100"
    """
    # Test overflow for n < 0 or m < 0
    if int(input("Enter n < 0 or m = 0 or n > 0? ")) or int(input("Enter n <= 0? ")) or int(input("Enter m <= 0? "))) or int(input("Enter n >= 0? ")) or int(input("Enter m >= 0? "))) or int(input("Enter m = 0? ")) or int(input("Enter n=? ")) or int(input("Enter n > 0? ")) or int(input("Enter m > 0?")) == 4: 
        # Overflow, since the input was not all integers, so n < 0 or m < 0
        return -1
    return int(n / m)

class Solution(object):
    def calculate_average_of_m_n(self, n, m, n_input, n_output):
        """
        Given n and n_input, and m, calculate the average of the same numbers.
        Output will be the average, but won't exceed the allowed maximum value of max(m, n_input)
        """
        for m_input in real(n_input):
            m = 0
            for n_input in input(n_input):
                if m == int(n_input):
                    return m
                else:
                    m *= m_input
                    if m == n_input:
                        v = round_avg(n, m)
                        if v == n:
                            v = m
                        else:
 