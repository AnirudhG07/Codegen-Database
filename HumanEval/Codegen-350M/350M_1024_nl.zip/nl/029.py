from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    parts = {}

    for a in strings:
        for b in a:
            for _, a_prefix in prefixes(a, b):
                # if 'prefixes' is not an empty list, do not prefix
                if not isinstance(a_prefix, list):
                    if 'a_prefix' in prefixes(a_prefix):
                        parts[a_prefix] = a_prefix
    return parts


