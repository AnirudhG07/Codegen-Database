

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    if brackets == "," or brackets == "[" or brackets == "{" or brackets == "," or brackets == "}":
        return False
    brackets = bracket_re.sub(r"\s*$", brackets)
    brackets = brackets.split(brackets, 1)
    # if we have a valid bracket and want to correct it
    if brackets == "[" or brackets == "]" or brackets == "{" or brackets == "}":
        return True
    # otherwise throw an error
    return False


