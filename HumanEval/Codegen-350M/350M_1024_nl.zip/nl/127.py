
def intersection(interval1, interval2):
    """You are given two intervals,
    where each interval is a pair of integers. For example, interval = (start, end) = (1, 2).
    The given intervals are closed which means that the interval (start, end)
    includes both start and end.
    For each given interval, it is assumed that its start is less or equal its end.
    Your task is to determine whether the length of intersection of these two 
    intervals is a prime number.
    Example, the intersection of the intervals (1, 3), (2, 4) is (2, 3)
    which its length is 1, which not a prime number.
    If the length of the intersection is a prime number, return "YES",
    otherwise, return "NO".
    If the two intervals don't intersect, return "NO".


    [input/output] samples:
    intersection((1, 2), (2, 3)) ==> "NO"
    intersection((-1, 1), (0, 4)) ==> "NO"
    intersection((-3, -1), (-5, 5)) ==> "YES"
    """
    if not intervals:
        return "NO")
    if interval1 == interval2 == interval:
        return "YES")
    return intersection(interval1, interval2) is number and not "NO"


  def test(self, interval1, interval2):
    """For testing interval1, interval2, and intervals may be the integers.
    The output of the tests is two numbers, not all-zero.
    The inputs of test are (end1, start1) and (end2, start2), and the given intervals
    can be one of them. If the interval(s) exist, an output of "YES" is returned.
    If there is no interval(s) between start1 and start2, the output is a pair, and
    an output of "NO" is returned.
    If the two intervals exist, it is assumed that interval1 and interval2 are "even".
    If the two intervals are not "even", interval1 and interval2 are "odd".
    """
    e1, e2 = interval1, interval2
    if e1 == e2 == number:
        return "YES"
    return "NO"


  def testInterval(self, start1, end1, start2, end2):
    """For testing interval.
    Input:
    start1         : One of interval1 (int), interval2
    end1           : One of interval1 (int), interval2
    source         : Interval in interval, end=end1, start=start1
    """
    return time(start1, source)==start1 is number and not "NO"

"""A `IntervalTest` object describes a test to confirm if two intervals (the
two intervals in this work, are of the same type) are contained in the testing
intervals."""


class IteratorTest(object):
  """This test uses a single-linked tree and iterate it."""

  def __init__(self):
    self.begin()
    self.end = self.end - 1

  def __iter__(self):
    '''Iterate the tree to the next test-iteration point.
    The `self.iteration` is always an object of the test-type.
    Subscript indicates that it is a `self.iteration`.
    '''
    for item in self.begin().iter_traversal():
      item.next()


  def __iter__b(self):
    '''Borrow the tree from the first iteration. (Do not change the structure!)
    '''
    self.begin().iter_traversal()
    self.begin()


  def test(self):
    """