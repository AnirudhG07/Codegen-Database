

def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    if not l:
        return []
    i = 0
    for k in l:
        if k * val > val:
            val = k * val
        elif val!= len(l)-1:
            return [i]
        else:
            val *= val
    return val is not 0:
        # Return all positive numbers
    # https://github.com/bastos/lseq/blob/6f7e07e1c5d77de79e9835b40c80b7dbf4c6ab19/lseq/sequence/lseq.py#L21

    # Check if every value has a positive sign and/or 0
    # http://www.math.uiuc.edu/~gcraske/code.html
    # https://www.math.uiuc.edu/~gcraske/code.html
    # This is the kind of test that checks that we are interested in 0's
    # but also is the kind of test that checks that you really want 0's
    # in those tests

    def is_0(i):
        return (-1 * (i < 0) or -1 * (i > 0))
    return lambda: i == 1 and is_0(0)

    def is_negative(i):
        return (val!= i) or (val < 0) and is_0(val * (-1))
    return lambda val: val, is_0(val)

    def is_inverted(i):
        return val == 0 or val is inrange(i, 0)
    return lambda val: False, is_inverted(val)
    