
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    n=nums
    if len(n) == 1:
        minSum=int(n[0])
    else:
        minSum=sum(n)[0]
    return minSum

    def sum(s):
        if s==0:
            return 0
        elif s==1:
            return sum(s)
        elif s==2:
            return sum(s) + sum(s)
        elif x==1:
            return sum(s)
        elif x==2:
            return sum(s) + (sum(s)-sum(s[0])/list(s))
        elif x==3:
            return sum(s)
        elif x==4:
            return sum(s) + sum(s)[int(x)+1]
        else:
            return sum(s)[int(x)+1]

        def minSum=sum(s)[int(x).pow(2),int(x)-1].pow(2)
        return sum(nums)[int(s).pop(),int(nums) - sum(nums)][int(s).pop()+1]     

if __name__=='__main__':
    test(4)

