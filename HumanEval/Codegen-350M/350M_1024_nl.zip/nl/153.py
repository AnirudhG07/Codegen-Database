
def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) =='my_class.AA'
    """
    for name in extensions:
        if name in class_name:
            return class_name[name]
    return 'My_class'

class my_extension:
    attr_members = ('attr_weak', 'attr_strong')

    def __init__(self, attr_weak, attr_strong):
        self.attr_weak = attr_weak
        self.attr_strong = attr_strong

    def load(self, data, path):
        c = MyClass.Class()
        c.attr_weak = data.get('attr_weak')
        c.attr_strong = data.get('attr_strong')
        return c

My_class = my_extension()
print My_class.attr_weak

Output: MyClass.attr_weak
attr_weak = AA
attr_strong = BeCC
attr_weak = CC
attr_strong = Chees
attr_weak = CSe
attr_strong = Effed
attr_weak = C
attr_strong = Eaa
attr_weak = Slices
attr_strong = SeRuF
attr_weak = SLiCes
attr_strong = CsE
attr_strong = EC

