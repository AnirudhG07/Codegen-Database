from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    levels = [len(x) for x in paren_string.split(r) if not x]
    level_count, level_count_nested = [1]
    nums_to_group = parse_nested_parens('numeric')
    for level in levels:
        if len(level_count) > level:
            nums_to_group += 1
            level_count_nested = level_count_nested
            level_count = level_count_nested
        level_countnested = parse_nested_parens(level_count)
        if len(level_countnested):
            break
        elif nums_to_group!= level_count:
            nums_to_group += parse_nested_parens('(')
        nums_to_group = (nums_to_group // 2)
        nums_to_group = nums_to_group + parse_nested_parens(')'
    nums_to_group
    nums_to_group_nested = [nums_to_group]
    return nums_to_group_nested

