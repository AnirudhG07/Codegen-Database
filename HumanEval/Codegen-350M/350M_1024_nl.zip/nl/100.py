
def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """
    stones = [0] * (2+2)
    while 1:  # next odd number
        n = int(input('n: '))
        stones += [0] * (n // 2) if n % 2!= 0 else 1
        n = int(input('n: '))
        stones += [0] * (n // 2) if n % 2!= 0 else 1
        n = int(input('n: '))

    # move next level up (first even)
    next_level = 0
    while 1:  # next even number
        n = int(input('n: '))
        stones += [0] * (n  // 2) if n % 2!= 0 else 1
        next_level += 1

    # move next level up (first odd)
    next_level = 0
    while 1:  # next odd number
        n = int(input('n: '))
        stones += [0] * (n %% 2) if n % 2!= 0 else 1
        next_level += 1

    return len(stones)

