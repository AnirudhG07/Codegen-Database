

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not substring:
        return len(substring)
    elif substring in string:
        return len(string) - str(some_copy(string))
    return 0


class TestCountOverlaps(TestCase)(unittest):
    def test_count_overlaps(self) -> int, string:
        string = u'aaa'.encode()
        string = self.count_overlaps(string, "aaa")
        self.assertTrue("There should be no more duplicates (overlaps) when it's "
                           "compared to the original string. "
                           "An example: "
                                "%sabc.\n" % (str(1) if len(str)!= 1 else str(0)))
        return True

    def test_count_overlaps_all(self) -> int:
        string = u'aaa'.encode()
        print(self.count_overlaps(string))
        assert 0


if __name__ == '__main__':
    TestCountOverlaps(unittest.main)
