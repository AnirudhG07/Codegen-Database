
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    N = sorted(nums)
    n_i = 1
    if len(n_i) == 2:
        n = sorted(n_i)[::-2, n]
    n = n_.ljust(len(n_i)[0])
    if order in keyed_orderable_sequence(N):
        return N
    elif len(n_i) == 3 and order in n[1:]:
        return n[1:3]
    for i in range(n[1], n[2]):
        n[i-1] += nums[i]
        if n[i] < 0 or not nums[i - 1] <= 0:
            n[i] = -n[i]
        else:
            n[i] = nums[i]
    return n


