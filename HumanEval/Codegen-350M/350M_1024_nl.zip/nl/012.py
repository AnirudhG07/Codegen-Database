from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if len(strings) == len(str(None)):
        if len(strings) < len(str(None)):
            return None
        return self.ascii_str(str(self.utf8))
    if not isinstance(strings, list):
        return strings[-1]
    if len(strings) < len(str(None)):
        return None
    if not isinstance(strings, str):
        return strings
    return strings[-1]
    
