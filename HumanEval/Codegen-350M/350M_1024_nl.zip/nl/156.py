
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    a = str(number)
    b = unicode(a)
    char_list = ([a.lower() for _ in range(1, b.size-1))[:-1] for a in b.tolist())
    b = b[:-1]
    print(char_list)
    def to_mini_roman(letter):
        char_list = b.lower()[:b.size-1]
        return char_list[-1]
    for c in char_list:
        int_to_roman(sorted(c, key=len))

A:

>>> from collections import defaultdict
>>> list(i)
['a', 'b']

The defaultdict works for any type. For example:
>>> def get_default_dict_to_dict(dictDict):
...     for k, kl in enumerate(dictDict):
...         if '.' not in k:
...             del k[k]
...

And you can write:
>>> default_dict = {'a': [str('a')], 'b': [str('b')]}
>>> get_default_dict_to_dict(default_dict)
{'a': ['xixi', 'xixi', 'xixi', 'xixi', 'xixi', 'xixi'], 'b': ['xidixiii', 'xixi', 'xixi', 'xixi', 'xixi'], 'c': [str('cli')] }
>>> get_default_dict_to_dict(default_dict)
{'a': ['xixi', 'xixi', 'xixi', 'xixi', 'xixi', 'xixi'], 'b': [ 'xidixiii', 'xixi' ] }

Of course, you will need to change the order of operations of the three loops. You could also keep that default_dict, and change it to a lazy defaultdict with a key called _dict_:
>>> default_dict = lazydefaultdict((get_default_dict_to_dict))
>>> get_default_dict_to_dict(default_dict)
{'_dict': {'a': ['xixi', 'xixi', 'xixi', 'xixi', 'xixi'], 'b': ['xidixiii', 'xixi' ] } }
>>> get_default_dict_to_dict(default_dict)
{'_dict': defaultdict(default=default_dict)}

A:

Use.lower() to lowercase.

I have a solution with a regex:
>>> from itertools import reduce
>>> from operator import itemgetter
>>> a = 'xixi'.lower()
>>> p=re.compile('(?x)(\\1)').sub(lambda m:m.lower(), a).lower()
>>> for _,m in p.findall(a):
...     print(m.group(1))
...

If you are only interested in the roman numerals, a:
>>> import re
>>> a='Roman'
>>> re.sub('(?x)(\d)(?=\n)?', lambda m: m.upper().lower(), a)
'\2'

A:

from collections import defaultdict

class my_dict(defaultdict):
    def __getitem__(self,key):
        if self._object_name == 'object' and not is_same(self._object_name, object_name):
          