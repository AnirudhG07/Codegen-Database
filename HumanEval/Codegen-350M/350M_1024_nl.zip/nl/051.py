

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    replace_vowels = [
        'abcdef\n',
        'cdef',
        'gdef',
        'hdef',
        'hiij',
        'jklm',
        'lmnr',
       'mnr',
       'smbm',
        'tmnr',
        'twmjklm',
        'xyz',
    ]
    return remove_vowels(text)

"""
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Remove vowels in strings of a base character')  # noqa
    parser.add_argument('filename', type=str, nargs=1, help='Filename of the file (must be in base character character)')
    parser.add_argument('--keeps', type=str, nargs=1, help='keeps a file where vowels will be kept')
    parser.add_argument('--remove_vowels', action='store_true', help='remove vowels and word-wrap')
    parser.add_argument('--write-ext', action='store_true', help='write the file (separated by, and newline)')
    parser.add_argument('--check_word_wrap', action='store_true', help='check the word_wrap option (see [2])', help_default="false")
    parser.add_argument('--check_regex', action='store_true', help='check the pattern (see [2])', help_default="false")
    args = parser.parse_known_args()
    if args.remove_vowels:
        args = args.remove_vowels(filename=args.filename, check_regex=args.check_regex)
    if args.write_ext:  # file content is non-conforming
        args = args.write_ext(filename=args.filename)
    script(script_arg_spec=args)
