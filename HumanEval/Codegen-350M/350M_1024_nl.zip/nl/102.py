
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    int_sum = 0
    for i in range(1,2):
        if (i == 0 || i % 2) == 0:
            if int_sum > 0:
                return int_sum
    return -1

