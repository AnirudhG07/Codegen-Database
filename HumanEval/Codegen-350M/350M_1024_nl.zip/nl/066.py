
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    total = ""
    print(s)
    while True:
        x, y = s = s.split(s.rfind(".")+1, 1)
        while x < len(x) and y < len(y+1):
            total += x.find(s)[:-x] + y[:-y]+1
            x, y = s.split(s.rfind(".")+1, 1)
        while x < len(x) and y < len(y+1):
            total += x+s[x-1]
            x, y = s.split(s.rfind(".")+1, 1)
        print(total)
        s = s.replace(s="", "")
        print(total+s)
        s = s.replace(s="", "")
        print("Success")

        print(total)


if __name__ == '__main__':
    print('Hello world!')
