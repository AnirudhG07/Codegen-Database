
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    for c in text:
        if c!= '':
            p = r.insert(" " * (p.count(' ') - 1) - 1, c)
        else:
            p = r.insert(c.replace(''* (p.count(' ') - 1) - 1), c)
    if p!= r.next():
        text = text.replace(" ", "")
    return text

# ---------------------------------------------- --

class Program:
    def test_string_to_numeric(self):
        p = "foo"
        i = p.rfind('<')
        if i < 0: 
            i = "<foo>"
        return(p)

