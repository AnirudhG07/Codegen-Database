

def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    # We need to account for the fact that a sum of numbers between 0 and
    # nth_element might yield a negative number.
    l.extend(
        [f for f in below_threshold(x) if x==f]
    )
    return l.find(not l) == 0


