

def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

However, every example below will generate this error:
ExceptionTypeError: Cannot convert 'int' to string

If either int or string is used as the argument to unique, it will give us the error. This is expected:
unique([4, 6])

Should be:
unique([4, 6])

I'm expecting:
['4','6']

Which I think is what it is asking for -- but this would lead to a very specific error.
I can see that the problem is in Python not in C:

A:

It's saying that you have "sorted" the list - int. It doesn't sort elements in the same order they are added.

If you want your data to not order your elements inside the same
  list when they are added or sorted, you'll need to handle that yourself

If you want the original list to be shuffled and added into a new list, you'll probably better go with:
l_new = np.argsort(l)

But, if you only care about your original data structure being shuffled around, then the solution is probably not that ugly either.

