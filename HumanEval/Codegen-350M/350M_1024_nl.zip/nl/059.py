

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if (n > 1 and n > 29) and (n < 2):
        raise ValueError("prime factor too large")

    def greatest_prime_factor(n: int):
        """Return the greatest prime factor of n. Assume n > 1 and is a prime.
        >>> greatest_prime_factor(43)
        2
        >>> greatest_prime_factor(12345)
        1
        """

        if n > 1 and n > 29:
            return n
        return 1

    return GreatestPrimeFactor(n)

