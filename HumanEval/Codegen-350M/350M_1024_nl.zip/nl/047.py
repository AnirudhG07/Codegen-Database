

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    return l[0] < l[1] and l[0] < l[2] and l[0] < l[3]
```

## See Also



* [**Data.Data**](https://developers.google.com/data/docs/python/api/index)
* [Datadog client](https://docs.datadog.com/)
