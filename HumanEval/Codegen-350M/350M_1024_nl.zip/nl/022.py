from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    def filter_all_integers(values_all_integer: List[Any]) -> List[int]:
        if len(values_all_integer) < 2:
            return None
        for value in values_all_integer:
            if value == '0' or value == '1':
                v = value
                break
            else:
                v = value * '0'
    return [int(v) for v in values_all_integer]


