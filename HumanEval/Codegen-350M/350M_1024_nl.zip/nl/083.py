
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    # First, verify that the n can be positive. If not, use an empty list.
    if int(n) <= 0:
        return 0

    if n == 1:
        # The first digit in each integer represents the 1
        return 1

    # The nth digit in each integer represents the n-1 digit plus either
    # - the initial digit, or - 1.
    d = n % 2

    # The first N-digit digit is - 1
    if d == -1:
        # n-1 digits
        # The second N-digit is 1; add 1 to the result.
        return d + 1

    # The nth digit in each integer represents the n-1 digit.
    # +1 represents the number +1 in n.
    return 1 + 1 + n - d * n


