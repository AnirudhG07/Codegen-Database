

def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    return number - (number % 0.5).astype(int)

  def int_to_decimal(num: int) -> float:
    """ Given a number, it's truncated to its int part.
    >>> int_to_decimal(3)
    0.
    >>> int_to_decimal(-1)
    -1
    """
    return float(num) / (int_to_decimal(int(num)) - 1)

  @property
  def int_to_decimal() -> float:
    """ Return the decimal part of an int value.

    >>> int_to_decimal(3)
    3
    >>> int_to_decimal(-1)
    -1
    """
    if not isinstance(val, Number):
      raise ValueError('Needed type' only valid if numpy.iscomplex(int(val))):
    return numpy.sign(val)

  @property
  def float_from_int(num: float) -> int:
    """ Return the number of decimal digits of its binary value.

    >>> float_to_int(3.0)
    1
    >>> int_to_decimal(3.0)
    1
    """
    if isinstance(val, Number):
      return val
    else:
      try:
        return int(val)
      except TypeError:
        raise ValueError('Needed type' only valid if numpy.iscomplex(int(val)))
    return val


