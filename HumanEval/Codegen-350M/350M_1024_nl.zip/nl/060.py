

def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    sum = 0
    for i in range(n):
        sum += i
    return sum/n

If I just add this to my main function it works fine:
import sum_to_n
print sum_to_n(5)
print sum_to_n(100)

But, I would like to have the function being used only for summing numbers and not numbers with the digits in it.
Any help would be greatly appreciated.

A:

You can implement a function as below which only sums the numbers with the digits in the argument:
import re

repr = re.compile(r'(?P<number>[0-9]+)')

