

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    n = 2 * n % 2
    n += n / 2
    n -= n / 2
    if n <= 0:
        return 0
    p = n < 0? -(n - 1) : n
    p -= 1
    d = 2 * p
    if not p:
        return p
    p -= 1
    if p <= 0:
        return d
    else:
        d = p + 1
        return d
    assert p > n
    return smallest_divisor(p)

