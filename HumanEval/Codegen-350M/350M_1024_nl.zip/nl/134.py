
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''
    # This is a string like "a b c d e f g h i l m n n".
    return check_if_last_char_is_a_letter(txt) is not None

    # This is a single word ending with an alpha.
    return check_if_last_char_is_a_letter(txt.rune("alpha")) is not None


