from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    groups = '\n'.join(split_groups(paren_string) for _ in range(0, len(paren_string), 1))
    groups += (repr_literal(paren_string) if not repr_literal(paren_string) else ')'
    groups += '\n'
    return groups


class _Reprinter(ReprTemplate):
    """ Reprint an item's contents, keeping the internal space.

    This method does the same thing as recursively using *repr*
    Instead of keeping the indent character by default, it keeps it at least
    indent 1.
    >>> _Reprinter('  (a) b  ')
    Text content:
    ''
    >>> _Reprinter('asdfg').replace('  ',"_")
    'asdfg'


class _Reprint(ReprTemplate):
    """ Recursively output lines, keeping at least 1 indent indent characters above
    and 1 indent characters below. (This allows `\n` lines with spaces to pass without
    raising a UnicodeDecodeError.)
    >>> _Reprint('  (   a)(x)(y)(z)   ')
   '         '
    >>> _Reprint('-asdfg').replace('  ',".\"")
   ' +. -- -- --- X  +.Y-+Z -- -- -- -- --   '
    """
    indent_chars = 1
    indent_level = 1
    def_level = 1

    def_chars = '\n'.join(split_groups(next(repr(next(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr(repr
...
    def_chars is not None)
    def_level is not None)
    def_level if not def_level else 1
    def_chars)

When
class _Text(_Reprinter):
    """ A _Text is a `Reprinter` instance to be output in strings to a file or to be pasted
    to a browser.
    >>> w'SomeString'
    'SomeString'
    >>> w'\n[This is another line]This is another line'
    >>> w'\n[[[This is another line]]This is another line\n[[[[This is another line]][[This is another line]]This is another line\n]' \
    '"This is another line" : '
    """
    def __init__(self, template):
        self._file = template.file
        self._line = template.line
        self._template_line = template.line_string

Then, this code is
   ...
   ...
   