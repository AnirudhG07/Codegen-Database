
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    # print(str(s))
    # string = 'aBCdEf'
    # length = str_count(string)
    # vowels = string.lower()
    # uvc = string[len(string)-len(vc)]
    # count = count_upper(vc)
    # print count
    # print len(vc) - len(v)
    # print len(uvc)

A:

To count the first 2 uppercase letters of a string (in an array):
vocabulary = [s.split() for s in list(s[1:])]

The following code counts the first 3 uppercase letters on the second level (array)
for v in vocabulary : 
  count_upper = vocabulary.count_upper(v)

The above code is probably too long for your case, but it can be summarized into the following lines:
a : The string to count
b : The array to build a tuple out of
c : the index of the first 2 letters of the first 2 letters of the first 2 letters of the string
count_upper = vocabulary[:,str(a)[0]]
count_upper.append(count_upper)

