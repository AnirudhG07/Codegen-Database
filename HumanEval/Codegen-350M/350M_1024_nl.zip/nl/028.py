from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    for item in strings:
        if item:
            parts = [re.sub('_\(|\)', '_', item) for re in item[1:].split()]
            parts = [re.strip() for re in parts]
            parts = ''.join(parts)
    return ''.join(parts)


