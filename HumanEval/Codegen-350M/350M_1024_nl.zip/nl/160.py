
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    array = operator
    operand_list = [operator]
    for p in operand:
        array[p].extend(operator)
        if operator == []:
            operand_list = [p for j in operand if j == operator]
    result = pow(2, operand_list[[0]]) - operand_list[[0]]
    return result

a = [1, 2, 3]
b = [1, 2, 3]
a[2] == b[2]
print(eval(a))
print(eval(b))

eval of b is:
('+', 2,[1,2,3]),
('-', 3,,[1,2,3]),
0

eval of a is:
('+', 2, [[1,2,3]],
('-', 3, [[1,2,3]],
0)

A:

Here is an answer to your original question. Unfortunately this works the wrong way around with the built-in eval function, so you will need to use enumerate and do some string manipulation on your list objects to get what you want.
import sys

class Addition(operator):
    def __iter__(self):
        return operator(self)

class Subtraction(operator):
    def __iter__(self):
        return operator(self)

class Multiplication(operator):
    def __iter__(self):
        return operator(self)

class Difference(operator):
    def __iter__(self):
        return operator(self)

