
def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """
    for N in range(1, len(n)):
        result = even_odd_palindrome_explanation(n)[N]
        print("result: " + result)


class EvenInteger(Integer):
    """
    This is a base-2 integer that gives the number of even and odd integer
    values. It implements the binary search algorithm by testing the binary search
    property of given input integer. 

    It is equivalent to the stdlib 'even-in-range' and 'even_odd_in-range'
    methods.

    @See: base-2_test_integer()
    """
    def __iter__(self):
        return even_odd_palindrome_explanation_explanation(self)

class OddInteger(Integer):
    """
    This is a base-2 integer that gives the number of odd and even integer
    values. It implements the binary search algorithm by testing the binary search
    property of given input integer. 

    It is equivalent to the stdlib 'odd-in-range' and 'odd_even_in-range'
    methods.

    @See: base-2_test_integer()
    """
    def __iter__(self):
        return odd_even_palindrome_explanation_explanation(self)

class EvenInteger(Integer):
    """
    This is a base-2 integer that gives the number of even and odd integer
    values. It implements the binary search algorithm by testing the binary search
    property of given input integer. 

    It is equivalent to the stdlib 'even-in-range' and 'even_odd_in-range'
    methods.

    @See: base-2_test_integer()
    """
    def __iter__(self):
        return even_odd_palindrome_explanation_explanation(self)

class HalfInteger(Integer):
    """
    This is a base-2 integer that gives the number of half integers. It
    implements the binary search algorithm by testing the binary search
    property of given input integer. 

    To be explicit it is equivalent to the stdlib 'half-in-range' and 'half-in-range'
    methods.

    Example1:

        Input: 3
        Output: 2, 1, 1, 1.
        Explanation:
        The number of half-integer within the range(1, 1 * 2)
    """
    def __iter__(self):
        return half_in_range_explanation(self)


class Square(Integer):
    """
    This is a square number.

    @