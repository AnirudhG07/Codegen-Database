

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    for i in range(1, n):
        y = 2
        x = n * i
        result = (x**y) + x
        if result < y: y = result
    return x


