
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello!!!Wdlor'
    """
    out_string = str(s.strip())
    words = []
    spaces = 0
    start_pos = 0
    for words[start_pos] in s.split():
        if spaces == 0:
            i = len(words)
            chars = words[start_pos:i]
            for charschar in chars:
                chars.replace(charschar, space)
        words.append(words[start_pos:i])
    words.sort()
    return words[:start_pos], words[start_pos+1:]
class AntiWord(object):
    def __init__(self, words_arr):
        self.num_of_words_=words_arr.count(',')

    def shuffle(self):
        """
        Get an array of the words of the document to replace/concatenate.
        """
        num_of_words = self.__dict__.get(self.__class__, 0).get('num_of_words_', 0)
        self.max_num_of_words = num_of_words
        self.chars_arr = self.__dict__.get(self.class_, {})['_chars_arr']

    def add(self, word):
        self.max_num_of_words += len(self.max_num_of_words)
        word['word'] = word
        self.max_num_of_words -= len(self.max_num_of_words)
        self.chars_arr[word['word']['str_id']] = word

    def to_chars(self, inp):
        """
        Return a charset array.
        Arrays may be concatenated multiple times as arguments to this function.
        Arrays with same key must be the same array.
        Arrays with same string_id must be the same array.
        Return charset arrays like:
            ['\t',0x2],
            ['a',0]
            ['.', 0],
            ['a',0.2]
        """
        if len(self.chars_arr)!= len(self.max_num_of_words):
            return self.max_num_of_words, None
        if len(self.chars_arr) == self.max_num_of_words:
            return self.chars_arr[self.to_chars], self.chars_arr
        else:
            return self.to_chars(