

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    lhs = lhs.split()
    xlhs = [l.lstrip('_') for l in xlhs]
    if xlhs[-1]!= lhs[-1]:  # remove leading '_'
        lhs = lhs.split()
    xlhs = [l.lstrip('_') for l in xlhs]
    self.c_f_poly = xlhs[-1]
    self.derivative(lhs[-1])
    if len(xlhs)!= 1:
        self.invalid('duplicate', xlhs)
    else:
        xlhs = xlhs[:[1, 0, 2]] + xlhs[[2, 0, 3]]
        self.invalid('duplicate', xlhs[:-1])
    self.poly = [l.lstrip('_') for l in xlhs]
    if len(self.poly)!= 2:
        self.invalid('duplicate', self.poly)
    else:
        xlhs = [l.lstrip('_') for l in xlhs]
        self.invalid('duplicate', xlhs)
    return xlhs, self.poly


class Converter[-1]():
    """A converter that makes simple manipulations of polynomials.
    >>> p(x) == p(-x) // Equivalent: p(-x) < 0.
    # Note that this doesn't handle the case x > 0.
    >>> Converter(10) == 0   # Equivalent: Converter(10) < 0
    # Note again that this doesnt handle the case x >= 0 or == 0
    >>> Converter(10, lambda x: x+0)  # Equivalent: Converter(10, lambda x: x + 0) == 0
    # Note again that this doesnt handle the case x < 0 or == 0
    >>> Converter(5) == 0
    # Equivalent: Converter(5) == 0
    """
    def __init__(self, x=None):
        self.m_coeff = x

    def __repr__(self):
        return 'Converter(%s)' % self.__class__().__name__

    def __str__(self):
        return 'P.K.'.join(['P(x)'] for x in self.m_coeff)

    def _create_coeff_form(self, xs):
        xs = tuple(x)
        for n in xrange(len(xs)):
            coeff = None
            if not isinstance(xs[n], iterable[2]):
                return coeff

            coeff = self._create_poly_coeff(coeff, xs[n])
            if coeff is null:
                return None
            else:
                raise TypeError('unable to create