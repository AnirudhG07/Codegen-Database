from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    result = ''
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            if a[i] == b[j] or a[i] == '0' or b[j] == '0':
                result = '%010d' % (i-1, j)
                break
    return ''.join(result)


