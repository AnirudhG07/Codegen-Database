
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    # These two are only needed since for some keywords there is no prefix
    # cyc.pattern_to_words should return the correct result except for cycword that is a word before the prefix itself
    try:
        cyc.pattern_to_words(1)
        return True

    except UnicodeError:
        return False

#cyc.pattern_to_words(nword)

A:

In Python 2, you might be able using a builtin function:
import sys

