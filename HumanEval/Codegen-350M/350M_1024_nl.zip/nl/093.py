
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    encoded = (s.replace(s) for s in message)
    message = encoded.upper()
    encoded = s + '<![CDATASET[^;]*>' + encoded.replace('[^;]*', '<' + encoded)
    encoded = encoded.upper()
    return encoded
           
The following example will take a word such as 'test'. Now I want to change the encoding such that it will only take the first 'T' and not the second 'F'] and the last 'M.'. How can I do this? Thank you.
>>> 

A:

Your question is:
How to write a function that takes a word and encodes the first n/2 / first letter and  second letter in a word?
Well, I am guessing you didn't try it out yet.
The answer is this one:
>>> x = "TEST"
>>> y = encode(x)
(TEST,TEST,TEST,TEST,TEST)

>>> y.join(',').lower()
TEST

Hope that will help.

