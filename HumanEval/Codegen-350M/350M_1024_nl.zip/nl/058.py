

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    for v in l1:
        for i, j in enumerate(l2)
            if (i!= j) or
                not common(v, l2[i])
        return v


class Sequence(object):

    def __init__(self, n: int):
        self.n = n

    def __len__(self):
        return len(self.n)

    def __rmule__(self, x, y, z):
        if not x:
            return None

        n = sum(x)
        n += z + (n - z) * (x + y)
        return p[x:y] = (x, y, z)
    @property
    def sum_seq(self):
        return sum(self.n)


class SortedSequence(object):

    def __init__(self):
        self.index1 = range(None)
        self.index2 = range(1, None)

    def sseq(self, x):
        while x < self.index1:
            self.index2[x] = self.index1[x-1] == x
            #   1:

        x1 = x - self.index1
        del self.index1
        x2 = x + self.index2[x-1]
        while x2 > x and x1 < self.index2[x1]:
            del self.index2[x1]
            x2 = x-1
        return x1, x2

    @staticmethod
    def count_seq(n):
        if n < 1:
            return n
        return len(n) - 1 + count_seq(1)

    @staticmethod
    def sseq_count(n):
        if n < 1:
            return n
        return count_seq(n - 1)

    @classmethod
    def fromstring(cls, s):
        # type: () -> list
        s.n *= int(cls(s).sum_seq())


class SortableList([Sequence]:
    def __init__(self, n: int)
        self.n = n

    def __len__(self):
        return len(self.n)

    def __rmule__(self, x, y):
        if x!= y or
            x > self.n or
            y > max_int(self.n + 2) or
            (x < self.n or x < self.n + 2) or
            (y >