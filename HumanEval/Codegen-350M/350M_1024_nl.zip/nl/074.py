
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''
    return [strx(lst1), strx(lst2)]

    def main():
        lst = ['hi', 'admin', 'project']
        total_match(lst, lst);
        print(total_match([], []));
        print (total_match([], lst));

        len = len(lst)[0]
        print (len);
        for i in range(len):
            print (total_match([i+1], []));

        for item in lst:
            print (item);

if __name__ == "__main__":
    main()

A:

You can convert your example to O(l). The number you return is not the number of elements, that is it's an array and therefor the number of elements will be O(n).
If you want the number of elements in the result, you will need to have a hash table (which will take O(log n) time). In fact, a dictionary will take O(log n**2).
If you have some sort of lookup, which takes time, then you'll need some sort of index or hash table to retrieve the matching elements.
(For a hash table, see this StackOverflow answer: Using O(log n**2) where n is the size of the array)

