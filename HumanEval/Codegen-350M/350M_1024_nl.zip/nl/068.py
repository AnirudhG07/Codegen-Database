
def pluck(arr):
    """
    "Given an array representing a branch of a tree that has non-negative integer nodes
    your task is to pluck one of the nodes and return it.
    The plucked node should be the node with the smallest even value.
    If multiple nodes with the same smallest even value are found return the node that has smallest index.

    The plucked node should be returned in a list, [ smalest_value, its index ],
    If there are no even values or the given array is empty, return [].

    Example 1:
        Input: [4,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index.

    Example 2:
        Input: [1,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index. 

    Example 3:
        Input: []
        Output: []
    
    Example 4:
        Input: [5, 0, 3, 0, 4, 2]
        Output: [0, 1]
        Explanation: 0 is the smallest value, but  there are two zeros,
                     so we will choose the first zero, which has the smallest index.

    Constraints:
        * 1 <= nodes.length <= 10000
        * 0 <= node.value
    """
    if len(arr) <= 0:
        raise ValueError("given an array with no more than 10000 nodes you have no branches of the tree.")

    # for each node in arr[0..-1]

    # keep track of the min value
    min = min(arr)

    # find the index of the nearest to minimum index
    leftmost = 0
    rightmost = min -- arr.shift()

    # find the index of the next to leftmost, if one exists
    min_next = min + 1

    while arr.is_empty():    
        # if there is no nodes, return the closest one
        if leftmost <= min:
            # continue on
            min = min - 1
        leftmost = min + 1

    # if no nodes found, return zero if there was a new node
    else:
        index = leftmost - node.size()
        if index < 0:
            # you have 0 children, return the index of the smallest node in the loop
            if leftmost >= node.size(): index = 0 - node.size()
        # search leftmost first in the index for the smallest index
        leftmost = min_next + 1
        if index <  0:
            # the index has to be larger than the smallest index or it isn't found
            // you have one child
            return 0 - node.size()
        else:
            # if the index is zero, then this is the next node
            # return the index of the next smallest index (or zero)
            return index

And if there are no more than 10000 nodes found, you can skip the plucking phase.

