
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    if isinstance(arr, (numbers.NumericType)):
        # 1, 2, 3, etc are already integers
        return nums - 1
    else:
        # If a number has no digits, then return -1.
        return -1


@functools.wraparound
class Count:
    """
    This class counts the number of digits in an input string.
    >>> count_nums(u'a') == 1
    >>> count_nums([2, -10, 13, -2, 9, 4, 6, -4, 13, 10]) == 4

    The count has the following parameters:
    0   - A string can be any number of characters.
    1   - The input string can be in binary, or in decimal.
    2   - The number of digits that the number should contain.
    3   - A number in upper- and lower-case.
    4   - A special flag: if not found, then it defaults to -1.
    """
    def __call__(self, str=None):
        if isinstance(str, numbers.Numbers):
            if str.is_number(False):
                return Count([len(str), str.digits[0]])
            elif str.is_string(True):
                return Count([len(str), -1])
            elif not isinstance(str, string):
                # A number doesn't have digits at all when it's not a string
                return Count([1])
            elif str.is_digit(1):
                return Count([str.digits[0]])
            else:
                # A number (in upper- and lower-case) is either a string or a
                # number of digits greater than 0 (which makes the first two
                # optional to take care of digits after the last, which will
                # be the number of digits the number has but which will need
                # to take up no space to fit into it, because, say, a number could
                # have less than 256 digits but end with an N) in the first
                # case where the number consists of two digits).
                # In some cases, such as when an int is passed to counts(),
                # we don't know if such a number is a string or integer up- or
                # down-cast:
                # if not a string, and it