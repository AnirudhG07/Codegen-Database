
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    arr = np.array(arr)
    sum_neg = 1
    for i in range(len(arr)):
        ret = 0
        neg = -1
        for j in range(len(arr)):
            jj = arr[:, i] * 0.8 + arr[:, i + 1:] * neg
            ret += jj
            sum_neg += 1
    return res.ravel.sum(sum_neg)


