
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    return "" if has_vowel in s else ""


class LexicalAnalyzer(astropy.core.matcher.Language):
    """
    Base class to perform basic lexical rules for a given language.
    """

    def __init__(self, context):
        self.lit(context.syntax.syntactic_rules, default=F)

    def get(self, s):
        """
        Return a token class instance for s, which will be treated as
        a token during next computation when it is to be matched against
        another token class like token class.
        """
        return s

    def get_token(self, s):
        return s.tokenize(self)


class StringAnalyzer(LexicalAnalyzer, Astropy.Function):
    """Base class to perform complex string analysis.

    This analyzes a string of words and returns a token based on the
    tokens of those words.
    """
    def __init__(self, language, ngrams, **kwargs):
        super(StringAnalyzer, self).__init__(**kwargs)

        self.language = language

        self.syntax = astropy.core.grammar.Grammar(language)
        self.syntax.locals["elementsOfExpression"] = tokenize(self.syntax)

        self.parse_grammar()


class RegularExpressionLexer(LexicalAnalyzer):
    """This Lexer will find and return regular expressions as they are
    encountered in Regular Expressions files.

    >>> regex = RegularExpressionLexer()
    >>> re = regex.regexp()
    >>> re.find()
    >>> re.find_match("test")

    """
    def __init__(self, language=None, options=None, **kwargs):
        super(RegularExpressionLexer, self).__init__(**kwargs)

        self.options = options and options or {}
        self.options[options.INDENT] = False

        keyword_class_name = '__name__'
        keyword_class = keyword_class_name(kwargs)
        if keyword_class not in self.options.get(keyword_class, None):
            pass
        self.options.set(keyword_class, keyword_class)

        self.kwd_class = keyword_class

    def regexp(self):
        """Add regexp method to this Lexer.

        Regexp for the text at the currently specified spot.
        Also checks the number of spaces, e.g. the current location."""
        if self.options.indent and len(self.options.indent) % 2 == 0:
            self.options.indent += space
        return re_compile(self.options)

    def