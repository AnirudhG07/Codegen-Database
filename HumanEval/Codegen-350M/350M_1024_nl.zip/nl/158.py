
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    """
    len = len(words)
    # Check if max character was found
    if len is None:
        print "Length"
        return words[len-1]
    if len > MAXCHERS:
        return ""
    # Check if max unique characters were found
    if len > len(words):
        print "No longer found"
        return words[len-1]   # Not found, no more max characters
    # Check if max found words
    if len is None:
        return len
    # check if first char of found words is max unique characters
    for i in words:
        if i[0] > 0 and i[0] < MAXCHERS:
            return i                          # Found
        # Check if first char of found words is max unique characters
        for j in i:
            if i[1] as i[0] <= j[0] and j[1] as i[0] > MAXCHERS:
                return i                      # Found
        return i                              # Not found
    print "'" in words
    return ''

max_characters = {'a': "a", '\xef': "f", 'g': "G", 'h': "H", 'i': "I"}

a = input("Please enter a word: ")
b = input("Please enter a character: ")
length(a)
print find_max(a)[len(a)-1]
print find_max(b)[len(b)-1]

#print find_max(find_max(a) + find_max(b))
print "found: " + find_max(find_max(a)+find_max(b))

A:

The problem with your code is caused by the list of strings starting from '"' instead of "". Using input.lstrip(), your code will correctly put the final string in it's place.

