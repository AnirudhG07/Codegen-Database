

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    x=sqrt((a-h)/2)
    y=sqrt((a+h)/2)
    z=0
    m=0
    for i in range(0,4):
    for j in range(0,3):
        for k in range(0,3):
            for l in range(0,3):
                n=sqrt((a-(m*m)+l*l)+(a+y*y)+j*j)
                z=(a-(m*m)+l*l)+(a+y*y)*(n/2)+uj;
        if j%2 == 0 and z<0:
            m+=z-l/(k+u)*m*l/2
        y+=m/2
    return x*y

