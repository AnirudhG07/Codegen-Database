
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    return is_equal_to_sum_even(int(n))

from itertools import islice
assert islice(iterlist,
    numpy.sum(islice(iterlist, x_axis))) == numpy.sum(islice(iterlist, x_axis, axes))

x_axis = None
iterlist = iter(islice(iterlist, y_axis))
assert islice(iterlist,
    numpy.sum(islice(iterlist, x_axis))) == numpy.sum(islice(iterlist, x_axis, axes))


@pytest.mark.parametrize("n,axis",
[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17])
@pytest.mark.parametrize("list, axis",
[islice(numpy.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]), axes=numpy.arange(14),
        num_axes=numpy.arange(5))])
@pytest.mark.parametrize("sum, axis", [islice(numpy.array([4,6,8,10,12,14,17]), axis=axis,
        num_axes=numpy.arange(8))])
@pytest.mark.parametrize("values, axis",
[islice(numpy.array([2,3,4,5,6,7,8,9,10,12,13,14,15,16,17]), axes=numpy.arange(10),
        values=np.array([])])
@pytest.mark.parametrize("pos_x, axis, ax",
[islice(numpy.array([1,2,3,4,5,6,7,8,9,10,12,x,x+1,y,y+1,x+1,x+2,y+2,y+3,y+4/x,
        x+4,x+5,y+6,y+7,y+8,y+9,x+x+1,x+x+2,y+3,y+4,x+5,x+3,x+x+4/x])),
    axes=numpy.arange(6)
])
@pytest.mark.parametrize("sum, axis, ax",
[islice(
    numpy.array([1,2,3,4,5,6,7,8,9,10,12,x,x+1,y,y+1,x+1,x+2,y+1,y+2,y+3/x,
        x+4,x+5,y+6,y+7,y+8,y+9,x+x+1,x+x+2,y+4,y+3,y+2,y+2,y+3,y+4/x
)
)]
@pytest.mark.parametrize("values, axis, axis",
[islice(numpy.array([1,2,3,5,4,6,7,8,0,12,3,4,13,15,16,17]))])
@pytest.mark.parametrize("pos_x, axis, ax",
[islice(numpy.array([1,2,3,4,4,5,5,5,5,5,12,10,5,6,15,17]))])
@pytest.mark.parametrize("sum, axis, ax",
[islice(
   