from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    def remove_duplicates_equal(numbers: List[int], duplicates: List[int]) -> bool:
        try:
            # no dupes are allowed here
            for number in numbers:
                remaining_dupes = list(range(numbers[number]))
                duplicates.extend(others)
                for duplicate in other_duplicates:
                    # do not remove duplicate elements except those with the same duplicates...
                    if duplicates[number-1] == duplicates[number]:
                        remaining_duplicates[number-1] = 1  # remove duplicate
                        del duplicates[number]
            return remaining_dupes[-1]
    return remove_duplicates_equal


@property
