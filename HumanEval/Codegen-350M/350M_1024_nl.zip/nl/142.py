


def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """
    L0, L1, L2, L3 = [12,13,14,15,32,12,34]
    S0, S1, S2, S3 = []                                           # index list (a.k.a. indices of lst)
    for i in range(0, lst[-1]):
        S0 = 0                                                   # for i=0..-1, we have a sum of the squares of all lst entries
        for j in range(2):
            S1 = S0 + S0 * S0 * S0 * S0
        S2 = S0 + S0 * S1 * S1 * S1 * S1
        S3 = S1 + S1 * S1 * S1 * S1 * S1
    L = []                                                        # index list for the remainder of the algorithm
    # calculate sum squares of lst entries where the index of the sum is a multiple of 3 or 4
    # multiply by a constant and sum the results
    for i in range(0, lst):                                       # for i=0..-1, we have a sum of the squares of all lst entries
        if islice(i, L0): S0 = S0 * 2                            # for i=0..-1, we have all the entries in L0
        else:                                                    # get the rest of lst entries
            S0 = Math.exp(sum(L0**i, 0)**2)                      # multiply the sum by the first number in L0 and sum the result
            S1 = sum(L0**2**i, 0)                                # multiply the sum by the second number in L0 and sum the result
            S2 = sum(L0**3**2**i, 0)                             # multiply the sum by the third number in L