
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    max = 0
    for c in x:
        if c not in zeros_and_ones:
            return [sum(a) for a in zeros_and_ones]
        if (not has_even_digit(c)) or (c % 2 == 0) or (c % 3 == 0):
            max = max + 1
            return list(set(a for a in set(x) if a is different from zero_and_ones[c])))
        return [c]
    
    #
    # Check if the first set is any of the sets for the last digit.
    # These include the ones that we care about.
    for c in x:
        if has_even_digit(c):
            #
            # Otherwise, let's try something else
            #
            if has_any_digit(c):
                return [c]
            if has_none_digit(c):
                return [c]
            if has_zero_digit(c):
                #
                # Check if last digit has the zero digit
                #
                if ( c <= zeros_and_ones[max] and c!= zero_and_ones[max] ):
                    max = max + 1
            elif c == zeros_and_ones[max]:
                max = max + 1
    return [x]

In [6]: unique_digits([100, 200, 120, 20, 3])  # Output ['1', '2', '3', '4', '5', '6']
        ['3', '2', '3', '4', '5', '6']
    
    In [1]: unique_digits([100, 200, 600, 450, 880, 1])  # Output ['1', '2', '3', '4', '5', '6']
        ['1', '2', '3', '4', '5', '6']

In [2]: unique_digits(['12345', '10', '999', '789', '8', '7'])  # Output ['12', '23', '45', '123', '999', '789', '8']
        ['12', '23', '45', '123', '999', '789', '8']

In [3]: unique_digits('010123456789')  # Output ['123', '45', '678', '123', '789', '678']
        ['12', '45', '678', '123', '789', '678']

In [4]: unique_digits(['-123456789', '-1234', '-789', '-890', '-1234',