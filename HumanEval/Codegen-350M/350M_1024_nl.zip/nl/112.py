
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    ret, ch = re.findall(reverse_delete, s)
    if not ret and not ch == c:
        pass
    else:
        ret = (ret == ch) and (ch in s)
    return ret

What is the purpose of this logic and how it is optimized. There are several techniques to store the results but I just need the one and only way 

A:

This function will go through both characters of the given string to determine their value, and if it is empty, it returns None. (See the docs for the function.)
This is actually really simple (and uses a lot less resources as far as I'm concerned).

