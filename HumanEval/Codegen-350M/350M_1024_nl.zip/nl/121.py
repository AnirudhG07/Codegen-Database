
def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """
    for x in lst:
        if x not in int(x, 2):
            return 5
    return solution_even(lst)

I want to get the method solution as a class method to be used as part of a generator and also as a super class method so that I can add methods to a solution and use them in another problem class.
So I tried adding a class solution with def solution(lst): and then in my generate method I tried something like this:
x = x + lst[0:2]

But this gives:
/usr/lib/python3.4/dist-packages/distribute.py", line 21, in distribute
raise DistutilsErrnoException('non-existent package:'+ str(e))
distutils.errors.DistutilsError: command 'x+1' failed with exit status 1

I know that I can add a __new__ method to my solutions class, and I can add one to my generate method and use that in another class, but I'm just unsure how this works. I'm guessing that I'm not understanding the method as well as the class and it's syntax.
Is it going to allow me to do this with methods, or should I just define an extend of solution in another class and have the super class class be the method?

A:

As you can see in your code you have to explicitly make solution() a subclass rather than an inheritance.
solution = solution()

solution_solution = solution()

class solution_solution:
    def __new__(cls, num_classes):
        return super(solution_solution, cls).__new__(cls, num_classes)
    def __init__(self, x=0):
        self.n_classes = cls(3)
        self.n_entries = 0
    def __eq__(self, other):
        for i in range(other.n_entries):
            if i%2 == 0:
                return 0
        return 1
    def __hash__(self):
        return hash(self.n_classes)
    @classmethod
    def load(cls, method):
        if "n_classes" in cls.__dict__.items():
            for i in method("n_classes").split(","):
                n_classes = int(i)
        elif "n_entries" in cls.__dict__.items():
            for i in cls.__dict__["n_classes"]():
                ent = i%2
                if ent == 2:
                    yield ent
    def __str__(self):
        return self.n_classes + " " + str(self.n_entries)
    def __repr__(self):
        return "solution (" + str(self.n_classes) + " entries, " + str(self.n_entries) + " classes)";

