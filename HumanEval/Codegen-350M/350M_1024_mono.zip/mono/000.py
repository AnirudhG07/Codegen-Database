from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if not numbers or len(numbers[0])!= 2:
        return False

    return abs(numbers[0][0] - numbers[1][0]) > threshold
    
# @lc app=leetcode id=1665 lang=python3
#
# [1665] Find the Max Closer Element to Hit
#
# https://leetcode.com/problems/find-the-max-closer-element-to-hit/description/
#
# algorithms
# Medium (43.25%)
# Likes:    22
# Dislikes: 133
# Total Accepted:    44.6K
# Total Submissions: 55.6K
# Testcase Example:  '[1,2,3,1]\n2'
#
# Given two integer arrays nums1 and nums2, return the maximum element in the first array
# that is strictly greater than the minimum in the second array. The two arrays will have
# length at least 2.
#
# It is guaranteed that for every element in nums1, i!= nums2, and nums1[i] > nums2[i].
#
#
# Example 1:
#
#
# Input: nums1 = [1,2,3,1], nums2 = [2,3,1,2]
# Output: 2
# Explanation: The maximum element that is strictly greater than the minimum element is
# 2.
#
#
# Example 2:
#
#
# Input: nums1 = [0,0,0,1,1,1,2,2,3,3,4], nums2 = [2,3,1,2,3,1,2,3,1,2,4,5]
# Output: 2
# Explanation: The minimum element that is strictly less than the maximum element is 2.
#
#
# Example 3:
#
#
# Input: nums1 = [1], nums2 = [6]
# Output: 1
#
#
# Example 4:
#
#
# Input: nums1 = [1,1], nums2 = [1,3,4]
# Output: 3
#
#
#
# Constraints:
#
#
# 1 <= nums1.length, nums2.length <= 1000
# -109 <= nums1[i], nums2[j] <= 109
#
#
#

# @lc tags=array

# @lc imports=start
from imports import *

# @lc imports=end

# @lc idea=start
#
# This is one of the questions of the problem set. At each step there are 2
# possibilities:
#
# 1. If the two numbers are sorted in decreasing order, then the element
#  with the smallest value is the closer to the minimum number, which is
#  the result of nums1[i].
# 2. If the elements are sorted in increasing order, then the elements in
#  nums1 are all sorted. Only the second option will be correct
#
#
# @lc idea=end

# @lc group=

# @lc rank=


# @lc code=start
class Solution:
    def findTheMaxCloser(self, nums1: List[int], nums2: List[int]) -> int:
        """
        @override
        Problem:
        In brute force, we need to find the closest in the numbers that are a pair of elements
        In search of these two elements we find the first closest number and choose the first element
        and the second closest to this element
        """
        l1 = []
        l2 = []
        for i in range(len(nums1)):
            for j in range(i + 1, len(nums1)):
                if has_close_elements(nums1[i