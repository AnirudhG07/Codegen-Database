
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    zero_values = sum(map(lambda i: 1 if len(bin(i)[2:]) == 4 else 0, arr))
    zero_values += sum(map(lambda i: len(bin(i))[2:] == 4 and len(bin(i)[2:]) in [4, 5], arr))

    def sort(x, y):
        if zero_values == 0:
            return x < y
        else:
            return x < y and  y < x, x > y or x > y

    return [sort(x, y) for x, y in zip(arr, arr[1:])]
