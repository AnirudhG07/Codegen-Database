
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    if s=='#':
        return s.lower()
    if s.isalpha():
        return s.upper()
    return s.lower() 

print solve(s[::-1])


"""
s = "abCb"
    if not s:
        return
    if len(s)==1:
        return s
    elif s[0]=="#":
        return solve(s[1:]).upper()
    elif s[0].isupper():                       #if s[0].islower:
        return solve(s[1:]).lower()           #return the lower case
    else:
        return solve(s[1:])                    #return the upper case
print solve(s[::-1])
"""
