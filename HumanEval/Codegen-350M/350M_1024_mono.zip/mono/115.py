
def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """
    # Time complexity: O(N*K)
    # Space complexity: O(1)
    # Space complexity: O(K+1)
    
    n = len(grid)
    bucket_capacity = 2 ** math.ceil(math.log2(n))
    if bucket_capacity < 5 or bucket_capacity > n: return 0
    
    water, bottles = sum(grid[i][1:] for i in range(n)), {}
    buckets = [0] * (bucket_capacity + 1)
    
    def insert(bucket_id):
        if bucket_id > 0:
            buckets[bucket_id] += 1
            buckets[bucket_id - 1] -= 1
            
            result = buckets[bucket_id - 1]
            
            if result == 0:
                buckets[bucket_id] = 0
                buckets[bucket_id - 1] = 0
            
            else:
                result -= 1
        else:
            result = 0
        
        if water >= result:
            return result
        
        else:
            return water - result
    
    for bucket_id in range(n):
        water += insert(bucket_id)
        for water in range(2):
            for bck_id in range(bucket_capacity):
                next_val = insert(bck_id) + insert(bck_id - 1) - water
                if next_val:
                    if next_val not in bottles:
                        bottles[next_val] = [bucket_id]
                    else:
                        bottles[next_val].append(bucket_id)
            
    for val in bottles.values():
        val[-1] += 1
            
    return sum(val[1:])
