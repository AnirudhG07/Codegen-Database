from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o|.| o| o|.|.|.|.| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    beat_counter = 0
    beat_string = ""
    # "." is not a note as in original music notation.
    # So we just need to count "o"
    for i in range(0, len(music_string)):
        if music_string[i] == "." or music_string[i] == 'o':
            beat_counter += 1
            if beat_counter > 5:
                beat_counter = beat_counter - 6
            if beat_counter == 0:
                return [0, 0, 0, 0]
            beat_string += music_string[i:i + 6]
    # add all notes starting with this one for every beat.
    note_array = [0] * beat_counter
    for beat in range(0, beat_counter):
        counter = 0
        beat_string += str(note_array[counter])
        while beat_string[-3] == "o":
            return [1, 1, 1, 1]
        # get the next letter
        i += 1
        beat_string = beat_string[i:]
        # check if one char is new note
        if note_array[counter] < 10:
            note_array[counter] += 1
