
def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1, 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """
    if len(arr) == 0: 
        return []
    
    output = []
    for i in range(len(arr)):
        output.append(str(arr[i]) + '-' + str(len(str(arr[i])))[::-1])

    output = sorted(output, key=lambda x:int(int(x) % 10))
    return output

# def by_length(arr): 
#     """
#     Given an array of integers, sort the integers that are between 0 and 9 inclusive.
#     Replace each digit in the array with its corresponding name.

#     For example:
#     arr = [1, 2, 3, 3, 4]
#               -> sort arr -> [1, 2, 3, 'Three', 'Three', 3, 2, 2, 1]
#     return ['Three', 'Four', 'Four', 'Three', 'Two', 'Two', 'One', 'One']

#     If the array has any strange number ignore it:
#     arr = [1, -1, 6, 2, 3, -1, 13, 2, 3, -1]
#           -> sort arr -> [1, -1, 6, 2, 3, 13, 2, 3, -1]
#           -> reverse arr -> [6, 3, 2, 3, 2, 1, 'Three', 'Three', 13, 2, 2, 3]
#     return = ['One']
#     """
#     if len(arr) <= 1: 
#         return arr 

#     output = []
#     for i in range(len(arr)): 
#         output.append(str(arr[i]) + '-' + str(len(str(arr[i])))[::-1])

#     output = sorted(output, key=lambda x: int(int(x) % 10))

#     for i in range(len(arr)):
#         arr[i] = arr[i] * -1

#     return output


