
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    circular_shift = 0
    if shift > len(str(x)):
        print("Sorry, the shift is too big. Please reset and try again.")
        exit()
    while True:
        circular_shift += 1
        x = (x+shift) % 10**len(str(x))
        if str(x) == str(x)[::-1]:
            break
        elif circular_shift == shift:
            print("The given number:", x, "doesn't represent ten on its left digit. Restart?")
            #input("Hit enter to continue.")
        else:
            print("The given number:", x, "does not represent ten on its right digit.")
    if circular_shift%2==0:
        return str(x)[::-1]
    else:
        return str(x)[::]