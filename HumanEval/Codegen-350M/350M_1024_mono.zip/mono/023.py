

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    n = len(string)
    if 1 < n < 2:
      return 0
    return n

