
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    l = []
    even_digits = []
    if b > a:
        while a > 0:
            if a %2==0:
                first_number = a
                a %=2
            else:
                first_number = b
                b %= 2
    
    if (a+b)==8:
        if a > 8:
            break
        while a % 10==6:
            a /=10

        if a*10+b <= 8:
            while a % 10!=6:
                l.append(a%10)
                a /=10
                if a == 6 and a%10!=6:
                    break
    
    else:
        while a%10!=1:
            first_number = a%10
            a = a%10
            while b!= first_number and a%10!=1:
                l.append(a%10)
                a = a%10
                b = (b*10+b)//10

    while first_number!=1:
        l.append(first_number)
        l.append(first_number)
        for i in l:
            even_digits.append(i)
        
        first_number = (first_number*2)//10
        if a%10!=1 or a<=8:
            a = a%10
            
                
    return even_digits