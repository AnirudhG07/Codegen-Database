

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    cntr: int
    div: int
    while n >= n % 11:
        cntr += 1
    div: int = int(n/11)
    if len(str(div)) == 1:
        div = 0
    return cntr, div

