
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    # create a variable that stores the current string
    current_sum = 0
    # for loop over the string
    for char in s:
        # if the current character is an lower case letter, add it to the current
        # value of the current_sum
        if char.islower():
            current_sum += ord(char)-ord('a')
    # return the current_sum back to it now
    return current_sum
 
