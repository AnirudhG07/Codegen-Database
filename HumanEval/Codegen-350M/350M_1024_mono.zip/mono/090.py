
def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    # Your code here

class Solution:
    def nextLargest(self, nums: List[int]) -> int:
        heap = [-nums[0]]
        for n in nums[1:]:
            heappush(heap,-n)

        while nums:
            if -heap[0]==-heap[-1]:
                heappush(heap,-heap.pop())
            else:
                break
        return heap.pop()

#runtime of 44.26%
#memory usage of 12.07 MB at 20 minutes 10+ seconds