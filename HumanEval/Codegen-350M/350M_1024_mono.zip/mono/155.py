
def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    count = [0, 0]
    for i in str(num):
        if i == '0':
            count[0] += 1
        elif i == '1':
            count[1] += 1
    for i in range(2, count[0]+2, 2):
        for j in range(0, count[1]-i, 2):
            count[0] += count[1-i]
    return count


