

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    # Sort it
    l.sort()

    # We want to be able to use the last element of the sorted
    # list and have each successive element in the same position as it
    # preceding it
    target: int = l[-1]
    for index in range(len(l)-1, -1, -1):
        if l[index] <= target:
            return True
        if l[index] > target:
            return False
    return True

