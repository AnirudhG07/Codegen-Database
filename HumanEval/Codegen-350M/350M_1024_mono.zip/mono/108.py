
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    arr.sort()
    sum_val = 0
    for num in arr:
        sum_val += num
        if sum_val > 0:
            first_digit = sum_val % 10
            sum_val //= 10
        else:
            first_digit = 0
    return arr.count(first_digit)


# driver
if __name__ == '__main__':
    arr = [
          -11, 7, -11, 0, 0, -7, -2, -7
        ,-7, 0, 0, -7, 0
        ]
    print(count_nums(arr))