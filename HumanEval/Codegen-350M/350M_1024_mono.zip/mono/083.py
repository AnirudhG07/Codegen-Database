
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    def dfs(start, end, count):
        if start == end:
            count += 1
        for num in s[start:end]:
            count = dfs(start+1, end+1, count)
        return count

    return dfs(0, n, 1)

print(starts_one_ends(999)) # should be 867
print(starts_one_ends(1001)) # should be 867