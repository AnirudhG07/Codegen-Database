

def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    # O(x^4) in worst case as you compute the fib4(x) for x = 2 and the factorial of 2
    # O(n) in case of n <= 15
    # In a case of n being extremely large, a looping approach has shown to cause O(n^n) runtime.
    # In the above loop it's not very necessary to write O(n^2) as just n is given, because the fib4 function starts at
    # 0 and goes through the numbers in the sequence, which would make it even quicker to compute O(log n) if we have a big
    # array of n^2 numbers, that would be better.
    if n == 1:
        return 0
    elif n == 2:
        return 1
    elif n < 2:
        return n
    else:
        return fib4(n//2)+fib4(n//2)

# Test
# print(fib4(100))

############################################################

# Implement the fibbonaci series, where the sequence starts from 0 and iterates backwards, counting

