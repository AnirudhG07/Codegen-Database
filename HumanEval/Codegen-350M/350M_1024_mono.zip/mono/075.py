
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    sum = 0
    b = a
    #print("The next prime divisor is: ", b, "{}".format(next_prime(a)))
    #print("You have guessed all answers correctly!")
    #print("So do you want to play again?")
    #print("y,n,d or q")
    #check = input()
    while(b!= 100000000):
        #get the next prime divisor
        c = next_prime(b) 
        #print(c)
        if(c >=100000000):
            print("Too high, try again! You won't be able to play this one.")
            c = False
        #If all prime numbers are divisible by the next prime divisor
        #if the current number is not a valid number
        if(isValid(c)):
            sum += c
            #If the next prime should go to its right
            #If it doesn't, skip it
            if(c % b!= 0):
                #print(c)
                b *= b
            #Else skip it
            else:
                b *= b
            #check = input("Play another? y,n,d or q")
            #if check == "q":
            #    quit()

    #Display the result
    #print("The result will be correct:", sum)
    return sum, c
    

#Write a function to get and return the sum of all positive numbers below 100. 
