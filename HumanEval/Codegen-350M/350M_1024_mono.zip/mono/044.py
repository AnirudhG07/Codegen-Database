

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    new = x // base
    result = x % base
    print(f'result after change {x} to {result}')
    return f'{result}{change_base(new, base)}'


# def convert_to_chars(s: str) -> str:
#     """Convert string s to a space separated string of
#     converted character.
#     >>> convert_to_chars("hahahaaaaaaa")
#     '4a2'
#     >>> convert_to_chars('hahahaaaaaaa')
#     '4a2'
#     """
#     result = ''
#     for c in s:
#         if c!='':
#             result += c
#         else:
#             result +=''
#     return result


if __name__ == '__main__':
    import doctest

    if doctest.testmod().failed == 0:
        print('\n*** ALL TESTS PASS. YOU HAVE ENOUGH TIME!! ***\n')
