

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n <= 1 :
        return 0
    if n <= 2 : return 1
    else:
        return fibfib(n-1) + fibfib(n-2);


# Example usage

print('\n'.center(105, '-') +'Example usage'.center(105, '-'))
fibf = lambda _: fibfib(int(_))


if __name__ == '__main__':
    if len(sys.argv) == 2:
        n = sys.argv[1]
        if n.isdigit() == True:
            if int(n) <= 0:
                print('Error!')
            else:
                print(fibf(int(n)))
        else:
            print('Invalid argument!')
    elif len(sys.argv) == 1:
        print('Example usage'.center(105, '-'))
        print('Python fibfib takes in an integer n which is the length of the FibFib number sequence '
                      'which has to be computed')
        print('Arguments : ', '0'*(80-len('Example usage'.center(105, '-'))))
        print(fibf(int(input())))
    else:
        assert False
