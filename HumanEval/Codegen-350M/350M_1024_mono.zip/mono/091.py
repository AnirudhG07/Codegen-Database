
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    num_boredoms = {word: 0 for word in S}
    count = 0
    for letter in S:
        if letter == "?":
            count += 1
        elif letter == "!":
            num_boredoms[letter] = num_boredoms[letter] + 1
        else:
            count += 0

    for word in S:
        if word in num_boredoms:
            num_boredoms[word] = num_boredoms[word] + 1

    for word in num_boredoms:
        count += num_boredoms[word] - 1
    return count