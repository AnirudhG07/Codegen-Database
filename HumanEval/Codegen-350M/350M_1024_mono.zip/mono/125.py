
def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1,... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
    if txt=="":
        return []
    word=txt[0].lower().split()
    word1=split_words(txt[1:])
    if len(word)==len(word1):
        if sum(word.count(elem) % 2 for elem in range(len(elem)))==1:
            return word+word1+word1
        return word
    return word
split_words("Abc,cde,fgh,ijj") ➞ [1, "a", "b", "c"]


