
def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """
    if n > m:
        return '-1'
    if abs(n) % (1 + m)!= 0:
        return '-1'
    if n >= m:
        return(str(int(round(n / (1+m)))))

# @lc code=end

# @lc main=start
if __name__ == '__main__':
    print('Example 1:')
    print('Input : ')
    print('n = 7, m = 6')
    print('Exception :')
    print('0b1100')
    print('Output :')
    print(str(int(rounded_avg(7, 6))))
    print()

    print('Example 2:')
    print('Input : ')
    print('abs(n) = 6')
    print('Exception :')
    print('-1')
    print('Output :')
    print(str(abs(int(str(rounded_avg(6, 6))))))
    print()

    pass
# @lc main=end