

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    try:
        assert 0 <= n <= 8
    except AssertionError:
        raise TypeError("Invalid n, minimum is 0 and maximum is 8.") from None
    if n == 1 or n == 2:
        return n
    if n == 3:
        return 4
    return fib(n - 3) + fib(n - 2) + fib(n - 1)
