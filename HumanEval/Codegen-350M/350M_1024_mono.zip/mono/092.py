
def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''
    x_sum = 0
    for t in range(len(x)):
        x_sum += x[t]
        y_sum = 0
        for o in range(len(y)):
            y_sum += y[o]
            z_sum = 0
            for n in range(len(z)):
                z_sum += z[n]
                
            if x_sum == y_sum == z_sum:
                return True
        else:
            return False
    return None
# @lc idea=end
