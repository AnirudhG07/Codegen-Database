
def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    def compare_vowels(word, s):
  for i in range(len(s)-1):
    if s[i:i+2] in VOWELS:
      l = s[i+1:]
      index_s = s.index(l)
      return s[index_s:i+1]
    if s.count('a') == 4:
      return s[:-1]
print(get_closest_vowel("yoga"))
#Time : 32 ms ± 0.0210 in python3 (+ possible)
#Memory Usage: 27.5 MB ± 17.14 %
