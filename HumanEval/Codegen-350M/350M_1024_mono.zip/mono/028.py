from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    first = ''
    second = ''
    for string in strings:
        first += string + " "
        second += string
    return (first + second).rstrip()

# test methods (don't modify this)

