
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    pass


if __name__ == "__main__":
    # count_invalid_letters()
    # print(find_min_or_max(["word", "of", "word", "words", "of", "word", "is", "an", "error"]))
    # print(find_num_of_unique(["abracadabra", "abracadabraab"]))
    find_max(["name", "of", "string"])
    print(find_max(["aaaaaaa", "bb","cc"]))
    # print(find_min_or_max(["a", "b", "aa", "b", "b", "babaa", "ba", "abbba", "baa"]))
    # print(find_num_of_unique(["a", "b","abc", "cadab", "cba", "cb"]))
    print(find_max(["aaa", "aab", "bb"]))
