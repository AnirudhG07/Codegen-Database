

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    stack = []
    for bracket in brackets:
        if bracket in ["(", "[", "{", ")"]:
            if bracket == "(" and stack: return False 
            else: stack.append(bracket)
        elif bracket == ">":
            stack.pop()
        elif bracket == ">":
            if stack: return False   
    if stack: return False
    else: return True

# @lc code=start
import sys
input = sys.stdin.readline
# @lc code=end
