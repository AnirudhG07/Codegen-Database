from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    # Check if list contains a single element
    if len(numbers) == 1:
        return numbers[0]
    else:
        return sum(numbers) / len(numbers)

# def median_absolute_deviation(numbers: List[float]) -> float:
#     """ For a given list of input numbers, calculate Median Absolute Deviation
#     around the mean of this dataset.
#     Median Absolute Deviation is the mean of the arithmetic averages:
#     Median Absolute Deviation of 1.0, 2.0, 3.0, 4.0
#     :param numbers: the input numbers to calculate Median Absolute Deviation
#     :return float median absolute deviation: the median absolute deviation of
#          this dataset
#     """
#     # Check if list contains a single element
#     if len(numbers) == 1:
#         return numbers[0]
#     else:
#         # Find the middle index of the current list
#         mid_indx = len(numbers) // 2
#         # return first half
#         if mid_indx == 0:
#             return numbers[0]
#         else:
#             # Calculate the arithmetic average for the first half
#             mid_mean = sum(numbers[:mid_indx]) / mid_indx
#             # Calculate the arithmetic average for the second half
#             mid_mean_2 = sum(numbers[mid_indx:]) / (len(numbers) - mid_indx - 1)
#             # Return the median absolute deviation
#             return mid_mean - (mid_mean_2 - mid_mean)
#     pass

