
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    
    result = []
    
    for i in range(len(lst)-1):
        if i % 2 == 0:
            result.append(lst[i])
        else:
            result.append(lst[i+1])
            

    return result





# -------------------------------------------------- DO NOT TOUCH  -------------------------------------------------------





print(add([4, 2 ]))
print(add([  ]  ))
#print(add([  2 ]))

