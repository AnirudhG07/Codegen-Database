from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    # Note that if you use list slicing (like the line below), you will get an exception. Also try to use min() and max()
    smallest = min(numbers)
    biggest = max(numbers)
    dif = biggest - smallest
    if dif == 0:
        return smallest, biggest
    else:
        # return largest, smallest # TODO: what should you do if a different value is found?
        return (smallest, biggest)


