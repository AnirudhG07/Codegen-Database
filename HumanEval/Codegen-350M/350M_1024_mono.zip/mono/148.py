
def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closerst to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return a tuple containing all planets whose orbits are 
    located between the orbit of planet1 and the orbit of planet2, sorted by 
    the proximity to the sun. 
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names. 
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''
    from collections import defaultdict
    import math #For scientific computations 
    import numpy as np
    csp = defaultdict(list)
    for i in range(len(planet1)) : 
        csp['Mercury'].append(planet1[i] +'' + str(int(
            2 * math.pi / (len(planet1) + 1-i)) - math.pi))
    for i in range(len(planet2)):
        csp['Venus'].append(planet2[i] +'' + str(int(
            2 * math.pi / (len(planet2) + 1-i)) - math.pi))
    for i in range(len(planet2)):
        for a in csp.keys():
            csp[a].append(planet2[i] +'' + str(int((
                        2 * math.pi / (len(planet2) + 1-i)) - math.pi)))
        csp.pop(planet2[i])#this is to remove a from a dictionary
    csp['Saturn'] = ""

    def compare(x, y):
        sum = 0
        for e in range(-1,2):
            for t in range(-1, 2):
                sum += (int(((x[0]+e-1)*y[0])/2)+int(((x[0]-e+1)*y[0])/2)+int(x[1]+e-1)* \
                        (y[1]+t)))%2
        return (sum % 2 == 0)   
    
    for planet1, planet2 in csp.items():
        c = compare(planet1, planet2)
        if c:
            new_planet = [planet1, planet2]
            while len(new_planet) < 5 :
                new_planet.append("")
            planet1_planet2_list = []
            for p in range(len(planet1)+1):
                for v in range(len(planet2)+1):
                    if v!= p:
                        planet1_planet2_list.append(csp[planet1][p])
            return (*new_planet, *planet1_planet2_list)
        
            
            
        
    
        
        
            
        
            
        #pass
        
        #else:
         #   return ()
      
    
    #def calc2(planet1, planet2):
    #    '''
    #    This function returns a tuple containing all planets in the 
    #    sorted by an orbit where the planets orbit distance is 
    #    equals to the value of rho and in order of decreasing rho. 
    #    All planets are arranged with respect to the order of rho. 
    #    '''
    #    from collections import defaultdict
    #    import math #For scientific computations 
    #    rho = defaultdict(list)
    #    for planet1 in planet1_planet2_list:
    #        rho[planet1[0]+i+1].append(planet1[1] - planet1[0])
    #        for planet2 in planet2_planet2_list:
    #                if planet1[0]+i+1!= planet2[0]:
    #                    rho[planet1[0]+i+1].append(planet2[1] - planet2[0])
    