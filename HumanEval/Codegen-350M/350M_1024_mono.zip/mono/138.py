
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    if n == 0 or n == 1:
        return True # 1.
    if n % 2 == 0 and n // 2 + 1 > 0:
        return False
    return is_equal_to_sum_even(n // 2 + 1)

print(is_equal_to_sum_even(2)) # True
print(is_equal_to_sum_even(3)) # True
print(is_equal_to_sum_even(4)) # True

"""#######################################################
## This is an auxiliary class 
## class that only does all the work of checking whether the number is equal to its sum of the first two numbers"""
class Check_Sum_Even:
    def __init__(self, num):
        self.n = num
    
    def is_equal_to_sum_even(self):
        if is_equal_to_sum_even(self.n[0] + self.n[1]) == False:
            return True
        return False


print(Check_Sum_Even(8)) # true
print(Check_Sum_Even(2)) # true
print(Check_Sum_Even(1)) # true


