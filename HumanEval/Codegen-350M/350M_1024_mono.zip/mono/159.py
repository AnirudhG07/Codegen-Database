
def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.
    you should return an array of [ total number of eaten carrots after your meals,
                                    the number of carrots left after your meals ]
    if there are not enough remaining carrots, you will eat all remaining carrots, but will still be hungry.
    
    Example:
    * eat(5, 6, 10) -> [11, 4]
    * eat(4, 8, 9) -> [12, 1]
    * eat(1, 10, 10) -> [11, 0]
    * eat(2, 11, 5) -> [7, 0]
    
    Variables:
    @number : integer
        the number of carrots that you have eaten.
    @need : integer
        the number of carrots that you need to eat.
    @remaining : integer
        the number of remaining carrots thet exist in stock
    
    Constrain:
    * 0 <= number <= 1000
    * 0 <= need <= 1000
    * 0 <= remaining <= 1000

    Have fun :)
    """
    remaining_ratio = remaining/number
    
    if number >= 6:
        left_remaining = (remaining-need)
        for i in range(0, number-1):
            remaining_ratio = remaining_ratio * (1 + remaining_ratio)
        left_remaining = remaining_ratio + remaining
        fat = left_remaining
    elif number < 12:
        fat = 10
        left_remaining = (number*fat)
        for i in range(0, fat):
            left_remaining = left_remaining/10
    else:
        fat = 100
        fat = (number * fat) + fat - left_remaining
        left_remaining = fat
        fat = leftover(number, fat, need)

    return fat, left_remaining

