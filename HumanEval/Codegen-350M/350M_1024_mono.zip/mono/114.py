
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    ans = 1e6**10
    i = 0
    if len(nums) == 0:
        return ans
    # while len(nums) > i and nums[i] > 0:
    #     minsubarray=num[i],i=0,j=0,ans=i-minsubarray
    #     while len(nums) > i and nums[j] <= nums[i]:
    #         # ans =min(ans,min(nums[j],nums[i]-num[j]))
    #         if nums[j] + num[i] >= nums[j]:
    #             j += 1
    #         else: 
    #              i += 1
    #     ans = min(ans,nums[i] + num[j + 1])
    
        
    #
    # while len(nums) > i and nums[i] > 0:
    #     # ans =min(ans,min(nums[i],nums[j] - num[i]))
    #     if nums[j] + num[i] >= nums[j]:
    #         j += 1
    #     else:
    #         i += 1
    j_pos = -1
    for i in range(i, len(nums)):
        current = nums[i]
        new_i = - 1
        # ans = min(i-new_i,j)
        # ans = min(current + new_i - i)
        for j in range(new_i+1, i):
            # ans = min(ans,nums[i] + num[j] - num[i])
            current = max(current, nums[j] + num[j])
            new_i = j if new_i < j else new_i
            
        
                
    #     print('i',i)
    #     print('j',j)
    #     print('j_pos',j_pos)
    #     print('nums',i,nums)
    #     print('ans',ans)
        
        # ans = min(ans,current + nums[i] - nums[i] + minsubarray)
        
        ans = min(ans,current+nums[i]-current+nums[j_-1])
    #    ans += current + nums[j] - nums[i]
        
        #     # ans[i] += current + nums[j],j=0,i=0
            #     # ans[i] = min(ans[i],nums[i] + nums[j] - nums[i])
            #     # ans[j] = min(ans[j],nums[i] + nums[j])
            #     #     # ans = min(ans,curmax-ans[i]+ans[j])
                   
        temp = [nums[j]]
        ans = min(ans,sum(nums[j:])+temp)

        new_j = - 1
        temp = [nums[i]]
        #     print('temp',current,temp)
        while new_j < i:
            # print('current temp',current,temp)
            temp = [num[j] - num[i] for j in range(i+1,j_pos,-1) if nums[j], num[i]]
            # ans += current + nums[j] - nums[i] + temp
            ans += (current + temp + nums[i] - current)
            # ans += ans[i][j_pos] + num[j]
            # ans = min(ans,sum(nums[i:j_pos]) + temp)

            new_j = j_pos if new_j > j else new_j
                
    return ans




ans = minSubArraySum([2, 3, 4, 1, 2, 4])
print(ans)