
def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be. or,

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """
    typea = type(a)
    typeb = type(b)
    if typea == int:
        valuea = a
    elif typea == float:
        valuea = a.__float__()
    elif typea == str:
        valuea = a
    else:
        return None
    if typeb == int:
        valueb = b
    elif typeb == float:
        valueb = b.__float__()
    elif typeb == str:
        valueb = b
    else:
        return None

    if valuea == valueb:
        return valuea
    else:
        return None

# print(compare_one(1,2.5)) # Prints 2.5
# print(compare_one(1, "2,3")) # Prints "2,3"
# print(compare_one(1,1)) # Prints None

print(compare_one(1, 3.3))
