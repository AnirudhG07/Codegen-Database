

def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    # sort even list by values
    l.sort()
    even = []
    odd = []
    l_len = len(l)

    for num in range(l_len):
        if num % 2 == 0:
            even.append(l[num])
        else:
            odd.append(l[num])

    return even + odd


if __name__ == '__main__':
    #import doctest
    #args, _, tests = doctest.testmod()
    #if args.report:
     #   print("Tests Run (1/4):")
    #    for item in tests:
     #       print(item)
    l1 = [[1, 2, 3], [9, 8, 7], [6, 5, 4], [12]]
    print(sort_even(l1))