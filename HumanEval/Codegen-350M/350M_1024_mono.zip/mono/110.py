
def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """
    print(lst1)
    print(lst2)

    lst3 = list()
    for i in range(len(lst1)):
        if lst1[i] % 2 == 0 and lst2[i] % 2 == 0:
            lst3.append(lst1[i]**2)
        else:
            lst3.append(0)

    # print(lst1.dtype)
    # print(lst2.dtype)
    # print(lst3)

    if lst1.dtype == int:
        if len(lst3) % 2!= 0:
            if lst1[0] + lst1[-1] == lst1[0]**2 + lst1[len(lst1)-1]**2 and lst1[0] + lst2[0] == lst2[0]**2 + lst2[-1]**2:
                return "YES"
            else:
                a = int((lst1[-1] + lst2[-1])/2)
                b = int((lst1[0]*a + lst2[0]*b) / 3)
                if b == lst2[0]**2 + lst2[-1]**2:
                    return "YES"
                else:
                    a = int(lst1[0] - lst2[0]) ** 2
                    b = int(lst1[-1] + lst2[-1]) - lst2[0]**2 + lst2[-1]**2
                    if b == lst1[0]**2 + lst1[-1]**2:
                        return "YES"
                    else:
                        if a == 0:
                            if b == 0:
                                return "YES"
                            else:

                                for i in range(int((-b + a)/2), len(lst1)):
                                    if lst1[i**2] in lst3:
                                        return "YES"
                                return "NO"
                        else:
                            if b == 0:
                                return "YES"
                            # else:
                            #     print(lst1, lst3)
                            #     print(lst2, lst3)
                            for i in range(int((-b + a)/2), len(lst1)):
                                if lst3[i] - lst1[i] in lst3:
                                    return "YES"
                            return "NO"

    else:
        print(type(lst1))
        print(lst2)
        print(lst3)
        print()
        return "NO"

# print(exchange([4, 2, 8, 6, 7, 3], [2, 1, 3, 4, 5, 6]))
# print(exchange([1, 2, 2, 4, 1], [2, 4, 4, 3, 7]))
# print(exchange([1, 2, 3, 4], [1, 5, 3, 4]))
# print(exchange([1, 2, 3, 4], [1, 5, 3, 4, 0]))