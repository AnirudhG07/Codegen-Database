from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    rolls = []
    last = None

    for index, number in enumerate(numbers):
        if index == 0:
            last = number

        current = last * index

        while True:
            if last == number:
                rolls.append(last)

            if current > 0:
                rolls.append(number)
                last = current

            if current < 0:
                return rolls

            current *= -1


    return []


# A better implementation of stack is to store a dictionary and then use it.  In the worst case, both operations need memory of 1
# memory requirements for stack is a little bit higher than the size of the numbers in the list that will be given in input.
