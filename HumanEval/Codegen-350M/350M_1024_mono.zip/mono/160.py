
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    result = 0                                    # initializing result

    # Step 1: 
    # Check if operator is empty and operand is empty.
    if operator == [] and operand == []:
        # return the result of arithmetic
        # TODO: return result of arithmetic
        return result
    elif operator == [] and operand!= []:
        # step 2: if operand is empty and operator is defined print error. 
        raise Exception('Unable to do algebra without operator')    
    elif operator!= [] and operand!= []:
        # Step 3: for all the indices of operator in operator list and operand in operand list, update the result.
        for i, operator_int in enumerate(operator):
            result += float(operator[i]) * float(operand[i])

    return result