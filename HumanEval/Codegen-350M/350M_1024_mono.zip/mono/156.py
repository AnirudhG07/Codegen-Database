
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    """
    1. Convert int into sring.
    2. Convert int into Roman numeral.
    3. Convert string to int.
    4. Convert the Roman numeral into string.
    """
    roman = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500,
             'M': 1000}
    # dict for sring of roman numerals
    s = []
    # dict for sring of nums
    num = {}

    for i in range(1, number + 1):
        num[i] = roman[i]
    # list for roman numeral
    numeral = [[], [], [], [], [], []]
    # iterate numeral with key values
    for i in range(number + 1):
        if 'I' <= i <= 'Z':
            s.append(i)
        elif 'X' <= i <= 'Z':
            numeral[0].append(i)
        elif 'V' <= i <= 'C':
            numeral[1].append(i)
        elif 'L' <= i <= 'D':
            numeral[2].append(i)
        else:
            numeral[3].append(i)
            numeral[0].remove(i)
            numeral[1].remove(i)
            numeral[2].remove(i)
            numeral[3].remove(i)
            if len(numeral[3]) == 1:
                s.append(numeral[3][0])
    # list of converted numeral
    converted = []
    for i in s:
        if len(s) == 1:
            converted.append(0)
        elif len(s) > 1:
            # convert roman numeral to numeral of length 1
            last_num = [i[-1]]
            for j in range(0, len(i) + 1 - 1):
                last_num.append(s[len(i) - j - 2]//roman[j])
            converted.append(last_num[0])
    # combine to make out string
    if number == 1:
        print("I")
    elif number == 2:
        print("II")
    elif number == 3:
        print("III")
    elif number == 4:
        print("IV")
    else:
        print("VIII")
    print("".join(converted)[:number] + "".join(numeral[number // 10]))
