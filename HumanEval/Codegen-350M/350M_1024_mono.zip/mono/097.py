
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    
    # Write your code here.
    result = 0
    result += a * b
    while b > 0:
        # Calculate the resulting remainder 
        while b > 0:
            remainder = b % 10
            b = int(b / 10)
            result += remainder
        # Keep adding the remainder if the previous calculation 
        # did not reach 0 and the resulting remainder is 0.
        if b == 0:
            break
    result += b
    
    return result
