
def pluck(arr):
    """
    "Given an array representing a branch of a tree that has non-negative integer nodes
    your task is to pluck one of the nodes and return it.
    The plucked node should be the node with the smallest even value.
    If multiple nodes with the same smallest even value are found return the node that has smallest index.

    The plucked node should be returned in a list, [ smalest_value, its index ],
    If there are no even values or the given array is empty, return [].

    Example 1:
        Input: [4,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index.

    Example 2:
        Input: [1,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index. 

    Example 3:
        Input: []
        Output: []
    
    Example 4:
        Input: [5, 0, 3, 0, 4, 2]
        Output: [0, 1]
        Explanation: 0 is the smallest value, but  there are two zeros,
                     so we will choose the first zero, which has the smallest index.

    Constraints:
        * 1 <= nodes.length <= 10000
        * 0 <= node.value
    """
    mh = lambda n, ls: sorted([n, ls%(n/2)+n/2])


    # Create a DAG
    dag = dict()  # d:node -> children nodes, d is a dict
    for val in arr:
        # find the first even index
        for n in range(val, len(dag), 2):
            if n!= val:
                dag[n] = [n] + [mh(n)[0]]
                dag[n].append(mh(n)[-1])
    # print(dag)

    # create a dictionary
    # we also set the first node to be key so that the key has
    # 0 index, and you get the correct index
    d = dict()
    for x in dag:
        if x not in d:
            d[x] = [x] + [0])

    return min(d, key=lambda num: 0 if sum(d[num]) == 0 else num)

# print(pluck([1,2,3,3,3,3]))

T = int(input())
for t in range(1, T+1):
    N = int(input())
    sorts = list(map(lambda x: int(x) if x.isdigit() else x, input().split()))
    print('Case #{}: {}'.format(t, pluck(sorts)))