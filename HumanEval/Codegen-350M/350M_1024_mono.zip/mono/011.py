from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    # a = int(a, 2)
    # b = int(b, 2)
    xor_result = "%02X" % ((a^b) % 256)
    # for i in range(0, 256):
    #     print("%02X" % i, "%02X" % (a^b), "%02X" % (i * 16 % 256))
    #     if i!= 255 or a!= b:
    #         print(chr(i))

    return xor_result
    


# def string_xor(a: str, b: str) -> str:
