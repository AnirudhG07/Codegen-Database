
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    filter_odd=[first_digit,first_digit,first_digit,first_digit,first_digit,first_digit]
    filter_odd[1]=-1
    filter_odd[last_digit]=1
    nth_number =filter_odd.count(nums[0])
    for i in range(0,nth_number):
        if filter_odd.count(nums[i]) > 2:
            filter_odd[nth_number]=(filter_odd.count(nums[i])-2)
    filter_odd[nth_number]=-1
    temp=[first_digit,first_digit,first_digit,first_digit,first_digit,first_digit]
    temp[first_digit]=0
    temp[last_digit]=0
    nth_number=filter_odd.count(nums[len(nums)-1])
    for i in range(0,nth_number):
        if filter_odd.count(nums[i]) > 2:
            filter_odd[nth_number]=-1
    for j in range(0,nth_number-1):
        temp[j]=nums[j]-1
    for k in range(0,nth_number-1):
        temp[k]=nums[k]-1.5;
    filter_odd=temp 

