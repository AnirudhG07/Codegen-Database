
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    while n%2 == 0:        #n: 10, 2, 3
        n = n/2

    if n == 1:                #n: 11, 1, 1
        return 1
    n = n*(3+5)            #n: 11, 1, 1, 6, 9
    return n

# main
if __name__ == '__main__':
    while True:
        digits(int(input("Enter the number: "))),
