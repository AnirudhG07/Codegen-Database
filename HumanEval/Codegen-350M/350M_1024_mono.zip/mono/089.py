
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    new = ""
    if not s: # check if the string is empty 
        return new # If the string is empty return nothing 
    else:
        x = 0    # start at the first item of the string 
        while x < len(s):
            if s[x] in ALPHABET: # if the alphabet is present 
                i = ALPHABET.index(s[x]) # which is the position 
                encrypted = ALPHABET[(i+2)%26] # which is the encrypted character 
            x += 1 # move the index by two 
        for i in range(len(s)): # loop through every char in string:
            new += encrypted # save the result 
    return new # return the result 

