
def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    sorted_array = []

    def sort_half_array(array_2d):
        def sort_two_half_array(array_2d, first_index, last_index):
            for index_0 in range(first_index, last_index):
                for index in range(0, len(array_2d) - index):
                    if (array_2d[index + index_0 * 2] % 2!= 0 and 0 < array_2d[index + index_0 * 2 + 1] % 2!= 0):
                        array_2d[index + index_0 * 2 + 1] = array_2d[index + index_0 * 2 + 1] - array_2d[index + index_0 * 2]
                        array_2d[index + index_0 * 2] = 0

        if len(array_2d) < 2:
            return array_2d
        for index in range(0, len(array_2d) - 1, 2):
            sort_two_half_array(array_2d, first_index=0, last_index=index + 2)
        sort_two_half_array(array_2d, first_index=1, last_index=len(array_2d) - 1)
        return array_2d

    def sort_array_into_array(array_2d):
        array_2d_temp = []
        for index in array_2d:
            index_second = index % 2
            index_first = index // 2
            if index_second == 0 or index_first == 0:
                continue
            else:
                array_2d_temp.append(array_2d[index_first])
                array_2d_temp.append(array_2d[index_second])
                del array_2d[index_second]
                del array_2d[index_first]
        array_2d_temp.sort(reverse=True)
        arr_1 = array_2d_temp
        arr_1.reverse()
        result = []
        for elem in arr_1:
            result.append(elem)
        return result

    if not array:
        return []
    if len(array) == 1:
        return array
    sort_half_array(array)
    return sort_array_into_array(array)

print(sort_array([4, 4, 1, 0, 2, 5, 6]))
print(sort_array([1, 2, 2, 2]))