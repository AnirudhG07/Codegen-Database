

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    # Check character with its corresponding
    # index, if match return True / False
    if not text:
        result = text
    else:
        for i, char in enumerate(reversed(text)):
            # Check character with its corresponding
            # index, if match return True / False
            if char == text[i]:
                result = char

            elif i < len(text) - 1:
                result = not (char == text[i + 1])
                break

    # Make sure it is a valid palindrome
    if not result:
        return False

    return result


# test valid palindrome
print(is_palindrome('a'))
# True
print(is_palindrome('b'))
# False
print(is_palindrome('abcdf'))
# False
