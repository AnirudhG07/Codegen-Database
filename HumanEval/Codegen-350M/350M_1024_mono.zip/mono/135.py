
def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    # The first two elements (1, 2) and any of three other elements
    # are not at same index

    for i in range(len(arr) - 1):
        if arr[i] > arr[i + 1]:
            return -1
    # The first element (1) is at index third and its successor was larger than any other element
    # and it's successor was not at this index
    return 2 + len(arr) - 1


# TEST: print(can_arrange([1,2,4,3,5]))
# [3,3,3,3,3]
# [1,2,3]
# -1

if __name__ == "__main__":
    main()