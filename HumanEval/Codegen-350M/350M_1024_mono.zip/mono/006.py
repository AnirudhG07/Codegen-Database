from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if paren_string == "()":
        return []

    paren_stack = []  # store the topmost paren pairs
    level = 1

    for i, char in enumerate(paren_string):
        if char.isdigit():
            next_char = paren_string[i + 1]
            if next_char not in "(":
                break
            level += int(next_char)
            if paren_stack:
                level -= 1
            paren_stack.append((level, ""))
        elif char == ')':
            if not paren_stack:
                level = 0
                while paren_stack:
                    paren_stack.pop()
            prev_level = paren_stack.pop()
            if prev_level[0]!= level:
                level -= 1

    return level


