
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    if isinstance(value, int):
        return value

    # get the closest closest integer number to value
    integer_closest = (1 + pow(10, 2)) * 100

    if (0 <= value < integer_closest):
        return integer_closest

    # fall point test
    # find where the smallest integer number less than value in the range
    integer_bef = 1
    while integer_bef < integer_closest and integer_bef < 1:
        integer_bef += 1
    integer_beg = 0
    while integer_beg < integer_bef:
        integer_beg += 1

    # now find the closest int between integer_beg and integer_bef
    integer_num = value
    while integer_num >= integer_bef and integer_num < integer_bef:
        integer_num -= 1

    # round up the closest number down
    integer_round = integer_num
    while integer_round >= 1 and integer_round < integer_closest:
        integer_round += 1

    return integer_round
#
