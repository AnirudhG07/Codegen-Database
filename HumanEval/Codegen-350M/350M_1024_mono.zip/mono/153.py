
def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) =='my_class.AA'
    """
    cap = 0
    sm = []
    for extension in extension_list:
        if extension[:1].isupper():
            cap += len(extension)
        if extension[:1].islower():
            sm.append(len(extension) - 1)
    
    # print(cap)
    # print(sm)

    """
    # What is the best extension from these lists?
    if cap == 0:
        return extension_list[0]
    if cap == cap - 1:
        sm = 0
        return extension_list[sm[sm.index(max(sm)]]]
    else:
        if sm[s.index(max(s))] >= 0:
            return extension_list[s.index(max(s))] + extension_list[s.index(max(s))] + ''.join(s[:2 - i] + s[2:]) + extension_list[s.index(max(s))]
        else:
            sm.append(0) 
            sm[s.index(max(s))] = len(extension_list[s[s.index(max(s))]])
            return extension_list[s.index(max(s))] + extension_list[s.index(max(s))] + ''.join(s[:2 - int(sum(sm[s:]) / 2)]) + extension_list[s.index(max(s))]"""
    if cap == 0:
        return extension_list[0]
    if cap == cap - 1:
        sm = 0
        return extension_list[sm[sm.index(max(sm)]]] + ''.join(extension[:2 - i] + extension[2:])
    else:
        if sm[s.index(max(s))] <= 0:
            return extension_list[s.index(max(s))] + extension_list[s.index(max(s))] + ''.join(extension[:2 - int(sum(sm[s:]) / 2)]) + extension_list[s.index(max(s))] + extension_list[s.index(max(s))] + ''.join(extension[2:])
        else:
            sm.append(0) 
            sm[s.index(max(s))] = len(extension_list[s[s.index(max(s))]])
            return extension_list[s.index(max(s))] + ''.join(extension[:2 - int(sum(sm[s:]) / 2)]) + extension_list[s.index(max(s))] + extension_list[s.index(max(s))] 

