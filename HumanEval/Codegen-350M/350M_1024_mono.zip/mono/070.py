
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    output = []
    for i in lst:
        output.append(i)
        min = output.index(min(output))
        output[min], output[-1] = output[-1], output[min]
        del output[min]
    return output

# Test
assert simple_sort_list([1, 3, 5, 9]) == [5, 3, 9, 1]
assert simple_sort_list([4, 2, 3, 1]) == [2, 3, 4, 1]
assert simple_sort_list([6, 5, 1, 2, 4, 9, 7]) == [1, 2, 4, 7, 6, 5, 9]
assert strange_sort_list([]) == []
assert strange_sort_list([9]) == [9, 1]
assert strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
