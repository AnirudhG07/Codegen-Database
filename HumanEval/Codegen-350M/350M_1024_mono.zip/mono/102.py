
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    if x >= y:
        return y
    elif x > y:
        return choose_num(y, x - 1)



T = int(input())

for t in range(1, T+1):
    N = int(input())
    cx = choik_num(N, 100, -1)
    cy = choik_num(N, 100, 0)
    if cx == cy:
        print('#{} 0'.format(t))
    else:
        print('#{} 1'.format(t))