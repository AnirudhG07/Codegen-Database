
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello!!!Wdlor'
    """
    wordlist = [
       '',
    ]
    result = ''
    for _, word in enumerate(s):
        wordlist.append(
            alphabet[int(word)])
    result = ''.join(wordlist)
    return result

# print(anti_shuffle('Hi'))
'''

#
# def longest_sentence(S):
#     """
#     Find the longest possible sentence represented by
#     a word array.
#     """
#     # Fill this in.
#
#     pass

# print(longest_sentence(['a', 'b', 'b', 'c', 'c', 'c']))
# print(longest_sentence(
#     ['a', 'b', 'b', 'c', 'c', 'c', 'c', 'd', 'd', 'd', 'd', 'd']))
# print(longest_sentence(
#     ['a', 'b', 'b', 'c', 'c', 'c', 'c', 'd', 'd', 'd', 'd', 'd']))
# print(longest_sentence(
#     ['a', 'b', 'b', 'c', 'c', 'b', 'c', 'b', 'b', 'c', 'b', 'c']))
# print(longest_sentence(
#     ['a', 'b', 'b', 'c', 'c', 'b', 'c', 'b', 'c', 'c', 'b', 'c']))

##############################################################################################
#
# TODO: Create a letter grade function
# TODO: Now that the function has been defined, write the following:
# TODO: - Convert this function from a string to a float.
# TODO: - Convert this float from ascii values 100.0 to a string "A" "B" "C" etc.
# TODO: - Accomplish one goal to calculate the grade
# TODO: - Test this function on some sentence

# def letter_grade(grade_string):
#     """
#     Returns the letter grade as a string
#     that is numeric in the range 0 - 10
#     """
#     # Fill this in.
#     a = ['A', 'B', 'C', 'D', 'E']
#     # a = ['A', 'A', 'A', 'A', 'A']  # Uncommenting this line will throw an error
#     # TODO: Complete this function
#     # TODO: Return a grade as a string
#     if grade_string not in a:
#         return 'Not a valid letter grade'
#     # TODO: Return the string letter grade
#     else:
#         return 'A'

##############################################################################################
#
# TODO: Create a password hashed password function
# TODO: Define an algorithm to hash a string - it takes in a string & returns a unique value
# TODO: Use the hashe and algos functions to generate the password
# TODO: Write the password
# TODO: Write the tests on the two substrings on the password

# def hashed_password(password, alg):
#     """
#     Returns the hashed value as a string
#     """
#     # Fill this in!
#     m = hashe(password)
#     t = algor(str(m))
#     if alg == 'hash_string':
#         # print(m)
#         str_hash = str(m.hash('password'))
#         # TODO: Create the hash (str_hashing) variable
#         # TODO: Return the hash as a string
#         # TODO: Return the str hashed value
#